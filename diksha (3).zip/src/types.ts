export interface MessDayMenu {
  breakfast: string;
  lunch: string;
  snacks?: string;
  dinner: string;
  specialNote?: string;
}

export type Weekday = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';

export interface MessMenuData {
  [day: string]: MessDayMenu;
}

export interface TuckshopInfo {
  timings: string;
  location: string;
  popularItems: string[];
  paymentModes: string[];
  contactNumber?: string;
  statusNote?: string;
}

export interface CafeteriaInfo {
  timings: string;
  location: string;
  menuHighlights: string[];
  paymentModes: string[];
  seatingCapacity?: string;
}

export interface LaundryInfo {
  process: string[] | string;
  timings: string;
  turnaroundTime: string;
  contactPerson: string;
  cost: string;
  location: string;
  helpline?: string;
}

export interface TimetableSlot {
  time: string;
  subject: string;
  faculty: string;
  room: string;
  code?: string;
}

export interface BatchTimetable {
  batchId: string;
  batchName: string;
  department: string;
  semester: string;
  schedule: {
    [day: string]: TimetableSlot[];
  };
}

export interface EvenSemSession {
  id: string;
  semesterId: string;
  day: string; // 'MON' | 'TUE' | 'WED' | 'THU' | 'FRI' | 'SAT'
  slotIndex: number;
  time: string;
  type: 'Lecture' | 'Practical/Lab' | 'Tutorial';
  courseCode: string;
  batches: string[];
  faculty: string;
  room: string;
  raw: string;
}

export interface EvenSemSemesterOption {
  id: string;
  name: string;
  year: string;
}

export interface EvenSemData {
  semesterOptions: EvenSemSemesterOption[];
  sessions: EvenSemSession[];
  meta: {
    sourceUrl: string;
    sessionName: string;
    totalSessions: number;
  };
}

export interface CampusBlock {
  id: string;
  name: string;
  shortName: string;
  category: 'academic' | 'hostel' | 'amenity' | 'sports' | 'admin';
  description: string;
  coordinates: {
    x: number; // percentage on custom vector map (0-100)
    y: number; // percentage on custom vector map (0-100)
  };
  keyRooms: string[];
  accessibleFeatures: string[];
}

export interface CampusMapInfo {
  blocks: CampusBlock[];
  mapImageUrl?: string;
}

export interface FacultyMember {
  id: string;
  name: string;
  department: string;
  designation: string;
  cabin: string;
  inchargeFor: string[];
  email: string;
  availableHours: string;
  phoneExtension?: string;
  researchArea?: string;
}

export interface CampusLynxStep {
  stepNumber: number;
  title: string;
  description: string;
  tip?: string;
}

export interface CampusLynxGuideItem {
  id: string;
  title: string;
  summary: string;
  category: string;
  steps: CampusLynxStep[];
  directUrl?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'buddy';
  text: string;
  timestamp: string;
  isError?: boolean;
}

export interface StudentProfile {
  enrollmentNo: string;
  batch: string;
  semesterId?: string;
  name?: string;
  isGuest?: boolean;
}

export interface LaundryTrackerRecord {
  id: string;
  tokenNumber: string;
  clothesCount: number;
  dropDate: string;
  expectedDate: string;
  status: 'Dropped' | 'In Wash' | 'Ready for Pickup' | 'Collected';
  notes?: string;
}

export interface Club {
  id: string;
  name: string;
  slug: string;
  description: string;
  categories: string[];
  activities: string[];
  keywords: string[];
  logoUrl: string | null;
  logoAlt: string;
  logoSource: string | null;
  logoVerified: boolean;
  officialEmail: string | null;
  officialPhone: string | null;
  instagramUrl: string | null;
  websiteUrl: string | null;
  discordUrl: string | null;
  whatsappUrl: string | null;
  coordinatorName: string | null;
  coordinatorEmail: string | null;
  eligibility: string | null;
  joiningMethod: string;
  joinLink: string | null;
  recruitmentStatus: 'open' | 'closed' | 'unknown';
  isNew: boolean;
  isFeatured: boolean;
  isActive: boolean;
  lastVerified: any;
  createdAt: any;
  updatedAt: any;
}

export interface AppSettings {
  theme: 'system' | 'light' | 'dark';
  accessibility: AccessibilitySettings;
  academicYear: string; // e.g. "2026-27"
}

export interface AccessibilitySettings {
  textSize: 'default' | 'large' | 'extra-large';
  reducedMotion: 'system' | 'on' | 'off';
  highContrast: 'system' | 'on' | 'off';
}

export interface MapNode {
  id: string;
  name: string;
  type: 'room' | 'corridor' | 'stairs' | 'lift' | 'entrance' | 'poi';
  category?: string;
  description?: string;
  connections: MapConnection[];
  branchDirection?: 'left' | 'right' | 'straight';
  coordinates: { x: number; y: number } | null;
  isVerified: boolean;
  qrCode?: string;
  keywords?: string[];
}

export interface MapConnection {
  to: string;
  direction: string;
  relationship: 'corridor' | 'branch' | 'stairs' | 'lift';
  distance?: number; // estimated or relative
  side?: 'left' | 'right' | 'straight';
}

export interface NavigationStep {
  instruction: string;
  targetNodeId: string;
  type: 'start' | 'move' | 'turn' | 'arrival';
}

export interface NavigationRoute {
  path: string[];
  steps: NavigationStep[];
}

export type LocationSource = 'unknown' | 'manual' | 'qr' | 'gps' | 'ble' | 'wifi';

export interface UserLocation {
  nodeId: string | null;
  source: LocationSource;
  timestamp: number;
}

export interface CampusData {
  mess_menu: MessMenuData;
  tuckshop: TuckshopInfo;
  cafeteria: CafeteriaInfo;
  laundry: LaundryInfo;
  timetable: BatchTimetable[];
  even_sem_2026?: EvenSemData;
  campus_map: CampusMapInfo;
  faculty: FacultyMember[];
  campus_lynx: CampusLynxGuideItem[];
  clubs?: Club[];
  navigation_graph?: MapNode[];
}
