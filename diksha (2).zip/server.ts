import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_CAMPUS_DATA } from './src/data/campusData.ts';
import { INITIAL_CLUBS_DATA } from './src/data/clubsData.ts';
import { GROUND_FLOOR_GRAPH } from './src/data/mapData.ts';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory active campus data (can be updated via admin endpoint)
let currentCampusData = { 
  ...INITIAL_CAMPUS_DATA,
  clubs: INITIAL_CLUBS_DATA
};

// Rate limiting: 25 requests per 10 minutes per IP/session
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_MAX = 25;
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000;

function checkRateLimit(clientId: string): boolean {
  const now = Date.now();
  const record = rateLimitMap.get(clientId);

  if (!record || now > record.resetTime) {
    rateLimitMap.set(clientId, { count: 1, resetTime: now + RATE_LIMIT_WINDOW_MS });
    return true;
  }

  if (record.count >= RATE_LIMIT_MAX) {
    return false;
  }

  record.count += 1;
  return true;
}

// 1. Campus Data API
app.get('/api/campus-data', (_req, res) => {
  res.json({
    status: 'success',
    data: currentCampusData,
    lastUpdated: new Date().toISOString()
  });
});

// 1b. Even Semester 2026 Official Timetable Search & Query API
app.get('/api/timetable/even-sem-2026', (req, res) => {
  const { semester, batch, day, search } = req.query;
  let sessions = currentCampusData.even_sem_2026?.sessions || [];

  if (semester && typeof semester === 'string') {
    sessions = sessions.filter(s => s.semesterId === semester);
  }
  if (batch && typeof batch === 'string') {
    const q = batch.toUpperCase();
    sessions = sessions.filter(s => s.batches.some(b => b.toUpperCase().includes(q)));
  }
  if (day && typeof day === 'string') {
    const d = day.toUpperCase().substring(0, 3);
    sessions = sessions.filter(s => s.day.toUpperCase() === d);
  }
  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    sessions = sessions.filter(s =>
      s.courseCode.toLowerCase().includes(q) ||
      s.faculty.toLowerCase().includes(q) ||
      s.room.toLowerCase().includes(q) ||
      s.batches.some(b => b.toLowerCase().includes(q))
    );
  }

  res.json({
    meta: currentCampusData.even_sem_2026?.meta,
    total: sessions.length,
    sessions,
    semesterOptions: currentCampusData.even_sem_2026?.semesterOptions || []
  });
});

// Admin update endpoint for campus data (e.g., updating menu or timings)
app.post('/api/campus-data/update', (req, res) => {
  const { passcode, section, data } = req.body;
  if (passcode !== 'juit2026' && passcode !== process.env.ADMIN_PASSCODE) {
    res.status(401).json({ error: 'Unauthorized: Invalid administrative passcode' });
    return;
  }

  if (section && data) {
    (currentCampusData as Record<string, unknown>)[section] = data;
    res.json({ status: 'success', message: `Section '${section}' updated successfully.`, data: currentCampusData });
    return;
  }

  res.status(400).json({ error: 'Invalid section or data payload' });
});

// Helper for local keyword-based campus lookup when AI is unavailable or undergoing high-demand spike
function getLocalCampusFallback(message: string, language: string, campusData: typeof currentCampusData): string {
  const query = message.toLowerCase();

  if (query.includes('mess') || query.includes('khana') || query.includes('food') || query.includes('menu') || query.includes('lunch') || query.includes('dinner') || query.includes('breakfast') || query.includes('snack')) {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const todayDay = days[new Date().getDay()];
    const todayMenu = campusData.mess_menu[todayDay];
    return language === 'hi'
      ? `Aaj (${todayDay.toUpperCase()}) ka mess menu:\n• Breakfast: ${todayMenu.breakfast}\n• Lunch: ${todayMenu.lunch}\n• Snacks: ${todayMenu.snacks}\n• Dinner: ${todayMenu.dinner}\n\nDining tab mein poore hafte ka menu check kar sakte hain!`
      : `Today's (${todayDay.toUpperCase()}) mess menu:\n• Breakfast: ${todayMenu.breakfast}\n• Lunch: ${todayMenu.lunch}\n• Snacks: ${todayMenu.snacks}\n• Dinner: ${todayMenu.dinner}\n\nYou can see the full weekly dining schedule in the Dining section!`;
  }

  if (query.includes('tuckshop') || query.includes('maggi') || query.includes('open') || query.includes('canteen') || query.includes('coffee') || query.includes('sandwich')) {
    return language === 'hi'
      ? `Tuckshop timings hain: ${campusData.tuckshop.timings} (${campusData.tuckshop.location}). Maggi, Grilled Sandwiches aur Cold Coffee uplabdh hain! UPI aur Cash dono accept hote hain.`
      : `Tuckshop is located at ${campusData.tuckshop.location}. Timings: ${campusData.tuckshop.timings}. Popular items: Maggi, Grilled Sandwiches, Cold Coffee. Payment: Cash & UPI accepted.`;
  }

  if (query.includes('laundry') || query.includes('dhobi') || query.includes('kapde') || query.includes('clothes') || query.includes('wash')) {
    return language === 'hi'
      ? `Laundry Counter Hostel Block B basement mein hai. Timings: ${campusData.laundry.timings}. Turnaround: ${campusData.laundry.turnaroundTime}. Contact: ${campusData.laundry.contactPerson}. Har mahine 30 items free hain hostel fee mein!`
      : `Laundry facility is at ${campusData.laundry.location}. Hours: ${campusData.laundry.timings}. Turnaround: ${campusData.laundry.turnaroundTime}. Contact: ${campusData.laundry.contactPerson}. Includes 30 garments/month free under hostel fee.`;
  }

  if (query.includes('scholarship') || query.includes('hostel') || query.includes('allotment') || query.includes('faculty') || query.includes('teacher') || query.includes('cabin') || query.includes('hod')) {
    return language === 'hi'
      ? `Important Faculty Cabins:\n• Scholarship Incharge: Dr. Vivek Sehgal (Cabin F-308)\n• Boys Hostel Allotment: Dr. Nafis U. Khan (Cabin F-315)\n• Girls Hostel Allotment: Dr. Geetanjali Rathee (Cabin F-322)\n• CSE/IT HOD: Academic Block 2\n\nFaculty tab mein search karke sabhi teachers ke cabin aur email dekh sakte hain.`
      : `Key Campus Officials & Cabins:\n• Scholarships: Dr. Vivek Sehgal (Cabin F-308)\n• Boys Hostel Incharge: Dr. Nafis U. Khan (Cabin F-315)\n• Girls Hostel Incharge: Dr. Geetanjali Rathee (Cabin F-322)\n\nCheck the Faculty Directory tab for full cabin listings, emails, and consultation hours.`;
  }

  if (query.includes('lynx') || query.includes('attendance') || query.includes('75%') || query.includes('webkiosk') || query.includes('fee') || query.includes('admit card') || query.includes('exam')) {
    return language === 'hi'
      ? `Campus Lynx (webkiosk.juitsolan.in) rules:\n• Exams ke liye minimum 75% attendance mandatory hai.\n• Fee receipt: 'Fee & Accounts' -> 'Student Fee Ledger' se download karein.\n• Exam Hall Ticket: 'Exam' section se generate hoti hai T1, T2, T3 ke pehle.`
      : `Campus Lynx (webkiosk.juitsolan.in) Essentials:\n• Attendance: Strict 75% minimum required to be eligible for T1/T2/T3 exams.\n• Fee Receipt: Navigate to 'Fee & Accounts' -> 'Student Fee Ledger' -> Print receipt.\n• Detailed step-by-step guides are in the Campus Lynx tab.`;
  }

  if (query.includes('timetable') || query.includes('schedule') || query.includes('class') || query.includes('lecture') || query.includes('batch') || query.includes('lab') || query.includes('sem')) {
    const sessions = campusData.even_sem_2026?.sessions || [];
    const qUpper = query.toUpperCase();
    const matched = sessions.filter(s => {
      return s.batches.some(b => qUpper.includes(b.toUpperCase())) ||
        (s.courseCode && qUpper.includes(s.courseCode.toUpperCase())) ||
        (s.faculty && qUpper.includes(s.faculty.toUpperCase())) ||
        (s.room && qUpper.includes(s.room.toUpperCase()));
    });

    if (matched.length > 0) {
      const list = matched.slice(0, 6).map(s => `• [${s.day} ${s.time}] ${s.courseCode} (${s.type}) in ${s.room}, Faculty: ${s.faculty || 'Dept'} (Batches: ${s.batches.slice(0, 3).join(', ')})`).join('\n');
      return language === 'hi'
        ? `Official Even Sem 2026 Timetable se matched sessions:\n${list}\n\nPoora schedule Timetable tab mein batch filter ke saath dekhein!`
        : `Matched sessions from official Even Semester 2026 Timetable:\n${list}\n\nFilter your complete batch timetable directly in the Timetable tab!`;
    }

    return language === 'hi'
      ? "Official JUIT Even Sem 2026 Timetable (EVENSEM2026.xls) app mein integrated hai! Aap Timetable tab mein jaakar apna semester (B.Tech 2, 4, 6, 8 sem) aur batch select karke poora schedule dekh sakte hain."
      : "The official JUIT Even Semester 2026 Timetable is fully integrated into the app! Visit the Timetable tab to see class schedules filtered by your specific semester and batch.";
  }

  if (query.includes('map') || query.includes('location') || query.includes('block') || query.includes('where is') || query.includes('audi') || query.includes('library')) {
    return language === 'hi'
      ? `JUIT Campus Blocks:\n• Academic Block 1: First-year classrooms, Admin offices, LRC Library.\n• Academic Block 2: CSE/IT labs, Faculty cabins.\n• Academic Block 3: Biotech, Pharmacy labs, Auditoriums.\n• Multi-Purpose Hall & Sports Ground: Lower campus.\n\nCampus Map tab mein interactive campus layout dekhein!`
      : `JUIT Campus Locations:\n• Academic Block 1: Freshman lecture halls, Registrar, Accounts, Central LRC Library.\n• Academic Block 2: Computer Science & IT department, server rooms, faculty cabins.\n• Academic Block 3: Biotechnology & Bioinformatics research labs, main auditorium.\n• Check the Campus Map tab for interactive layout and navigation!`;
  }

  return language === 'hi'
    ? "Namaste! Main JUIT Buddy hoon. Aap mujhse mess menu, tuckshop timings, laundry rules, Even Sem 2026 timetable, faculty cabins, ya Campus Lynx ke baare mein pooch sakte hain."
    : "Hello! I am JUIT Buddy. Feel free to ask me about today's mess menu, tuckshop timings, laundry services, Even Sem 2026 timetables, faculty cabin numbers, or Campus Lynx steps.";
}

async function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  let timer: NodeJS.Timeout;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      const err = new Error(`Request timed out after ${ms}ms`);
      (err as unknown as { status: number }).status = 504;
      reject(err);
    }, ms);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer));
}

// Initialize Gemini with telemetry User-Agent header and longer request timeout
const GENAI_CLIENT = process.env.GEMINI_API_KEY 
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
        timeout: 15000, // Increased to 15s for more reliable responses
      }
    })
  : null;

// Resilient helper with timeout and model fallback cascade for 503 high-demand mitigation
async function callGeminiWithRetryAndFallback(
  ai: GoogleGenAI,
  message: string,
  systemInstruction: string
): Promise<string | null> {
  // Ordered cascade: primary recommended flash -> flash latest alias
  const models = ['gemini-3.8-flash', 'gemini-flash-latest'];

  for (const model of models) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: message,
        config: {
          systemInstruction,
          temperature: 0.6,
        }
      });

      if (response && response.text) {
        return response.text;
      }
    } catch (err: unknown) {
      const errObj = err as {
        status?: number;
        code?: number;
        message?: string;
        error?: { code?: number; status?: string; message?: string };
      };
      const msg = (errObj.error?.message || errObj.message || '').toString();
      const statusStr = (errObj.error?.status || '').toString();

      console.warn(`[askJuitBuddy] Model ${model} unavailable: ${msg || statusStr || 'Temporary error'}`);
    }
  }

  return null;
}

// 2. Gemini Proxy: JUIT Buddy Chatbot
app.post('/api/askJuitBuddy', async (req, res) => {
  try {
    const { message, language = 'en', sessionId, context } = req.body;
    const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || 'anonymous';
    const rateLimitKey = sessionId || clientIp;

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      res.status(400).json({ error: 'A valid message string is required.' });
      return;
    }

    // Rate Limit Check
    if (!checkRateLimit(rateLimitKey)) {
      res.status(429).json({
        reply: language === 'hi'
          ? "Aapne session request limit exceed kar di hai (25 messages). Kripya thodi der baad dobara try karein!"
          : "You have reached the session query limit (25 messages). Please wait a few minutes before asking again."
      });
      return;
    }

    if (!GENAI_CLIENT) {
      console.warn('GEMINI_API_KEY environment variable is not configured, serving verified local campus data.');
      const fallbackReply = getLocalCampusFallback(message, language, currentCampusData);
      res.json({ reply: fallbackReply });
      return;
    }

    // Extract relevant Even Semester 2026 timetable sessions matching student query
    let relevantTimetableSessions: unknown[] = [];
    if (currentCampusData.even_sem_2026?.sessions) {
      const msgUpper = message.toUpperCase();
      const matched = currentCampusData.even_sem_2026.sessions.filter(s => {
        return (
          s.batches.some(b => msgUpper.includes(b.toUpperCase())) ||
          (s.faculty && msgUpper.includes(s.faculty.toUpperCase())) ||
          (s.courseCode && msgUpper.includes(s.courseCode.toUpperCase())) ||
          (s.room && msgUpper.includes(s.room.toUpperCase())) ||
          (msgUpper.includes('TIMETABLE') || msgUpper.includes('CLASS') || msgUpper.includes('SCHEDULE') || msgUpper.includes('BATCH'))
        );
      });
      relevantTimetableSessions = matched.slice(0, 30).map(s => ({
        semester: s.semesterId,
        day: s.day,
        time: s.time,
        type: s.type,
        courseCode: s.courseCode,
        batches: s.batches,
        faculty: s.faculty,
        room: s.room
      }));
    }

    // Compile structured campus data for context
    const campusContextData = {
      mess_menu: currentCampusData.mess_menu,
      tuckshop: currentCampusData.tuckshop,
      cafeteria: currentCampusData.cafeteria,
      laundry: currentCampusData.laundry,
      timetable: currentCampusData.timetable,
      even_sem_2026_timetable_sample: relevantTimetableSessions,
      campus_map: currentCampusData.campus_map.blocks.map(b => ({
        name: b.name,
        shortName: b.shortName,
        category: b.category,
        description: b.description,
        keyRooms: b.keyRooms
      })),
      faculty: currentCampusData.faculty.map(f => ({
        name: f.name,
        department: f.department,
        designation: f.designation,
        cabin: f.cabin,
        inchargeFor: f.inchargeFor,
        email: f.email,
        availableHours: f.availableHours
      })),
      campus_lynx_guides: currentCampusData.campus_lynx.map(g => ({
        title: g.title,
        summary: g.summary,
        category: g.category,
        steps: g.steps.map(s => `${s.stepNumber}. ${s.title}: ${s.description}`)
      })),
      clubs: currentCampusData.clubs?.map(c => ({
        name: c.name,
        description: c.description,
        categories: c.categories,
        recruitmentStatus: c.recruitmentStatus,
        joiningMethod: c.joiningMethod
      })),
      ground_floor_navigation_graph: GROUND_FLOOR_GRAPH.map(n => ({
        id: n.id,
        name: n.name,
        type: n.type,
        category: n.category,
        connections: n.connections.map(c => c.to)
      }))
    };

    const userDate = context?.currentDate || new Date().toDateString();
    const userTime = context?.currentTime || new Date().toLocaleTimeString();
    const userDay = context?.dayOfWeek || new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date());
    const userTimeZone = context?.timezone || 'Asia/Kolkata';
    const academicYear = context?.academicYear || '2026-27';

    const systemInstruction = `You are JUIT Buddy, the AI campus companion inside the JUIT Guide app for students of Jaypee University of Information Technology (JUIT), Waknaghat.

RUNTIME CONTEXT (User Device Info):
- Current Date: ${userDate}
- Current Time: ${userTime}
- Day of Week: ${userDay}
- User Timezone: ${userTimeZone}
- Academic Year (JUIT Verified): ${academicYear}

CORE PERSONALITY:
- Smart, helpful Gen-Z senior/friend from JUIT. Not a corporate bot.
- Friendly, witty, slightly sarcastic, helpful, emotionally aware.
- Concise and easy to understand. "Smart senior energy".

LANGUAGE STYLE:
- Use natural Hinglish + English. 
- Use Gen-Z expressions occasionally (bro, ngl, tbh, btw, literally, lowkey, honestly, 😭, 💀, 👀).
- Never put slang in every sentence. Natural > forced.

HUMOUR & ROASTING:
- Make small jokes when natural.
- Lightly roast the SITUATION (e.g., "Bro really chose the hardest possible route 😭"), never the student's identity.
- Use JUIT-specific context (Attendance, Mess, Moodle, Campus Lynx, 75% rule).
- If the student is genuinely stressed/scared, STOP joking and be supportive.

RULES:
1. NEVER sacrifice accuracy for humour. Do not invent room numbers, faculty, or timings.
2. If you don't know, say: "I don't have a verified room number for that one yet. Check Moodle/timetable or ask your batch coordinator."
3. Prefer short responses (1-3 sentences for simple questions). Use bullet points for complex ones.
4. Route Format: "Yep — go from [starting point] → [building] → [landmark] → [destination]."
5. Be serious/professional for emergencies (medical, safety, harassment).
6. DATE SAFETY: Calculate relative dates (today, tomorrow, next week) using the Runtime Context provided above. Never assume the current year is 2026 unless confirmed by Runtime Context.
7. TIMEZONE: Assume JUIT local time is Asia/Kolkata. If user timezone is different, clarify if needed.

70% useful information | 20% natural personality | 10% humour/roasting.

CLUB RESPONSE STYLE:
- When answering club questions, sound like a helpful senior: friendly, concise, slightly Gen-Z, occasional Hinglish.
- Example: "If you're into coding, ACM JUIT and SIAM JUIT are worth checking out. If you're more into bio + research, SYNAPSE is probably more your lane."
- NEVER invent recruitment dates or joining links. Use verified database info only.

NAVIGATION & MAPS:
- You understand the JUIT Ground Floor navigation graph.
- If a user asks "Where am I?", and their location is known (provided in context), tell them. If unknown, say: "I don't have your indoor location yet. Set your location or scan a JUIT location QR in the Ground Floor Map tab."
- Never guess or fake a user's location.
- When asked "Take me to [Destination]", check if their current location is known. If yes, provide a natural Hinglish route based on the graph connections. 
- Example: "Sure. You're at LT2. Head toward the central hallway, continue past the stairs, and LRC will be on your right."
- Route for CR1: "Go through the Lower Level route, then take the stairs to CR1."
- If location is unknown, guide them to use the Ground Floor Map tool.

CAMPUS DATA:
${JSON.stringify(campusContextData)}`;

    // Call Gemini with retry & model fallback cascade
    const generatedText = await callGeminiWithRetryAndFallback(GENAI_CLIENT, message, systemInstruction);

    if (generatedText) {
      res.json({ reply: generatedText });
      return;
    }

    // If all upstream AI models were temporarily unavailable due to demand spikes
    console.warn('[askJuitBuddy] Upstream AI models temporarily in high demand; activating verified campus knowledge fallback.');
    const localAnswer = getLocalCampusFallback(message, language, currentCampusData);
    const politePrefix = language === 'hi'
      ? "*(Note: Model high demand ke dauran JUIT Verified Campus Data se direct information:)*\n\n"
      : "*(Note: AI service is experiencing a temporary demand spike; serving verified JUIT campus data directly:)*\n\n";

    res.json({ reply: politePrefix + localAnswer });

  } catch (err: unknown) {
    const error = err as Error;
    console.warn('[askJuitBuddy] Fallback triggered due to unexpected error:', error?.message || error);
    try {
      const fallbackReply = getLocalCampusFallback(req.body?.message || '', req.body?.language || 'en', currentCampusData);
      res.json({ reply: fallbackReply });
    } catch {
      res.json({
        reply: 'JUIT Buddy is having trouble reaching the campus server right now. Please check the relevant dining, laundry, or faculty tabs directly or try again shortly.'
      });
    }
  }
});

// Vite middleware / production serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`JUIT Guide server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
