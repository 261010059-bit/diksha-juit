import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { CampusProvider, useCampus } from './context/CampusContext';
import { SettingsProvider, useSettings } from './context/SettingsContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { DiningView } from './components/DiningView';
import { LaundryView } from './components/LaundryView';
import { TimetableView } from './components/TimetableView';
import { CampusLynxView } from './components/CampusLynxView';
import { FacultyView } from './components/FacultyView';
import { ClubsView } from './components/ClubsView';
import { ClubDetailView } from './components/ClubDetailView';
import { ClubsAdminView } from './components/ClubsAdminView';
import { SettingsView } from './components/SettingsView';
import { GroundFloorMapView } from './components/GroundFloorMapView';
import { NavigationProvider } from './context/NavigationContext';
import { JuitBuddyChatModal } from './components/JuitBuddyChatModal';
import { AdminModal } from './components/AdminModal';
import { StudentEntryModal } from './components/StudentEntryModal';
import {
  PhoneCall,
  Shield,
  HeartPulse,
  Sparkles,
  MapPin,
  Building2,
  ExternalLink
} from 'lucide-react';

const ChatAutoOpener: React.FC = () => {
  const { setIsChatOpen } = useCampus();
  React.useEffect(() => {
    setIsChatOpen(true);
  }, [setIsChatOpen]);
  return <Navigate to="/" replace />;
};

const MainLayout: React.FC = () => {
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const location = useLocation();
  const { studentProfile, isProfileModalOpen, setIsProfileModalOpen } = useCampus();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-[#0B2545] selection:text-white">
      
      {/* Student Entry Gate on website entrance */}
      {!studentProfile && (
        <StudentEntryModal isBlocking={true} />
      )}

      {/* Student Profile Switcher / Editor Modal */}
      {studentProfile && isProfileModalOpen && (
        <StudentEntryModal
          isBlocking={false}
          onClose={() => setIsProfileModalOpen(false)}
        />
      )}

      {/* Top Header */}
      <Navbar onOpenAdmin={() => setIsAdminOpen(true)} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-24 lg:pb-16">
        <Routes>
          <Route path="/" element={<HomeView />} />
          <Route path="/dining" element={<DiningView />} />
          <Route path="/laundry" element={<LaundryView />} />
          <Route path="/timetable" element={<TimetableView />} />
          <Route path="/campus-lynx" element={<CampusLynxView />} />
          <Route path="/faculty" element={<FacultyView />} />
          <Route path="/clubs" element={<ClubsView />} />
          <Route path="/clubs/:clubId" element={<ClubDetailView />} />
          <Route path="/admin/clubs" element={<ClubsAdminView />} />
          <Route path="/settings" element={<SettingsView />} />
          <Route path="/map/ground-floor" element={<GroundFloorMapView />} />
          <Route path="/chat" element={<ChatAutoOpener />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      {/* Campus Footer & Emergency Strip */}
      <footer className="bg-[#0B1E36] text-slate-300 border-t border-[#142C4E] text-xs py-8 px-4 sm:px-6 lg:px-8 mt-auto hidden sm:block">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-[#142C4E]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white p-0.5 ring-1 ring-blue-400/40 shadow-sm flex items-center justify-center overflow-hidden flex-shrink-0">
                <img
                  src="/src/assets/images/juit_official_logo_v4_final_1789206375553.jpg"
                  alt="JUIT Logo"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <span className="font-bold text-white text-sm">Jaypee University of Information Technology</span>
                <p className="text-[11px] text-slate-400">Waknaghat, P.O. Waknaghat, Teh. Kandaghat, Distt. Solan, H.P. - 173234</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-[11px]">
              <div className="flex items-center gap-1.5 text-slate-300">
                <HeartPulse className="w-3.5 h-3.5 text-rose-400" />
                <span>Dispensary (24/7): <strong className="text-white">Ext. 112</strong></span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                <span>Main Gate Security: <strong className="text-white">Ext. 200</strong></span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                <PhoneCall className="w-3.5 h-3.5 text-sky-400" />
                <span>Hostel Caretaker: <strong className="text-white">Ext. 401</strong></span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px]">
            <p>© {new Date().getFullYear()} JUIT Guide • Developed for JUIT Students & Faculty</p>
            <div className="flex items-center gap-4">
              <a
                href="https://www.juit.ac.in"
                target="_blank"
                rel="noreferrer"
                className="hover:text-white transition-colors flex items-center gap-1"
              >
                <span>Official JUIT Website</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <a
                href="https://webkiosk.juitsolan.in"
                target="_blank"
                rel="noreferrer"
                className="hover:text-white transition-colors flex items-center gap-1"
              >
                <span>Webkiosk Portal</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating PARTHSAARATHI AI Modal & FAB */}
      <JuitBuddyChatModal />

      {/* Admin Passcode Modal */}
      <AdminModal isOpen={isAdminOpen} onClose={() => setIsAdminOpen(false)} />

      {/* Mobile Bottom Navigation */}
      <BottomNav />

    </div>
  );
};

export default function App() {
  return (
    <SettingsProvider>
      <CampusProvider>
        <NavigationProvider>
          <BrowserRouter>
            <MainLayout />
          </BrowserRouter>
        </NavigationProvider>
      </CampusProvider>
    </SettingsProvider>
  );
}
