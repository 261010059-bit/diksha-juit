import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  Search,
  Mail,
  Clock,
  MapPin,
  Phone,
  Sparkles,
  ShieldCheck,
  Building,
  Award
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { FacultyMember } from '../types';
import { BackButton } from './common/BackButton';
import { EmptyState } from './common/EmptyState';

export const FacultyView: React.FC = () => {
  const navigate = useNavigate();
  const { data, setIsChatOpen, setChatInitialPrompt } = useCampus();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('All');

  const tags = [
    'All',
    'Scholarship',
    'Hostel Allotment',
    'Placements',
    'Anti-Ragging',
    'Student Welfare',
    'Examinations'
  ];

  const filteredFaculty = data.faculty.filter((fac) => {
    const matchesSearch =
      fac.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fac.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fac.cabin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      fac.inchargeFor.some(p => p.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesTag =
      selectedTag === 'All' ||
      fac.inchargeFor.some(p => p.toLowerCase().includes(selectedTag.toLowerCase()));

    return matchesSearch && matchesTag;
  });

  const handleAskFaculty = (fac: FacultyMember) => {
    setChatInitialPrompt(`Tell me about ${fac.name} (${fac.designation}), their cabin ${fac.cabin}, incharge duties, and available hours.`);
    setIsChatOpen(true);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* View Header with Back Navigation */}
      <div className="space-y-4">
        <BackButton />
        <div className="space-y-1">
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Faculty Directory
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Find cabins before the 'sir, actually' walk 🎓
          </p>
        </div>
      </div>

      {/* Search & Tags */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by professor name, cabin (e.g. F-308), department, or incharge duty..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-2.5 rounded-2xl text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {tags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedTag === tag
                  ? 'bg-[#0B2545] text-white shadow-md shadow-blue-950/40'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      {/* Faculty Cards Grid */}
      {filteredFaculty.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredFaculty.map((fac) => (
            <div
              key={fac.id}
              className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm hover:border-blue-500/40 hover:shadow-md transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {fac.name}
                    </h3>
                    <p className="text-xs font-medium text-blue-700 dark:text-blue-400">
                      {fac.designation}
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Dept. of {fac.department}
                    </p>
                  </div>
                  <div className="w-10 h-10 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 flex items-center justify-center font-bold flex-shrink-0">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                </div>

                {/* Cabin Location Badge */}
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-1.5 text-xs">
                  <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <span>Cabin: {fac.cabin}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 text-[11px]">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{fac.availableHours}</span>
                  </div>
                </div>

                {/* Incharge Portfolios */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Campus Responsibilities
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {fac.inchargeFor.map((item, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800/40"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions: Email + Ask Buddy */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                <a
                  href={`mailto:${fac.email}`}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Email</span>
                </a>

                <button
                  onClick={() => handleAskFaculty(fac)}
                  className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 dark:text-blue-400 hover:underline"
                >
                  <span>Ask Buddy</span>
                  <Sparkles className="w-3 h-3 text-sky-400" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Search}
          title="No faculty found"
          description={`Couldn't find anyone matching "${searchTerm}". Maybe they're in a different department or taking a lecture?`}
          actionLabel="Clear filters"
          onAction={() => {
            setSearchTerm('');
            setSelectedTag('All');
          }}
        />
      )}
    </div>
  );
};
