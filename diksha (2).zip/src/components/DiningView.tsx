import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Utensils,
  Coffee,
  Store,
  Clock,
  MapPin,
  CreditCard,
  CheckCircle2,
  Calendar,
  Sparkles,
  ChevronRight,
  Info
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { Weekday } from '../types';
import { BackButton } from './common/BackButton';

export const DiningView: React.FC = () => {
  const navigate = useNavigate();
  const { data, setIsChatOpen, setChatInitialPrompt } = useCampus();
  const [searchParams, setSearchParams] = useSearchParams();

  // Tab state: 'mess' | 'cafeteria' | 'tuckshop'
  const initialTab = (searchParams.get('tab') as 'mess' | 'cafeteria' | 'tuckshop') || 'mess';
  const [activeTab, setActiveTab] = useState<'mess' | 'cafeteria' | 'tuckshop'>(initialTab);

  // Sync tab with URL query parameter
  useEffect(() => {
    const tabFromUrl = searchParams.get('tab') as 'mess' | 'cafeteria' | 'tuckshop';
    if (tabFromUrl && ['mess', 'cafeteria', 'tuckshop'].includes(tabFromUrl)) {
      setActiveTab(tabFromUrl);
    }
  }, [searchParams]);

  const handleTabChange = (tab: 'mess' | 'cafeteria' | 'tuckshop') => {
    setActiveTab(tab);
    setSearchParams({ tab });
  };

  // Day selector for Mess: defaults to today
  const dayKeys: Weekday[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const dayDisplayNames: Record<Weekday, string> = {
    monday: 'Monday',
    tuesday: 'Tuesday',
    wednesday: 'Wednesday',
    thursday: 'Thursday',
    friday: 'Friday',
    saturday: 'Saturday',
    sunday: 'Sunday'
  };

  const currentDayIndex = new Date().getDay(); // 0 is Sunday, 1 is Monday...
  const todayKey: Weekday = currentDayIndex === 0 ? 'sunday' : dayKeys[currentDayIndex - 1];

  const [selectedDay, setSelectedDay] = useState<Weekday>(todayKey);

  // Tuckshop open: 8:00 AM to 11:00 PM
  const now = new Date();
  const currentHour = now.getHours();
  const isTuckshopOpen = currentHour >= 8 && currentHour < 23;

  const currentMenu = data.mess_menu[selectedDay] || data.mess_menu.monday;

  const handleAskDining = (item: string) => {
    setChatInitialPrompt(`Tell me more about ${item} at JUIT dining.`);
    setIsChatOpen(true);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* View Header with Back Navigation */}
      <div className="space-y-4">
        <BackButton />
        <div className="space-y-1">
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Dining & Mess
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Weekly menu, timings & tuckshop scenes 🍕
          </p>
        </div>
      </div>

        {/* Tab Switcher */}
        <div className="flex p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
          <button
            id="tab-btn-mess"
            onClick={() => handleTabChange('mess')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'mess'
                ? 'bg-[#0B2545] text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Utensils className="w-4 h-4" />
            <span>Mess Menu</span>
          </button>
          <button
            id="tab-btn-cafeteria"
            onClick={() => handleTabChange('cafeteria')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'cafeteria'
                ? 'bg-[#0B2545] text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Coffee className="w-4 h-4" />
            <span>Cafeteria</span>
          </button>
          <button
            id="tab-btn-tuckshop"
            onClick={() => handleTabChange('tuckshop')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
              activeTab === 'tuckshop'
                ? 'bg-[#0B2545] text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Store className="w-4 h-4" />
            <span>Tuckshop</span>
          </button>
        </div>

      {/* 1. MESS TAB */}
      {activeTab === 'mess' && (
        <div className="space-y-6">
          {/* Day Selector Pills */}
          <div className="bg-white dark:bg-slate-900 p-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-x-auto">
            <div className="flex items-center gap-1.5 min-w-max">
              {dayKeys.map((day) => {
                const isSelected = selectedDay === day;
                const isToday = todayKey === day;
                return (
                  <button
                    key={day}
                    id={`day-select-${day}`}
                    onClick={() => setSelectedDay(day)}
                    className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all relative ${
                      isSelected
                        ? 'bg-[#0B2545] text-white font-bold shadow-md shadow-blue-950/40'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <span>{dayDisplayNames[day]}</span>
                    {isToday && (
                      <span className={`ml-1.5 px-1.5 py-0.2 rounded text-[10px] uppercase tracking-wide font-extrabold ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300'
                      }`}>
                        Today
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Meals Layout for Selected Day */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Breakfast Card */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm hover:border-blue-500/40 transition-all">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                    ☕
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-base">
                      Breakfast
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      07:30 AM – 09:00 AM
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  Morning
                </span>
              </div>
              <p className="text-sm sm:text-base font-medium text-slate-800 dark:text-slate-200 leading-relaxed min-h-[50px]">
                {currentMenu.breakfast}
              </p>
            </div>

            {/* Lunch Card */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm hover:border-blue-500/40 transition-all">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                    🍲
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-base">
                      Lunch
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      12:30 PM – 02:15 PM
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  Afternoon
                </span>
              </div>
              <p className="text-sm sm:text-base font-medium text-slate-800 dark:text-slate-200 leading-relaxed min-h-[50px]">
                {currentMenu.lunch}
              </p>
            </div>

            {/* Evening Snacks Card */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm hover:border-blue-500/40 transition-all">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 flex items-center justify-center font-bold">
                    🫖
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-base">
                      Evening Snacks & Tea
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      05:00 PM – 06:15 PM
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  Evening
                </span>
              </div>
              <p className="text-sm sm:text-base font-medium text-slate-800 dark:text-slate-200 leading-relaxed min-h-[50px]">
                {currentMenu.snacks}
              </p>
            </div>

            {/* Dinner Card */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm hover:border-blue-500/40 transition-all">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                    🍛
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white text-base">
                      Dinner & Dessert
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      07:45 PM – 09:30 PM
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  Night
                </span>
              </div>
              <p className="text-sm sm:text-base font-medium text-slate-800 dark:text-slate-200 leading-relaxed min-h-[50px]">
                {currentMenu.dinner}
              </p>
            </div>

          </div>

          {/* Notes / Special information */}
          {currentMenu.specialNote && (
            <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-blue-600 flex-shrink-0" />
              <p className="text-xs sm:text-sm font-medium text-blue-900 dark:text-blue-200">
                <span className="font-bold">Chef's Day Special:</span> {currentMenu.specialNote}
              </p>
            </div>
          )}

          {/* Annapurna Mess Facility Info */}
          <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200 font-bold text-sm">
              <Info className="w-4 h-4 text-blue-600" />
              <span>Annapurna Mess Guidelines for Students & Guests</span>
            </div>
            <ul className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 space-y-1.5 list-disc pl-5">
              <li>Entry is governed via JUIT Student Biometric or RFID Hostel Identity Cards.</li>
              <li>Guest coupons (for visiting parents/friends) are available at the Mess Manager office (₹75 for Breakfast, ₹110 for Lunch/Dinner).</li>
              <li>Diet rebates must be submitted at least 48 hours prior via the Hostel Office for official club/sports trips.</li>
            </ul>
          </div>
        </div>
      )}

      {/* 2. CAFETERIA TAB */}
      {activeTab === 'cafeteria' && (
        <div className="space-y-6">
          {/* Info Card */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                  <MapPin className="w-3.5 h-3.5 text-blue-600" />
                  <span>Academic Complex Annex Ground Floor</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  JUIT Student Cafeteria
                </h2>
                <p className="text-slate-500 dark:text-slate-400 text-sm">
                  Quick hot meals, South Indian snacks, Chinese dishes, juices, and scenic outdoor pine-tree seating.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span>Timings</span>
                  </div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                    {data.cafeteria.timings}
                  </p>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <CreditCard className="w-4 h-4 text-blue-600" />
                    <span>Payments</span>
                  </div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                    {data.cafeteria.paymentModes.join(', ')}
                  </p>
                </div>
              </div>
            </div>

            {/* Popular Items & Highlights */}
            <div className="mt-6 space-y-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Featured Menu Highlights & Rates
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {data.cafeteria.menuHighlights.map((item, index) => (
                  <div
                    key={index}
                    onClick={() => handleAskDining(item)}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 hover:border-blue-500/50 hover:bg-blue-50/20 dark:hover:bg-blue-950/20 cursor-pointer transition-all flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-xs font-extrabold text-blue-700 dark:text-blue-300">
                        {index + 1}
                      </span>
                      <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                        {item}
                      </span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. TUCKSHOP TAB */}
      {activeTab === 'tuckshop' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                    isTuckshopOpen
                      ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                  }`}>
                    {isTuckshopOpen ? '● Open Now' : '○ Currently Closed'}
                  </span>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    Closes 11:00 PM Daily
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  Campus Tuckshop
                </h2>
                <p className="text-slate-500 dark:text-slate-400 text-sm">
                  {data.tuckshop.location}. The premier late-night refuge for hot Maggi, energy drinks, snacks, and exam stationery.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span>Operating Hours</span>
                  </div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                    {data.tuckshop.timings}
                  </p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <CreditCard className="w-4 h-4 text-blue-600" />
                    <span>Payment Methods</span>
                  </div>
                  <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                    {data.tuckshop.paymentModes.join(', ')}
                  </p>
                </div>
              </div>
            </div>

            {/* Popular Tuckshop items */}
            <div className="mt-6 space-y-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Popular Midnight Items & Essentials
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {data.tuckshop.popularItems.map((item, index) => (
                  <div
                    key={index}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-center gap-3"
                  >
                    <span className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-sm">
                      ✨
                    </span>
                    <span className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                      {item}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {data.tuckshop.contactNumber && (
              <div className="mt-6 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs sm:text-sm">
                <span className="text-slate-600 dark:text-slate-400">
                  Direct Campus Intercom Extension: <strong className="text-slate-900 dark:text-white">{data.tuckshop.contactNumber}</strong>
                </span>
                <button
                  onClick={() => handleAskDining("Tuckshop items and prices")}
                  className="text-blue-700 dark:text-blue-400 font-bold hover:underline"
                >
                  Ask PARTHSAARATHI
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
