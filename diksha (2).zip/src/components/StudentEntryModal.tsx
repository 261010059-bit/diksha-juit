import React, { useState, useEffect, useMemo } from 'react';
import {
  GraduationCap,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  X,
  User,
  Layers,
  Search,
  BookOpen,
  Info,
  LogOut
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { StudentProfile } from '../types';
import { EVEN_SEM_2026_DATA } from '../data/evenSem2026Data';

interface StudentEntryModalProps {
  isBlocking?: boolean;
  onClose?: () => void;
}

export const StudentEntryModal: React.FC<StudentEntryModalProps> = ({
  isBlocking = false,
  onClose
}) => {
  const { studentProfile, saveStudentProfile, logoutStudent } = useCampus();

  const [enrollmentNo, setEnrollmentNo] = useState<string>(studentProfile?.enrollmentNo || '');
  const [selectedBatch, setSelectedBatch] = useState<string>(studentProfile?.batch || '24A17');
  const [studentName, setStudentName] = useState<string>(studentProfile?.name || '');
  const [selectedSemesterId, setSelectedSemesterId] = useState<string>(studentProfile?.semesterId || 'btech_4');
  const [batchSearch, setBatchSearch] = useState<string>('');
  const [error, setError] = useState<string>('');

  // Extract authentic batches from Even Semester 2026 data grouped by semester
  const semesterOptions = EVEN_SEM_2026_DATA.semesterOptions;

  // Auto-detect year and semester from enrollment number prefix
  useEffect(() => {
    const clean = enrollmentNo.trim();
    if (clean.length >= 2) {
      const prefix = clean.substring(0, 2);
      if (prefix === '25') {
        setSelectedSemesterId('btech_2');
      } else if (prefix === '24') {
        setSelectedSemesterId('btech_4');
      } else if (prefix === '23') {
        setSelectedSemesterId('btech_6');
      } else if (prefix === '22') {
        setSelectedSemesterId('btech_8');
      }
    }
  }, [enrollmentNo]);

  // Available batches for currently selected semester
  const availableBatches = useMemo(() => {
    const set = new Set<string>();
    EVEN_SEM_2026_DATA.sessions
      .filter(s => s.semesterId === selectedSemesterId)
      .forEach(s => {
        s.batches.forEach(b => {
          const clean = b.replace(/\]$/, '').trim();
          if (clean && clean.length >= 2 && !['AND', '&', 'DLC'].includes(clean.toUpperCase())) {
            set.add(clean);
          }
        });
      });
    return Array.from(set).sort();
  }, [selectedSemesterId]);

  // Quick popular batches for 1-click chip selection
  const quickBatches = useMemo(() => {
    return availableBatches.slice(0, 8);
  }, [availableBatches]);

  // Filtered batches list if searching
  const displayedBatches = useMemo(() => {
    if (!batchSearch.trim()) return availableBatches;
    return availableBatches.filter(b => b.toLowerCase().includes(batchSearch.toLowerCase().trim()));
  }, [availableBatches, batchSearch]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanRoll = enrollmentNo.trim().toUpperCase();
    const cleanBatch = selectedBatch.trim().toUpperCase();

    if (!cleanRoll) {
      setError('Please enter your Student Enrollment Number (e.g. 24103014).');
      return;
    }

    if (!cleanBatch) {
      setError('Please select or specify your assigned Batch (e.g. 24A17).');
      return;
    }

    setError('');
    const profile: StudentProfile = {
      enrollmentNo: cleanRoll,
      batch: cleanBatch,
      semesterId: selectedSemesterId,
      name: studentName.trim() || undefined,
      isGuest: false
    };

    saveStudentProfile(profile);
    if (onClose) onClose();
  };

  const handleGuestEntry = () => {
    const guestProfile: StudentProfile = {
      enrollmentNo: 'GUEST',
      batch: '24A17',
      semesterId: 'btech_4',
      name: 'Guest Visitor',
      isGuest: true
    };
    saveStudentProfile(guestProfile);
    if (onClose) onClose();
  };

  const handleApplyPreset = (presetRoll: string, presetBatch: string, presetSem: string, presetName: string) => {
    setEnrollmentNo(presetRoll);
    setSelectedBatch(presetBatch);
    setSelectedSemesterId(presetSem);
    setStudentName(presetName);
    setError('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header with official JUIT branding */}
        <div className="bg-[#0B1E36] p-6 sm:p-7 text-white relative overflow-hidden border-b border-blue-900/60">
          <div className="absolute right-0 top-0 bottom-0 w-64 bg-gradient-to-l from-blue-600/15 to-transparent pointer-events-none" />

          <div className="relative z-10 flex items-start justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-white p-1 ring-2 ring-blue-400/40 shadow-md flex items-center justify-center overflow-hidden flex-shrink-0">
                <img
                  src="/src/assets/images/juit_official_logo_v4_final_1789206375553.jpg"
                  alt="JUIT Logo"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-blue-500/20 text-sky-300 border border-blue-400/30 mb-1">
                  <Sparkles className="w-3 h-3 text-sky-400" />
                  <span>JUIT Student Gateway</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                  Jaypee University of IT
                </h2>
                <p className="text-xs text-blue-200/80">
                  Waknaghat • Even Semester 2026 Portal
                </p>
              </div>
            </div>

            {!isBlocking && onClose && (
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-7 space-y-6">
          <div className="space-y-1">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {studentProfile && !studentProfile.isGuest ? 'Update Student Information' : 'Setup your JUIT Student Profile'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              Personalize your timetable, batch slots, and campus AI buddy. Skip the manual search struggle 🎓
            </p>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-2">
              <Info className="w-4 h-4 text-rose-500 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Enrollment Number Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center justify-between">
                <span>Enrollment Number (Roll No):</span>
                <span className="text-[11px] text-blue-600 dark:text-blue-400 font-normal">
                  e.g. 24103014 or 23103001
                </span>
              </label>
              <div className="relative">
                <GraduationCap className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="input-student-enrollment"
                  type="text"
                  value={enrollmentNo}
                  onChange={(e) => setEnrollmentNo(e.target.value.toUpperCase())}
                  placeholder="Enter JUIT Enrollment No (e.g. 24103014)"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono font-bold text-sm sm:text-base rounded-xl pl-10 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-600 uppercase"
                  required
                />
              </div>
              {enrollmentNo.length >= 2 && (
                <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>
                    Detected: {
                      enrollmentNo.startsWith('25') ? '1st Year (2nd Semester 2026)' :
                      enrollmentNo.startsWith('24') ? '2nd Year (4th Semester 2026)' :
                      enrollmentNo.startsWith('23') ? '3rd Year (6th Semester 2026)' :
                      enrollmentNo.startsWith('22') ? '4th Year (8th Semester 2026)' :
                      'JUIT Student'
                    }
                  </span>
                </div>
              )}
            </div>

            {/* Semester Selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                Current Semester:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {semesterOptions.slice(0, 4).map((sem) => (
                  <button
                    type="button"
                    key={sem.id}
                    onClick={() => setSelectedSemesterId(sem.id)}
                    className={`p-2 rounded-xl text-xs font-bold border transition-all text-center ${
                      selectedSemesterId === sem.id
                        ? 'bg-[#0B2545] text-white border-blue-900 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div>{sem.name.replace('B.Tech ', '')}</div>
                    <div className="text-[10px] opacity-75 font-normal">{sem.year}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Batch Selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center justify-between">
                <span>Assigned Batch:</span>
                <span className="text-[11px] text-blue-600 dark:text-blue-400 font-semibold">
                  Selected: {selectedBatch || 'None'}
                </span>
              </label>

              {/* Quick Batch Pills */}
              {quickBatches.length > 0 && (
                <div className="flex flex-wrap items-center gap-1.5 pb-1">
                  {quickBatches.map((b) => (
                    <button
                      type="button"
                      key={b}
                      onClick={() => setSelectedBatch(b)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                        selectedBatch === b
                          ? 'bg-blue-700 text-white shadow-sm ring-1 ring-blue-500'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              )}

              {/* Dropdown or Custom Batch Input */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="relative">
                  <select
                    id="select-batch-entry"
                    value={selectedBatch}
                    onChange={(e) => setSelectedBatch(e.target.value)}
                    className="w-full appearance-none bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-semibold text-xs sm:text-sm rounded-xl px-3.5 py-2.5 pr-8 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  >
                    <option value="">Choose from all batches...</option>
                    {availableBatches.map((b) => (
                      <option key={b} value={b}>
                        Batch: {b}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>

                <input
                  type="text"
                  value={selectedBatch}
                  onChange={(e) => setSelectedBatch(e.target.value.toUpperCase())}
                  placeholder="Or type custom batch code"
                  className="bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono text-xs sm:text-sm rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-600 uppercase"
                />
              </div>
            </div>

            {/* Optional Student Name */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
                Student Name / Preferred Name (Optional):
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="e.g. Paul or Jayashree"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-xs sm:text-sm rounded-xl pl-10 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            {/* Quick Demo Presets */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Skip typing? Try these demo profiles:
              </span>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleApplyPreset('24103014', '24A17', 'btech_4', 'Jayashree')}
                  className="px-2.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/40 text-xs font-semibold transition-colors"
                >
                  ⚡ Demo: 24103014 (Batch 24A17 • 4th Sem)
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('25103042', '25BT08', 'btech_2', 'Rahul')}
                  className="px-2.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/40 text-xs font-semibold transition-colors"
                >
                  ⚡ Demo: 25103042 (Batch 25BT08 • 2nd Sem)
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('23103005', '23A12', 'btech_6', 'Aman')}
                  className="px-2.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/40 text-xs font-semibold transition-colors"
                >
                  ⚡ Demo: 23103005 (Batch 23A12 • 6th Sem)
                </button>
              </div>
            </div>

            {/* Submit & Action Buttons */}
            <div className="pt-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleGuestEntry}
                className="px-4 py-2.5 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white text-xs font-semibold transition-colors text-center"
              >
                Skip / Continue as Guest
              </button>

              <div className="flex items-center gap-2">
                {studentProfile && !isBlocking && (
                  <button
                    type="button"
                    onClick={() => {
                      logoutStudent();
                      if (onClose) onClose();
                    }}
                    className="px-3.5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-rose-600 text-xs font-semibold transition-colors flex items-center gap-1.5"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Reset</span>
                  </button>
                )}

                <button
                  id="btn-submit-student-entry"
                  type="submit"
                  className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-[#0B2545] hover:bg-blue-900 text-white font-bold text-xs sm:text-sm shadow-md shadow-blue-950/50 transition-all"
                >
                  <span>Enter Campus Portal</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </form>
        </div>

      </div>
    </div>
  );
};
