import React from 'react';
import { 
  Settings as SettingsIcon, 
  Moon, 
  Sun, 
  Monitor, 
  Type, 
  Zap, 
  Contrast, 
  Globe, 
  Clock, 
  Calendar,
  RotateCcw,
  CheckCircle2,
  Info
} from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { BackButton } from './common/BackButton';
import { motion } from 'motion/react';

export const SettingsView: React.FC = () => {
  const { 
    settings, 
    setTheme, 
    setAccessibility, 
    resetSettings, 
    effectiveTheme, 
    currentTime, 
    timeZone 
  } = useSettings();

  const handleReset = () => {
    if (window.confirm('Reset all appearance and accessibility settings to default?')) {
      resetSettings();
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat(navigator.language, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(date);
  };

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat(navigator.language, {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(date);
  };

  return (
    <div className="flex-1 overflow-y-auto pb-24">
      <div className="max-w-3xl mx-auto px-4 pt-6 space-y-8">
        
        {/* Header */}
        <div className="space-y-4">
          <BackButton />
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-900/20">
              <SettingsIcon className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Settings</h1>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Personalize your JUIT Guide experience</p>
            </div>
          </div>
        </div>

        {/* Appearance */}
        <section className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500 flex items-center gap-2">
            <Monitor className="w-4 h-4" />
            Appearance
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { id: 'system', label: 'System Default', icon: Monitor },
              { id: 'light', label: 'Light', icon: Sun },
              { id: 'dark', label: 'Dark', icon: Moon }
            ].map(mode => (
              <button
                key={mode.id}
                onClick={() => setTheme(mode.id as any)}
                className={`flex flex-col items-center gap-3 p-4 rounded-2xl border transition-all ${
                  settings.theme === mode.id
                    ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-500 text-blue-600 dark:text-blue-400 ring-4 ring-blue-500/10'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <mode.icon className="w-6 h-6" />
                <span className="text-sm font-bold">{mode.label}</span>
                {settings.theme === mode.id && <CheckCircle2 className="w-4 h-4" />}
              </button>
            ))}
          </div>
        </section>

        {/* Accessibility */}
        <section className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500 flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Accessibility
          </h2>
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden shadow-sm">
            
            {/* Text Size */}
            <div className="p-5 space-y-3">
              <div className="flex items-center gap-3">
                <Type className="w-5 h-5 text-slate-400" />
                <div>
                  <p className="text-sm font-bold dark:text-white">Text Size</p>
                  <p className="text-xs text-slate-500">Adjust the global font size of the application</p>
                </div>
              </div>
              <div className="flex gap-2">
                {['default', 'large', 'extra-large'].map(size => (
                  <button
                    key={size}
                    onClick={() => setAccessibility({ textSize: size as any })}
                    className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold capitalize transition-all ${
                      settings.accessibility.textSize === size
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Reduced Motion */}
            <div className="p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Zap className="w-5 h-5 text-slate-400" />
                <div>
                  <p className="text-sm font-bold dark:text-white">Reduced Motion</p>
                  <p className="text-xs text-slate-500">Minimize animations and transitions</p>
                </div>
              </div>
              <select
                value={settings.accessibility.reducedMotion}
                onChange={(e) => setAccessibility({ reducedMotion: e.target.value as any })}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="system">System Default</option>
                <option value="on">On</option>
                <option value="off">Off</option>
              </select>
            </div>

            {/* High Contrast */}
            <div className="p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Contrast className="w-5 h-5 text-slate-400" />
                <div>
                  <p className="text-sm font-bold dark:text-white">High Contrast</p>
                  <p className="text-xs text-slate-500">Increase visual contrast for better visibility</p>
                </div>
              </div>
              <select
                value={settings.accessibility.highContrast}
                onChange={(e) => setAccessibility({ highContrast: e.target.value as any })}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-1.5 text-xs font-bold dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="system">System Default</option>
                <option value="on">On</option>
                <option value="off">Off</option>
              </select>
            </div>
          </div>
        </section>

        {/* Device Info */}
        <section className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500 flex items-center gap-2">
            <Info className="w-4 h-4" />
            System & Device Information
          </h2>
          <div className="bg-slate-100 dark:bg-slate-950 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                  <Globe className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Device Timezone</span>
                </div>
                <p className="text-sm font-bold dark:text-white">{timeZone}</p>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                  <Clock className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Current Time</span>
                </div>
                <p className="text-sm font-bold dark:text-white">{formatTime(currentTime)}</p>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                  <Calendar className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">System Date</span>
                </div>
                <p className="text-sm font-bold dark:text-white">{formatDate(currentTime)}</p>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                  <Monitor className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase tracking-wider">Academic Year</span>
                </div>
                <p className="text-sm font-bold dark:text-white text-blue-600 dark:text-blue-400">{settings.academicYear}</p>
              </div>
            </div>
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
              <p className="text-[10px] text-slate-500 leading-relaxed italic">
                * All date and time information is detected automatically from your browser's Locale and Timezone settings. JUIT academic data is based on the verified university calendar.
              </p>
            </div>
          </div>
        </section>

        {/* Reset */}
        <div className="pt-4">
          <button
            onClick={handleReset}
            className="w-full py-4 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-bold flex items-center justify-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-900 hover:border-slate-300 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            Reset Appearance & Accessibility
          </button>
        </div>

        <div className="text-center text-[10px] text-slate-400 py-4">
          JUIT Guide Version 2.0.0 (Dynamic Engine)
        </div>

      </div>
    </div>
  );
};
