import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import {
  Sparkles,
  Utensils,
  Shirt,
  CalendarDays,
  BookOpen,
  GraduationCap,
  WifiOff,
  CheckCircle2,
  ShieldCheck,
  Building2,
  Settings
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';

interface NavbarProps {
  onOpenAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAdmin }) => {
  const {
    isOffline,
    setIsChatOpen,
    setChatInitialPrompt,
    studentProfile,
    setIsProfileModalOpen
  } = useCampus();

  const handleOpenChat = () => {
    setChatInitialPrompt(null);
    setIsChatOpen(true);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0B1E36]/95 backdrop-blur-md border-b border-[#142C4E] text-white transition-all shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Logo & Title with JUIT Emblem */}
          <Link to="/" id="nav-brand-logo" className="flex items-center gap-3 group">
              <div className="relative w-11 h-11 rounded-xl bg-white p-0.5 ring-2 ring-blue-400/40 shadow-md group-hover:scale-105 transition-transform flex-shrink-0 overflow-hidden flex items-center justify-center">
                <img
                  src="/src/assets/images/juit_official_logo_v4_final_1789206375553.jpg"
                  alt="JUIT Logo"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain rounded-lg"
                />
              </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-blue-100 to-sky-300 bg-clip-text text-transparent">
                  JUIT Guide
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-900/80 text-blue-200 border border-blue-600/50">
                  Campus
                </span>
              </div>
              <p className="text-[11px] text-slate-300 font-medium hidden sm:block">
                Jaypee University of Information Technology, Waknaghat
              </p>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 text-sm font-medium">
            <NavLink
              to="/"
              end
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#142C4E] text-sky-300 font-semibold border border-blue-500/30'
                    : 'text-slate-200 hover:text-white hover:bg-[#142C4E]/60'
                }`
              }
            >
              Home
            </NavLink>
            <NavLink
              to="/dining"
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#142C4E] text-sky-300 font-semibold border border-blue-500/30'
                    : 'text-slate-200 hover:text-white hover:bg-[#142C4E]/60'
                }`
              }
            >
              <Utensils className="w-4 h-4" />
              Dining & Mess
            </NavLink>
            <NavLink
              to="/laundry"
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#142C4E] text-sky-300 font-semibold border border-blue-500/30'
                    : 'text-slate-200 hover:text-white hover:bg-[#142C4E]/60'
                }`
              }
            >
              <Shirt className="w-4 h-4" />
              Laundry
            </NavLink>
            <NavLink
              to="/timetable"
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#142C4E] text-sky-300 font-semibold border border-blue-500/30'
                    : 'text-slate-200 hover:text-white hover:bg-[#142C4E]/60'
                }`
              }
            >
              <CalendarDays className="w-4 h-4" />
              Timetable & Map
            </NavLink>
            <NavLink
              to="/campus-lynx"
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#142C4E] text-sky-300 font-semibold border border-blue-500/30'
                    : 'text-slate-200 hover:text-white hover:bg-[#142C4E]/60'
                }`
              }
            >
              <BookOpen className="w-4 h-4" />
              Lynx Guide
            </NavLink>
            <NavLink
              to="/faculty"
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg transition-colors flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#142C4E] text-sky-300 font-semibold border border-blue-500/30'
                    : 'text-slate-200 hover:text-white hover:bg-[#142C4E]/60'
                }`
              }
            >
              <GraduationCap className="w-4 h-4" />
              Faculty
            </NavLink>
          </nav>

          {/* Right actions: Student Profile Pill + Online Badge + Chat Button + Admin */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Student ID & Batch button */}
            <button
              id="btn-navbar-student-profile"
              onClick={() => setIsProfileModalOpen(true)}
              title="Click to view or change enrollment number & batch"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#142C4E] hover:bg-[#1B3A66] text-white font-medium text-xs border border-blue-500/40 transition-all shadow-sm group"
            >
              <GraduationCap className="w-3.5 h-3.5 text-sky-300 group-hover:rotate-12 transition-transform" />
              {studentProfile && !studentProfile.isGuest ? (
                <div className="flex items-center gap-1.5">
                  <span className="font-mono font-bold text-sky-200 text-xs">
                    {studentProfile.enrollmentNo}
                  </span>
                  <span className="hidden sm:inline-block px-1.5 py-0.2 rounded text-[10px] font-extrabold bg-blue-900/80 text-sky-300 border border-blue-500/40 uppercase">
                    {studentProfile.batch}
                  </span>
                </div>
              ) : (
                <span className="text-xs text-sky-200 font-semibold">Student ID</span>
              )}
            </button>

            {/* Status indicator */}
            {isOffline ? (
              <span className="hidden md:inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-950/60 border border-amber-600/30 text-amber-300">
                <WifiOff className="w-3.5 h-3.5" />
                Offline
              </span>
            ) : (
              <span className="hidden md:inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-950/50 border border-emerald-600/30 text-emerald-400">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Live JUIT
              </span>
            )}

            {/* AI PARTHSAARATHI trigger */}
            <button
              id="btn-open-juit-buddy-nav"
              onClick={handleOpenChat}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-600 hover:to-indigo-600 text-white font-medium text-xs sm:text-sm shadow-md shadow-blue-950/50 border border-blue-400/30 active:scale-95 transition-all"
            >
              <Sparkles className="w-4 h-4 text-sky-200 animate-pulse" />
              <span className="font-semibold hidden sm:inline">PARTHSAARATHI</span>
            </button>

            {/* Settings access */}
            <Link
              to="/settings"
              id="btn-open-settings"
              title="Application Settings"
              className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-[#142C4E] transition-colors"
            >
              <Settings className="w-5 h-5" />
            </Link>

            {/* Admin access */}
            <button
              id="btn-open-admin-dialog"
              onClick={onOpenAdmin}
              title="Admin Data Manager"
              className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-[#142C4E] transition-colors"
            >
              <ShieldCheck className="w-5 h-5" />
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
