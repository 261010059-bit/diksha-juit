import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  Save, 
  X, 
  Upload, 
  CheckCircle2, 
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Eye,
  Star,
  Zap,
  Globe,
  Instagram,
  Mail,
  Phone
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BackButton } from './common/BackButton';
import { Club } from '../types';

import { useCampus } from '../context/CampusContext';

export const ClubsAdminView: React.FC = () => {
  const { data, updateCampusSection, isLoading: contextLoading } = useCampus();
  const [clubs, setClubs] = useState<Club[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editingClub, setEditingClub] = useState<Partial<Club> | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [passcode, setPasscode] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (data.clubs) {
      setClubs(data.clubs);
    }
  }, [data.clubs]);

  const handleAuthorize = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode === 'juit2026') {
      setIsAuthorized(true);
      setFeedback(null);
    } else {
      setFeedback({ type: 'error', message: 'Invalid Admin Passcode' });
    }
  };

  const handleCreateNew = () => {
    const newClub: Partial<Club> = {
      id: 'club-' + Date.now(),
      name: '',
      slug: '',
      description: '',
      categories: [],
      activities: [],
      keywords: [],
      logoUrl: null,
      logoAlt: '',
      logoVerified: false,
      recruitmentStatus: 'unknown',
      isActive: true,
      isFeatured: false,
      isNew: true,
      joiningMethod: '',
      lastVerified: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setEditingClub(newClub);
    setIsEditing(true);
  };

  const handleEdit = (club: Club) => {
    setEditingClub({ ...club });
    setIsEditing(true);
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this club?')) return;
    
    const updatedClubs = clubs.filter(c => c.id !== id);
    setIsSaving(true);
    const res = await updateCampusSection('clubs', updatedClubs, passcode);
    setIsSaving(false);
    
    if (res.success) {
      setFeedback({ type: 'success', message: 'Club deleted successfully!' });
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingClub) return;

    setIsSaving(true);
    
    let updatedClubs: Club[];
    const now = new Date().toISOString();
    
    const clubToSave: Club = {
      ...editingClub as Club,
      updatedAt: now,
      lastVerified: now
    };

    if (clubs.find(c => c.id === clubToSave.id)) {
      updatedClubs = clubs.map(c => c.id === clubToSave.id ? clubToSave : c);
    } else {
      updatedClubs = [...clubs, clubToSave];
    }

    const res = await updateCampusSection('clubs', updatedClubs, passcode);
    setIsSaving(false);
    
    if (res.success) {
      setFeedback({ type: 'success', message: 'Club saved successfully!' });
      setIsEditing(false);
      setEditingClub(null);
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  const filteredClubs = clubs.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.slug.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!isAuthorized) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-6">
        <div className="w-20 h-20 rounded-3xl bg-blue-600 flex items-center justify-center text-white shadow-xl shadow-blue-900/40">
          <ShieldCheck className="w-10 h-10" />
        </div>
        <div className="text-center space-y-2">
          <h1 className="text-2xl font-black dark:text-white">Club Admin Portal</h1>
          <p className="text-slate-500 text-sm">Verify your administrative identity to manage JUIT clubs.</p>
        </div>
        <form onSubmit={handleAuthorize} className="w-full max-w-sm space-y-4">
          <input
            type="password"
            placeholder="Enter Admin Passcode"
            value={passcode}
            onChange={(e) => setPasscode(e.target.value)}
            className="w-full px-5 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-lg font-mono tracking-widest focus:ring-2 focus:ring-blue-600 focus:outline-none"
          />
          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-lg shadow-blue-900/20 transition-all active:scale-95"
          >
            Authorize Access
          </button>
          {feedback?.type === 'error' && (
            <p className="text-rose-500 text-xs font-bold text-center animate-shake">{feedback.message}</p>
          )}
        </form>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto pb-24">
      <div className="max-w-6xl mx-auto px-4 pt-6 space-y-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <BackButton />
            <div>
              <h1 className="text-2xl font-black dark:text-white">Manage Clubs</h1>
              <p className="text-xs text-slate-500">Authorized Control Panel</p>
            </div>
          </div>
          <button
            onClick={handleCreateNew}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold shadow-md shadow-blue-900/20"
          >
            <Plus className="w-4 h-4" />
            Add New Club
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filter by name, category, status..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm"
            />
          </div>
        </div>

        {/* Club List Table */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Club Name</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Recruitment</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {clubs.length > 0 ? (
                clubs.map(club => (
                  <tr key={club.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center overflow-hidden border border-slate-200 dark:border-slate-700">
                          {club.logoUrl ? <img src={club.logoUrl} className="w-full h-full object-contain" /> : <span className="text-[10px] font-black">{club.name[0]}</span>}
                        </div>
                        <div>
                          <p className="text-sm font-bold dark:text-white">{club.name}</p>
                          <p className="text-[10px] text-slate-400">{club.slug}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        club.recruitmentStatus === 'open' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                      }`}>
                        {club.recruitmentStatus.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5">
                        <Star className={`w-3.5 h-3.5 ${club.isFeatured ? 'text-amber-500 fill-amber-500' : 'text-slate-300'}`} />
                        <Zap className={`w-3.5 h-3.5 ${club.isNew ? 'text-blue-500 fill-blue-500' : 'text-slate-300'}`} />
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => handleEdit(club)} className="p-2 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 text-slate-400 hover:text-blue-600 transition-colors">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(club.id)} className="p-2 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-900/20 text-slate-400 hover:text-rose-600 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-slate-400 text-sm">
                    No clubs found in database. Start by adding one.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit/Create Modal */}
      <AnimatePresence>
        {isEditing && editingClub && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 w-full max-w-4xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="px-6 py-4 bg-[#0B1E36] text-white flex items-center justify-between">
                <h3 className="font-bold">Club Configuration</h3>
                <button onClick={() => setIsEditing(false)}><X className="w-5 h-5" /></button>
              </div>
              <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Basic Info */}
                  <div className="space-y-4">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400">Basic Information</label>
                    <input
                      type="text"
                      placeholder="Club Name (e.g. SIAM JUIT)"
                      required
                      value={editingClub.name || ''}
                      onChange={e => setEditingClub({ ...editingClub, name: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm"
                    />
                    <input
                      type="text"
                      placeholder="Slug (e.g. siam-juit)"
                      required
                      value={editingClub.slug || ''}
                      onChange={e => setEditingClub({ ...editingClub, slug: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm font-mono"
                    />
                    <textarea
                      placeholder="Short Description"
                      rows={4}
                      value={editingClub.description || ''}
                      onChange={e => setEditingClub({ ...editingClub, description: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm"
                    />
                  </div>

                  {/* Logo & Flags */}
                  <div className="space-y-4">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400">Branding & Metadata</label>
                    <input
                      type="url"
                      placeholder="Logo URL (Direct Image Link)"
                      value={editingClub.logoUrl || ''}
                      onChange={e => setEditingClub({ ...editingClub, logoUrl: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm"
                    />
                    <div className="flex flex-wrap gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={editingClub.isFeatured || false}
                          onChange={e => setEditingClub({ ...editingClub, isFeatured: e.target.checked })}
                          className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-600" 
                        />
                        <span className="text-sm dark:text-slate-300">Featured Club</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={editingClub.isNew || false}
                          onChange={e => setEditingClub({ ...editingClub, isNew: e.target.checked })}
                          className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-600" 
                        />
                        <span className="text-sm dark:text-slate-300">New in JUIT</span>
                      </label>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase text-slate-400">Recruitment Status</label>
                      <select 
                        value={editingClub.recruitmentStatus || 'unknown'}
                        onChange={e => setEditingClub({ ...editingClub, recruitmentStatus: e.target.value as any })}
                        className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm"
                      >
                        <option value="open">🟢 Open</option>
                        <option value="closed">⚪ Closed</option>
                        <option value="unknown">🟡 Unknown</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div className="space-y-4">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400">Joining Information</label>
                    <textarea
                      placeholder="How to join? (e.g. Join through annual recruitment drive...)"
                      rows={3}
                      value={editingClub.joiningMethod || ''}
                      onChange={e => setEditingClub({ ...editingClub, joiningMethod: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm"
                    />
                    <input
                      type="url"
                      placeholder="Official Join Link (e.g. Google Form)"
                      value={editingClub.joinLink || ''}
                      onChange={e => setEditingClub({ ...editingClub, joinLink: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm"
                    />
                  </div>
                  <div className="space-y-4">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400">Contact & Socials</label>
                    <input
                      type="text"
                      placeholder="Instagram Handle (URL)"
                      value={editingClub.instagramUrl || ''}
                      onChange={e => setEditingClub({ ...editingClub, instagramUrl: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm"
                    />
                    <input
                      type="email"
                      placeholder="Official Club Email"
                      value={editingClub.officialEmail || ''}
                      onChange={e => setEditingClub({ ...editingClub, officialEmail: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 text-sm"
                    />
                  </div>
                </div>
                
                <div className="flex justify-end gap-3 pt-6 border-t border-slate-100 dark:border-slate-800">
                  <button type="button" onClick={() => setIsEditing(false)} className="px-6 py-2 rounded-xl text-sm font-bold text-slate-500">Cancel</button>
                  <button 
                    type="submit" 
                    disabled={isSaving}
                    className="px-8 py-2 rounded-xl bg-blue-600 text-white font-bold shadow-lg shadow-blue-900/20 disabled:opacity-50"
                  >
                    {isSaving ? 'Saving...' : 'Save Club Record'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
