import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Instagram, 
  Globe, 
  Mail, 
  Phone, 
  MessageSquare, 
  Calendar, 
  Users, 
  CheckCircle2, 
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Info,
  Layers,
  Zap
} from 'lucide-react';
import { motion } from 'motion/react';
import { BackButton } from './common/BackButton';
import { LoadingState } from './common/LoadingState';
import { useCampus } from '../context/CampusContext';
import { Club } from '../types';

export const ClubDetailView: React.FC = () => {
  const { clubId } = useParams<{ clubId: string }>();
  const navigate = useNavigate();
  const { data, isLoading } = useCampus();
  const [club, setClub] = useState<Club | null>(null);

  useEffect(() => {
    if (clubId && data.clubs) {
      const found = data.clubs.find(c => c.slug === clubId);
      setClub(found || null);
    }
  }, [clubId, data.clubs]);

  if (isLoading) return <LoadingState message="Loading club details..." />;
  
  if (!club) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-4">
        <AlertCircle className="w-16 h-16 text-rose-500" />
        <h2 className="text-xl font-bold dark:text-white">Club not found</h2>
        <p className="text-slate-500 text-center max-w-xs">We couldn't find the community you're looking for. It might have moved or been renamed.</p>
        <BackButton />
      </div>
    );
  }

  const statusColors = {
    open: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
    closed: 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/20',
    unknown: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20'
  };

  return (
    <div className="flex-1 overflow-y-auto pb-24">
      {/* Hero Section */}
      <div className="bg-[#0B1E36] text-white pt-6 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-600/10 to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto px-4 space-y-6 relative z-10">
          <BackButton />
          
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 sm:gap-8">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-24 h-24 sm:w-32 sm:h-32 rounded-3xl bg-white p-3 shadow-2xl shadow-blue-900/40 border border-blue-400/20 flex-shrink-0 flex items-center justify-center overflow-hidden"
            >
              {club.logoUrl ? (
                <img src={club.logoUrl} alt={club.logoAlt} className="w-full h-full object-contain" />
              ) : (
                <div className="text-3xl font-black text-slate-300 uppercase tracking-tighter">
                  {club.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                </div>
              )}
            </motion.div>
            
            <div className="text-center sm:text-left space-y-3">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                {club.categories.map(cat => (
                  <span key={cat} className="px-2.5 py-0.5 rounded-full bg-blue-500/20 border border-blue-400/30 text-[10px] font-bold uppercase tracking-wider text-blue-100">
                    {cat}
                  </span>
                ))}
              </div>
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight">{club.name}</h1>
              <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-bold ${statusColors[club.recruitmentStatus]}`}>
                {club.recruitmentStatus === 'open' ? '🟢 Recruitment Open' : club.recruitmentStatus === 'closed' ? '⚪ Currently Closed' : '🟡 Check with the club'}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 -mt-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <section className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
              <div className="space-y-4">
                <h2 className="text-xl font-bold dark:text-white flex items-center gap-2">
                  <Info className="w-5 h-5 text-blue-500" />
                  What is it?
                </h2>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-sm sm:text-base">
                  {club.description}
                </p>
              </div>

              <div className="space-y-4">
                <h2 className="text-xl font-bold dark:text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-blue-500" />
                  What can I do here?
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {club.activities.map((activity, idx) => (
                    <div key={idx} className="flex items-center gap-2.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                      <span className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-300">{activity}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <h2 className="text-xl font-bold dark:text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-500" />
                  Who can join?
                </h2>
                <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base">
                  {club.eligibility || 'Contact the club for eligibility criteria.'}
                </p>
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                <h2 className="text-xl font-bold dark:text-white">How do I join?</h2>
                <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-800 text-sm">
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                    {club.joiningMethod}
                  </p>
                  {club.joinLink && (
                    <a 
                      href={club.joinLink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-colors"
                    >
                      Apply Now
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            </section>
          </div>

          {/* Sidebar / Links */}
          <div className="space-y-6">
            <section className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
              <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-xs">Official Links</h3>
              <div className="space-y-3">
                {club.websiteUrl && (
                  <a href={club.websiteUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-3 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group">
                    <div className="flex items-center gap-3">
                      <Globe className="w-5 h-5 text-slate-400 group-hover:text-blue-500" />
                      <span className="text-sm font-medium dark:text-slate-300">Official Website</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300" />
                  </a>
                )}
                {club.instagramUrl && (
                  <a href={club.instagramUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-3 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group">
                    <div className="flex items-center gap-3">
                      <Instagram className="w-5 h-5 text-slate-400 group-hover:text-pink-500" />
                      <span className="text-sm font-medium dark:text-slate-300">Instagram</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300" />
                  </a>
                )}
                {club.discordUrl && (
                  <a href={club.discordUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-3 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group">
                    <div className="flex items-center gap-3">
                      <MessageSquare className="w-5 h-5 text-slate-400 group-hover:text-indigo-500" />
                      <span className="text-sm font-medium dark:text-slate-300">Discord</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300" />
                  </a>
                )}
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
                <h3 className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-xs">Contact Information</h3>
                <div className="space-y-4">
                  {club.officialEmail && (
                    <div className="flex items-center gap-3">
                      <Mail className="w-4 h-4 text-slate-400" />
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Club Email</p>
                        <a href={`mailto:${club.officialEmail}`} className="text-sm dark:text-slate-300 hover:text-blue-500 transition-colors">{club.officialEmail}</a>
                      </div>
                    </div>
                  )}
                  {club.coordinatorName && (
                    <div className="flex items-center gap-3">
                      <Users className="w-4 h-4 text-slate-400" />
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Faculty Coordinator</p>
                        <p className="text-sm dark:text-slate-300 font-semibold">{club.coordinatorName}</p>
                        {club.coordinatorEmail && (
                          <a href={`mailto:${club.coordinatorEmail}`} className="text-xs text-slate-500 hover:text-blue-500">{club.coordinatorEmail}</a>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2 text-[10px] text-slate-400">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  <span>Verified: {new Date(club.lastVerified).toLocaleDateString()}</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">Source: {club.logoSource || 'Internal Verification'}</p>
              </div>
            </section>
          </div>

        </div>
      </div>
    </div>
  );
};
