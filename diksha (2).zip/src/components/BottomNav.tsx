import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Home,
  Utensils,
  Shirt,
  CalendarDays,
  BookOpen,
  Settings
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  return (
    <nav aria-label="Mobile Navigation" className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0B1E36]/95 backdrop-blur-lg border-t border-[#142C4E] px-2 py-2">
      <div className="flex items-center justify-around max-w-lg mx-auto">
        
        <NavLink
          to="/"
          end
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 flex-1 py-1 px-2 rounded-xl transition-all ${
              isActive
                ? 'text-sky-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          {({ isActive }) => (
            <>
              <div className={`p-1 rounded-lg ${isActive ? 'bg-sky-500/20 text-sky-300' : ''}`}>
                <Home className="w-5 h-5" />
              </div>
              <span className="text-[10px] tracking-tight">Home</span>
            </>
          )}
        </NavLink>

        <NavLink
          to="/dining"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 flex-1 py-1 px-2 rounded-xl transition-all ${
              isActive
                ? 'text-sky-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          {({ isActive }) => (
            <>
              <div className={`p-1 rounded-lg ${isActive ? 'bg-sky-500/20 text-sky-300' : ''}`}>
                <Utensils className="w-5 h-5" />
              </div>
              <span className="text-[10px] tracking-tight">Dining</span>
            </>
          )}
        </NavLink>

        <NavLink
          to="/laundry"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 flex-1 py-1 px-2 rounded-xl transition-all ${
              isActive
                ? 'text-sky-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          {({ isActive }) => (
            <>
              <div className={`p-1 rounded-lg ${isActive ? 'bg-sky-500/20 text-sky-300' : ''}`}>
                <Shirt className="w-5 h-5" />
              </div>
              <span className="text-[10px] tracking-tight">Laundry</span>
            </>
          )}
        </NavLink>

        <NavLink
          to="/timetable"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 flex-1 py-1 px-2 rounded-xl transition-all ${
              isActive
                ? 'text-sky-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          {({ isActive }) => (
            <>
              <div className={`p-1 rounded-lg ${isActive ? 'bg-sky-500/20 text-sky-300' : ''}`}>
                <CalendarDays className="w-5 h-5" />
              </div>
              <span className="text-[10px] tracking-tight">Schedule</span>
            </>
          )}
        </NavLink>

        <NavLink
          to="/campus-lynx"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 flex-1 py-1 px-2 rounded-xl transition-all ${
              isActive
                ? 'text-sky-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          {({ isActive }) => (
            <>
              <div className={`p-1 rounded-lg ${isActive ? 'bg-sky-500/20 text-sky-300' : ''}`}>
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-[10px] tracking-tight">Lynx</span>
            </>
          )}
        </NavLink>
        
        <NavLink
          to="/settings"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-1 flex-1 py-1 px-2 rounded-xl transition-all ${
              isActive
                ? 'text-sky-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          {({ isActive }) => (
            <>
              <div className={`p-1 rounded-lg ${isActive ? 'bg-sky-500/20 text-sky-300' : ''}`}>
                <Settings className="w-5 h-5" />
              </div>
              <span className="text-[10px] tracking-tight">Settings</span>
            </>
          )}
        </NavLink>

      </div>
    </nav>
  );
};
