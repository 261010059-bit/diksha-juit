import React, { useState } from 'react';
import {
  Shirt,
  Clock,
  MapPin,
  Phone,
  Coins,
  CheckCircle2,
  PlusCircle,
  Trash2,
  AlertCircle,
  Calendar,
  Sparkles,
  ArrowRight,
  HelpCircle
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { LaundryTrackerRecord } from '../types';
import { BackButton } from './common/BackButton';

export const LaundryView: React.FC = () => {
  const {
    data,
    laundryRecords,
    addLaundryRecord,
    updateLaundryStatus,
    deleteLaundryRecord,
    setIsChatOpen,
    setChatInitialPrompt
  } = useCampus();

  const [showAddForm, setShowAddForm] = useState(false);
  const [tokenNumber, setTokenNumber] = useState('');
  const [clothesCount, setClothesCount] = useState<number>(10);
  const [notes, setNotes] = useState('');

  // Auto calculate drop and expected date
  const todayStr = new Date().toISOString().split('T')[0];
  const expectedDateDefault = new Date(Date.now() + 48 * 3600 * 1000).toISOString().split('T')[0];
  const [dropDate, setDropDate] = useState(todayStr);
  const [expectedDate, setExpectedDate] = useState(expectedDateDefault);

  const handleSubmitRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenNumber.trim()) return;

    addLaundryRecord({
      tokenNumber: tokenNumber.trim().toUpperCase(),
      clothesCount: Number(clothesCount) || 1,
      dropDate,
      expectedDate,
      status: 'Dropped',
      notes: notes.trim()
    });

    setTokenNumber('');
    setNotes('');
    setShowAddForm(false);
  };

  const statusList: LaundryTrackerRecord['status'][] = ['Dropped', 'In Wash', 'Ready for Pickup', 'Collected'];

  const handleAskLaundry = () => {
    setChatInitialPrompt("What are the laundry rules, token lost procedure, and timings at JUIT?");
    setIsChatOpen(true);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* View Header with Back Navigation */}
      <div className="space-y-4">
        <BackButton />
        <div className="space-y-1">
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Laundry Service
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Track your wash cycles & token status 🧼
          </p>
        </div>
      </div>

      {/* Key Info Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center flex-shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Timings</p>
            <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">{data.laundry.timings}</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center flex-shrink-0">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Counter Location</p>
            <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">{data.laundry.location}</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center flex-shrink-0">
            <Coins className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Cost & Quota</p>
            <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">30 pcs/mo free in hostel</p>
            <p className="text-[11px] text-slate-400">₹10/piece beyond quota</p>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center flex-shrink-0">
            <Phone className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Manager & Incharge</p>
            <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">{data.laundry.contactPerson}</p>
            <p className="text-[11px] text-slate-400">Intercom Ext: 402</p>
          </div>
        </div>
      </div>

      {/* Step-by-Step Submission Process */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
          How Laundry Drop-off Works
        </h2>
        <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">
          Follow these 5 standardized steps to ensure your garments are securely tagged and safely returned.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
          {Array.isArray(data.laundry.process) ? (
            data.laundry.process.map((step, idx) => (
              <div
                key={idx}
                className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 flex flex-col justify-between"
              >
                <div>
                  <div className="w-8 h-8 rounded-xl bg-[#0B2545] text-white font-bold flex items-center justify-center text-sm mb-3 shadow-md shadow-blue-950/30">
                    {idx + 1}
                  </div>
                  <p className="text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-200 leading-relaxed">
                    {step.replace(/^\d+\.\s*/, '')}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-sm text-slate-700">{data.laundry.process}</p>
          )}
        </div>
      </div>

      {/* Personal Student Laundry Token Tracker */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400">
                Personal Log
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                My Laundry Dropped Tokens
              </h2>
            </div>
            <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm mt-0.5">
              Keep track of your physical tokens, garments count, and pickup dates in local storage.
            </p>
          </div>

          <button
            id="btn-add-laundry-token"
            onClick={() => setShowAddForm(!showAddForm)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-[#0B2545] hover:bg-blue-800 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-950/30 transition-all active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{showAddForm ? 'Close Form' : 'Log New Drop-off'}</span>
          </button>
        </div>

        {/* New Drop-off Form */}
        {showAddForm && (
          <form onSubmit={handleSubmitRecord} className="p-5 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40 space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm">
              Enter Laundry Token Details
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Token Number *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. JUIT-284"
                  value={tokenNumber}
                  onChange={(e) => setTokenNumber(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Clothes Count (pcs)
                </label>
                <input
                  type="number"
                  min="1"
                  max="40"
                  value={clothesCount}
                  onChange={(e) => setClothesCount(parseInt(e.target.value) || 1)}
                  className="w-full px-3 py-2 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Drop-off Date
                </label>
                <input
                  type="date"
                  value={dropDate}
                  onChange={(e) => setDropDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Expected Pickup Date
                </label>
                <input
                  type="date"
                  value={expectedDate}
                  onChange={(e) => setExpectedDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Optional Notes (e.g. 2 hoodies, bedsheet, lab coat)
              </label>
              <input
                type="text"
                placeholder="Items description..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-[#0B2545] hover:bg-blue-800 text-white text-xs font-semibold shadow-sm transition-colors"
              >
                Save Token Record
              </button>
            </div>
          </form>
        )}

        {/* Existing Records List */}
        {laundryRecords.length === 0 ? (
          <div className="text-center py-10 text-slate-400">
            <Shirt className="w-10 h-10 mx-auto opacity-40 mb-2" />
            <p className="text-sm font-medium">No active laundry tokens logged yet.</p>
            <p className="text-xs">Click "Log New Drop-off" above when you give clothes to the counter.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {laundryRecords.map((rec) => (
              <div
                key={rec.id}
                className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900 dark:text-white text-base tracking-wide">
                      Token #{rec.tokenNumber}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                      {rec.clothesCount} garments
                    </span>
                  </div>
                  <button
                    onClick={() => deleteLaundryRecord(rec.id)}
                    title="Remove token"
                    className="text-slate-400 hover:text-rose-500 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-400">
                  <div>
                    <span className="text-[11px] block text-slate-400">Dropped:</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200">{rec.dropDate}</span>
                  </div>
                  <div>
                    <span className="text-[11px] block text-slate-400">Expected Pickup:</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200">{rec.expectedDate}</span>
                  </div>
                </div>

                {rec.notes && (
                  <p className="text-xs text-slate-500 italic bg-white/60 dark:bg-slate-900/60 p-2 rounded-xl">
                    "{rec.notes}"
                  </p>
                )}

                {/* Status Stepper */}
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Current Stage (Tap to update)
                  </span>
                  <div className="grid grid-cols-4 gap-1">
                    {statusList.map((st) => {
                      const isCurrent = rec.status === st;
                      return (
                        <button
                          key={st}
                          onClick={() => updateLaundryStatus(rec.id, st)}
                          className={`py-1.5 px-1 rounded-lg text-[10px] font-bold transition-all text-center leading-none ${
                            isCurrent
                              ? st === 'Collected'
                                ? 'bg-emerald-600 text-white shadow-sm'
                                : st === 'Ready for Pickup'
                                ? 'bg-amber-500 text-slate-950 shadow-sm'
                                : 'bg-blue-600 text-white shadow-sm'
                              : 'bg-slate-200 dark:bg-slate-700/70 text-slate-600 dark:text-slate-400 hover:bg-slate-300 dark:hover:bg-slate-700'
                          }`}
                        >
                          {st}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
