import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  X,
  Send,
  Bot,
  User,
  RotateCcw,
  Languages,
  CheckCircle2,
  AlertCircle,
  HelpCircle
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { useSettings } from '../context/SettingsContext';
import { useNavigation } from '../context/NavigationContext';
import { ChatMessage } from '../types';

export const JuitBuddyChatModal: React.FC = () => {
  const { isChatOpen, setIsChatOpen, chatInitialPrompt, setChatInitialPrompt } = useCampus();
  const { currentTime, timeZone, settings } = useSettings();
  const { currentLocation, nodes } = useNavigation();

  const [language, setLanguage] = useState<'en' | 'hi'>('en');
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: 'msg-welcome',
        sender: 'buddy',
        text: "Yo! I'm PARTHSAARATHI 🏔️, your JUIT buddy. Poocho kya scene hai—mess food, tuckshop, navigation, timetables, or faculty cabins? Sab sorted hai!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isChatOpen) {
      scrollToBottom();
    }
  }, [messages, isChatOpen]);

  // Handle initial prompt passed from other cards/buttons
  useEffect(() => {
    if (isChatOpen && chatInitialPrompt) {
      sendMessage(chatInitialPrompt);
      setChatInitialPrompt(null);
    }
  }, [isChatOpen, chatInitialPrompt]);

  const quickPrompts = [
    "What's in the mess menu today?",
    "Is tuckshop open right now?",
    "Where is Dr. Vivek Sehgal's cabin?",
    "How to download fee receipt on Campus Lynx?",
    "What are the laundry counter timings?",
    "Who is in charge of scholarships?"
  ];

  const sendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || isSending) return;

    const userMessage: ChatMessage = {
      id: 'msg-user-' + Date.now(),
      sender: 'user',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsSending(true);

    try {
      const res = await fetch('/api/askJuitBuddy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          language,
          context: {
            currentDate: currentTime.toDateString(),
            currentTime: currentTime.toLocaleTimeString(),
            dayOfWeek: new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(currentTime),
            year: currentTime.getFullYear(),
            timezone: timeZone,
            locale: navigator.language,
            academicYear: settings.academicYear,
            navigation: {
              currentLocation: currentLocation.nodeId ? nodes.find(n => n.id === currentLocation.nodeId)?.name : null,
              source: currentLocation.source
            }
          }
        })
      });

      const data = await res.json();
      const buddyReply: ChatMessage = {
        id: 'msg-buddy-' + Date.now(),
        sender: 'buddy',
        text: data.reply || (language === 'hi' ? 'Koyi response nahi mila.' : 'No response received.'),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: !res.ok
      };

      setMessages(prev => [...prev, buddyReply]);
    } catch {
      const errorMsg: ChatMessage = {
        id: 'msg-err-' + Date.now(),
        sender: 'buddy',
        text: language === 'hi'
          ? "Network connection mein dikkat aayi. Kripya check karein aur dobara try karein."
          : "Network connection error. Please verify your connection or try again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsSending(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(inputText);
  };

  const handleReset = () => {
    setMessages([
      {
        id: 'msg-welcome-reset',
        sender: 'buddy',
        text: language === 'hi'
          ? "Namaste! Main PARTHSAARATHI hoon. Aap mujhse mess menu, tuckshop, laundry, timetable, ya faculty ke baare mein poohein!"
          : "Chat reset! How can I help you today on the JUIT campus?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  if (!isChatOpen) {
    return (
      /* Persistent Floating Action Button (FAB) with JUIT Logo */
      <button
        id="btn-floating-juit-buddy"
        onClick={() => setIsChatOpen(true)}
        aria-label="Open PARTHSAARATHI AI Assistant"
        className="fixed bottom-20 lg:bottom-6 right-6 z-40 flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-gradient-to-r from-[#0B2545] to-[#1E40AF] hover:from-[#081B33] hover:to-[#1D4ED8] text-white font-bold text-sm shadow-xl shadow-blue-950/50 border border-blue-400/40 hover:scale-105 active:scale-95 transition-all group"
      >
        <div className="w-6 h-6 rounded-full bg-white p-0.5 ring-1 ring-blue-300 overflow-hidden flex-shrink-0">
          <img
            src="/src/assets/images/juit_official_logo_v4_final_1789206375553.jpg"
            alt="JUIT Logo"
            referrerPolicy="no-referrer"
            className="w-full h-full object-contain"
          />
        </div>
        <span className="tracking-tight">PARTHSAARATHI</span>
        <Sparkles className="w-4 h-4 text-sky-200 animate-pulse group-hover:rotate-12 transition-transform" />
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full sm:max-w-xl h-[85vh] sm:h-[650px] rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-slide-up">
        
        {/* Chat Modal Header */}
        <div className="bg-[#0B1E36] text-white px-5 py-3.5 border-b border-[#142C4E] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white p-0.5 ring-1 ring-blue-400/40 flex items-center justify-center shadow-md overflow-hidden flex-shrink-0">
              <img
                src="/src/assets/images/juit_official_logo_v4_final_1789206375553.jpg"
                alt="JUIT Crest Logo"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm sm:text-base tracking-tight text-white">
                  PARTHSAARATHI AI
                </h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <p className="text-[11px] text-slate-300">
                Sorted Gen-Z Campus Guide | Hinglish Sorted Scene
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Switcher Pill */}
            <div className="flex p-0.5 rounded-xl bg-[#142C4E] border border-blue-700/50 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  language === 'en'
                    ? 'bg-[#0B2545] text-white shadow-sm border border-blue-400/40'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('hi')}
                className={`px-2 py-1 rounded-lg transition-all ${
                  language === 'hi'
                    ? 'bg-[#0B2545] text-white shadow-sm border border-blue-400/40'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Hinglish
              </button>
            </div>

            {/* Clear conversation button */}
            <button
              onClick={handleReset}
              title="Reset conversation"
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-[#142C4E] transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Close button */}
            <button
              id="btn-close-chat-modal"
              onClick={() => setIsChatOpen(false)}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-[#142C4E] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quick Question Chips */}
        <div className="bg-slate-50 dark:bg-slate-950/40 px-4 py-2 border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
          <div className="flex items-center gap-1.5 min-w-max">
            {quickPrompts.map((q, idx) => (
              <button
                key={idx}
                onClick={() => sendMessage(q)}
                disabled={isSending}
                className="px-2.5 py-1 rounded-full text-[11px] font-medium bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-950/50 hover:text-blue-700 dark:hover:text-blue-300 hover:border-blue-300 active:scale-95 transition-all"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Message Bubble Feed */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-[#0B2545] text-white flex items-center justify-center flex-shrink-0 shadow-sm mt-0.5 border border-blue-700/50">
                    <Sparkles className="w-4 h-4 text-sky-200" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 sm:p-4 text-xs sm:text-sm leading-relaxed shadow-sm ${
                    isUser
                      ? 'bg-gradient-to-r from-[#0B2545] to-blue-800 text-white rounded-tr-none'
                      : msg.isError
                      ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200 border border-rose-200 dark:border-rose-800 rounded-tl-none'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-none border border-slate-200/60 dark:border-slate-700/60'
                  }`}
                >
                  <div className="whitespace-pre-line break-words">
                    {msg.text}
                  </div>
                  <span
                    className={`block text-[10px] mt-1.5 ${
                      isUser ? 'text-blue-200 text-right' : 'text-slate-400'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-[#142C4E] text-white flex items-center justify-center flex-shrink-0 shadow-sm mt-0.5 border border-blue-600/40">
                    <User className="w-4 h-4 text-sky-200" />
                  </div>
                )}
              </div>
            );
          })}

          {isSending && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-xl bg-[#0B2545] text-white flex items-center justify-center flex-shrink-0 shadow-sm mt-0.5 border border-blue-700/50">
                <Sparkles className="w-4 h-4 text-sky-200 animate-spin" />
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl rounded-tl-none p-3.5 border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 text-xs text-slate-500">
                <span className="w-2 h-2 rounded-full bg-blue-600 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-blue-600 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-blue-600 animate-bounce [animation-delay:0.4s]" />
                <span className="ml-1 text-[11px] font-medium text-slate-600 dark:text-slate-300">Consulting JUIT campus data...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={handleSubmit}
          className="p-3 sm:p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
        >
          <input
            type="text"
            placeholder={
              language === 'hi'
                ? "Kuch bhi poochiye (e.g. Aaj mess mein kya hai?)..."
                : "Ask anything about JUIT (e.g. lunch menu, tuckshop, cabins)..."
            }
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isSending}
            className="flex-1 px-4 py-2.5 rounded-2xl text-xs sm:text-sm bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600 disabled:opacity-60"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isSending}
            className="p-2.5 rounded-2xl bg-[#0B2545] hover:bg-blue-800 text-white font-bold shadow-md shadow-blue-950/40 border border-blue-600/40 disabled:opacity-40 active:scale-95 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
