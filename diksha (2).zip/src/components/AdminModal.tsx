import React, { useState } from 'react';
import {
  ShieldCheck,
  X,
  Save,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  FileCode
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({ isOpen, onClose }) => {
  const { data, updateCampusSection } = useCampus();

  const [passcode, setPasscode] = useState('');
  const [selectedSection, setSelectedSection] = useState<'mess_menu' | 'tuckshop' | 'cafeteria' | 'laundry'>('mess_menu');
  const [jsonContent, setJsonContent] = useState<string>('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Sync section JSON on selection
  React.useEffect(() => {
    if (data && selectedSection) {
      setJsonContent(JSON.stringify(data[selectedSection], null, 2));
      setFeedback(null);
    }
  }, [selectedSection, data]);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    let parsedData: unknown;
    try {
      parsedData = JSON.parse(jsonContent);
    } catch {
      setFeedback({ type: 'error', message: 'Invalid JSON format. Please verify syntax.' });
      return;
    }

    setIsSaving(true);
    const res = await updateCampusSection(selectedSection, parsedData, passcode);
    setIsSaving(false);

    if (res.success) {
      setFeedback({ type: 'success', message: 'Campus data updated successfully and synced!' });
    } else {
      setFeedback({ type: 'error', message: res.message || 'Passcode incorrect or update rejected.' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-slide-up flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-[#0B1E36] text-white flex items-center justify-between border-b border-[#142C4E]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base">Campus Data Manager</h3>
              <p className="text-xs text-slate-400">Authorized JUIT Admin Panel</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-6 space-y-4 overflow-y-auto flex-1">
          
          {feedback && (
            <div className={`p-3.5 rounded-2xl text-xs sm:text-sm font-medium flex items-center gap-2 ${
              feedback.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
            }`}>
              {feedback.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              <span>{feedback.message}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                Admin Passcode *
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  placeholder="Enter passcode (default: juit2026)"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                Select Section to Edit
              </label>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value as 'mess_menu' | 'tuckshop' | 'cafeteria' | 'laundry')}
                className="w-full px-3 py-2 rounded-xl text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-600 focus:outline-none cursor-pointer"
              >
                <option value="mess_menu">Mess Menu (Daily diet schedule)</option>
                <option value="tuckshop">Tuckshop (Timings, items, status)</option>
                <option value="cafeteria">Cafeteria (Highlights & timings)</option>
                <option value="laundry">Laundry (Turnaround & process)</option>
              </select>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-blue-600" />
                <span>JSON Payload</span>
              </label>
              <span className="text-[11px] text-slate-400">Direct structured schema</span>
            </div>
            <textarea
              rows={12}
              value={jsonContent}
              onChange={(e) => setJsonContent(e.target.value)}
              className="w-full font-mono text-xs p-3.5 rounded-2xl bg-slate-950 text-emerald-400 border border-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving || !passcode}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-[#0B2545] hover:bg-blue-800 disabled:opacity-50 text-white text-xs font-bold shadow-md shadow-blue-950/30 transition-all active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Saving...' : 'Deploy Changes'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
