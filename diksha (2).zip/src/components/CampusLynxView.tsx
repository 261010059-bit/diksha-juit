import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen,
  Search,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Key,
  Calendar,
  Sparkles,
  HelpCircle,
  Building,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { CampusLynxGuideItem } from '../types';
import { BackButton } from './common/BackButton';
import { EmptyState } from './common/EmptyState';

export const CampusLynxView: React.FC = () => {
  const navigate = useNavigate();
  const { data, setIsChatOpen, setChatInitialPrompt } = useCampus();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedGuideId, setExpandedGuideId] = useState<string>(data.campus_lynx[0]?.id || 'lynx_login');

  const categories = ['All', 'Account & Access', 'Academics', 'Finance & Accounts', 'Campus Facilities', 'Examinations'];

  const filteredGuides = data.campus_lynx.filter((guide) => {
    const matchesCategory = selectedCategory === 'All' || guide.category === selectedCategory;
    const matchesSearch =
      guide.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guide.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guide.steps.some(s => s.description.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleAskLynx = (guideTitle: string) => {
    setChatInitialPrompt(`How do I complete "${guideTitle}" on JUIT Campus Lynx / Webkiosk?`);
    setIsChatOpen(true);
  };

  const toggleExpand = (id: string) => {
    setExpandedGuideId(prev => prev === id ? '' : id);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* View Header with Back Navigation */}
      <div className="space-y-4">
        <BackButton />
        <div className="space-y-1">
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Campus Lynx Guide
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Survival guides for official JUIT portals 💻
          </p>
        </div>
      </div>

      {/* Search & Category Filter */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search guides (e.g. attendance, fee receipt, password reset, hostel complaint)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-2.5 rounded-2xl text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-[#0B2545] text-white shadow-md shadow-blue-950/40'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* 75% Attendance Advisory Banner */}
      <div className="p-5 rounded-3xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center flex-shrink-0 font-extrabold">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Critical Academic Notice: 75% Mandatory Attendance
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 leading-relaxed">
              JUIT regulations mandate minimum 75% aggregate attendance in each individual course to sit in the T-3 End Semester examinations. Regularly monitor Webkiosk reports.
            </p>
          </div>
        </div>

        <button
          onClick={() => handleAskLynx("How is 75% attendance calculated and how to submit medical leave on Webkiosk?")}
          className="whitespace-nowrap px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors"
        >
          Ask Medical Leave Rules
        </button>
      </div>

      {/* Guides List */}
      <div className="space-y-4">
        {filteredGuides.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-400">
            <BookOpen className="w-12 h-12 mx-auto opacity-30 mb-2 text-emerald-500" />
            <p className="text-base font-bold text-slate-800 dark:text-slate-200">No matching guides found.</p>
            <p className="text-xs mt-1">Try another search term or click PARTHSAARATHI for instant AI assistance.</p>
          </div>
        ) : (
          filteredGuides.map((guide) => {
            const isExpanded = expandedGuideId === guide.id;

            return (
              <div
                key={guide.id}
                className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-all"
              >
                {/* Accordion Header */}
                <div
                  onClick={() => toggleExpand(guide.id)}
                  className="p-6 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors flex items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
                        {guide.category}
                      </span>
                      {guide.directUrl && (
                        <span className="text-[11px] text-slate-400">
                          • {guide.directUrl.replace('https://', '')}
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                      {guide.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                      {guide.summary}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAskLynx(guide.title);
                      }}
                      title="Ask PARTHSAARATHI"
                      className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 hover:scale-105 transition-transform"
                    >
                      <Sparkles className="w-4 h-4" />
                    </button>

                    <div className="p-2 rounded-xl text-slate-400">
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </div>
                </div>

                {/* Expanded Steps Body */}
                {isExpanded && (
                  <div className="p-6 pt-0 border-t border-slate-100 dark:border-slate-800 space-y-4 mt-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 pt-3">
                      Step-by-Step Procedure
                    </h4>

                    <div className="space-y-3">
                      {guide.steps.map((step) => (
                        <div
                          key={step.stepNumber}
                          className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-start gap-3.5"
                        >
                          <div className="w-7 h-7 rounded-xl bg-[#0B2545] text-white font-bold flex items-center justify-center text-xs flex-shrink-0">
                            {step.stepNumber}
                          </div>
                          <div className="space-y-1">
                            <h5 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                              {step.title}
                            </h5>
                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                              {step.description}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                      <span className="text-xs text-slate-400">
                        Need clarification? Ask JUIT Buddy in English or Hinglish.
                      </span>
                      <button
                        onClick={() => handleAskLynx(guide.title)}
                        className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        <span>Ask AI Questions about this step</span>
                        <Sparkles className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
