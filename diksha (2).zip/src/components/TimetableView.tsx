import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Calendar,
  Clock,
  MapPin,
  Navigation2,
  User,
  BookOpen,
  Map,
  Sparkles,
  ChevronDown,
  Building2,
  CalendarDays,
  Download,
  ExternalLink,
  Search,
  Filter,
  Grid,
  List,
  Layers,
  GraduationCap,
  FlaskConical,
  FileSpreadsheet,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { CampusMapView } from './CampusMapView';
import { EvenSemSession } from '../types';
import { EVEN_SEM_2026_DATA } from '../data/evenSem2026Data';
import { getCourseTitle, getFacultyDetail, mapRoomToCampusBlockId } from '../data/juitCourseDirectory';
import { BackButton } from './common/BackButton';

type ViewMode = 'explorer' | 'matrix' | 'map';
type DayCode = 'MON' | 'TUE' | 'WED' | 'THU' | 'FRI' | 'SAT';

const TIME_SLOTS = [
  '09:00 AM - 09:55 AM',
  '10:00 AM - 10:55 AM',
  '11:00 AM - 11:55 AM',
  '12:00 PM - 12:55 PM',
  '01:00 PM - 01:55 PM',
  '02:00 PM - 02:55 PM',
  '03:00 PM - 03:55 PM',
  '04:00 PM - 04:55 PM',
  '05:00 PM - 05:55 PM'
];

const DAYS: { code: DayCode; name: string; short: string }[] = [
  { code: 'MON', name: 'Monday', short: 'Mon' },
  { code: 'TUE', name: 'Tuesday', short: 'Tue' },
  { code: 'WED', name: 'Wednesday', short: 'Wed' },
  { code: 'THU', name: 'Thursday', short: 'Thu' },
  { code: 'FRI', name: 'Friday', short: 'Fri' },
  { code: 'SAT', name: 'Saturday', short: 'Sat' }
];

export const TimetableView: React.FC = () => {
  const navigate = useNavigate();
  const {
    data,
    setIsChatOpen,
    setChatInitialPrompt,
    studentProfile,
    setIsProfileModalOpen
  } = useCampus();

  // Active sub-tab
  const [activeTab, setActiveTab] = useState<ViewMode>('explorer');

  // Semester options from official dataset
  const semesterOptions = data.even_sem_2026?.semesterOptions || EVEN_SEM_2026_DATA.semesterOptions;
  const allSessions: EvenSemSession[] = data.even_sem_2026?.sessions || EVEN_SEM_2026_DATA.sessions;

  // Selected Semester - defaults to student's enrolled semester if available
  const [selectedSemesterId, setSelectedSemesterId] = useState<string>(
    studentProfile?.semesterId || 'btech_4'
  );

  // Today determination
  const jsDay = new Date().getDay(); // 0 is Sunday, 1 is Monday ... 6 is Saturday
  const defaultDay: DayCode = (jsDay >= 1 && jsDay <= 6) ? (DAYS[jsDay - 1].code) : 'MON';
  const [selectedDay, setSelectedDay] = useState<DayCode>(defaultDay);

  // Selected Batch filter - defaults to student's enrolled batch if available
  const [selectedBatch, setSelectedBatch] = useState<string>(
    (studentProfile && !studentProfile.isGuest && studentProfile.batch) ? studentProfile.batch : 'ALL'
  );

  // Sync with studentProfile updates
  useEffect(() => {
    if (studentProfile && !studentProfile.isGuest && studentProfile.batch) {
      setSelectedBatch(studentProfile.batch);
      if (studentProfile.semesterId) {
        setSelectedSemesterId(studentProfile.semesterId);
      }
    }
  }, [studentProfile]);

  // Search filter query
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Class Type filter
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'Lecture' | 'Practical/Lab' | 'Tutorial'>('ALL');

  // Map target block (when clicking "Locate on Map" from a session)
  const [targetBlockId, setTargetBlockId] = useState<string>('block_academic');

  // Sessions for currently selected semester
  const semesterSessions = useMemo(() => {
    return allSessions.filter(s => s.semesterId === selectedSemesterId);
  }, [allSessions, selectedSemesterId]);

  // Unique batches in the selected semester
  const availableBatches = useMemo(() => {
    const set = new Set<string>();
    semesterSessions.forEach(s => {
      s.batches.forEach(b => {
        const clean = b.replace(/\]$/, '').trim();
        if (clean && clean.length >= 2 && !['AND', '&', 'DLC'].includes(clean.toUpperCase())) {
          set.add(clean);
        }
      });
    });
    return Array.from(set).sort();
  }, [semesterSessions]);

  // Quick popular batches for easy 1-click pill selection
  const topBatches = useMemo(() => {
    return availableBatches.slice(0, 8);
  }, [availableBatches]);

  // Filtered sessions for the selected day in Explorer View
  const filteredSessions = useMemo(() => {
    return semesterSessions.filter(s => {
      // Day filter
      if (s.day !== selectedDay) return false;

      // Batch filter
      if (selectedBatch !== 'ALL') {
        const matchesBatch = s.batches.some(b => b.toUpperCase().includes(selectedBatch.toUpperCase()));
        if (!matchesBatch) return false;
      }

      // Type filter
      if (typeFilter !== 'ALL' && s.type !== typeFilter) return false;

      // Text search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesCode = s.courseCode.toLowerCase().includes(q);
        const matchesRoom = s.room.toLowerCase().includes(q);
        const matchesFaculty = s.faculty.toLowerCase().includes(q);
        const matchesTitle = getCourseTitle(s.courseCode).toLowerCase().includes(q);
        const matchesBatch = s.batches.some(b => b.toLowerCase().includes(q));
        if (!matchesCode && !matchesRoom && !matchesFaculty && !matchesTitle && !matchesBatch) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => a.slotIndex - b.slotIndex);
  }, [semesterSessions, selectedDay, selectedBatch, typeFilter, searchQuery]);

  // Matrix view sessions: group by day and slot index
  const matrixSessions = useMemo(() => {
    return semesterSessions.filter(s => {
      if (selectedBatch !== 'ALL') {
        return s.batches.some(b => b.toUpperCase().includes(selectedBatch.toUpperCase()));
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        return (
          s.courseCode.toLowerCase().includes(q) ||
          s.room.toLowerCase().includes(q) ||
          s.faculty.toLowerCase().includes(q) ||
          s.batches.some(b => b.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [semesterSessions, selectedBatch, searchQuery]);

  // Count classes per day for selected semester & batch
  const countPerDay = useMemo(() => {
    const counts: Record<DayCode, number> = { MON: 0, TUE: 0, WED: 0, THU: 0, FRI: 0, SAT: 0 };
    semesterSessions.forEach(s => {
      if (selectedBatch !== 'ALL' && !s.batches.some(b => b.toUpperCase().includes(selectedBatch.toUpperCase()))) {
        return;
      }
      if (counts[s.day as DayCode] !== undefined) {
        counts[s.day as DayCode]++;
      }
    });
    return counts;
  }, [semesterSessions, selectedBatch]);

  // Handle locate room on campus map
  const handleLocateRoom = (room: string) => {
    const blockId = mapRoomToCampusBlockId(room);
    setTargetBlockId(blockId);
    setActiveTab('map');
  };

  // Handle asking PARTHSAARATHI about a session or faculty
  const handleAskSession = (session: EvenSemSession) => {
    const title = getCourseTitle(session.courseCode);
    const faculty = getFacultyDetail(session.faculty);
    setChatInitialPrompt(`Tell me details about course ${session.courseCode} (${title}), class timing ${session.time} on ${session.day}, faculty ${faculty.name} (${session.faculty}), and room ${session.room}.`);
    setIsChatOpen(true);
  };

  const handleAskFaculty = (facultyCode: string) => {
    const faculty = getFacultyDetail(facultyCode);
    setChatInitialPrompt(`Where is the cabin of faculty ${faculty.name} (${facultyCode}) at JUIT and what are their consultation timings?`);
    setIsChatOpen(true);
  };

  return (
    <div className="space-y-6 pb-14">
      {/* View Header with Back Navigation */}
      <div className="space-y-4">
        <BackButton />
        <div className="space-y-1">
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Timetable & Map
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Don't walk past your classroom twice 💀
          </p>
        </div>
      </div>

      {/* Official JUIT Even Semester 2026 Header Card */}
      <div className="bg-[#0B1E36] rounded-3xl p-6 sm:p-7 border border-[#0B2545] text-white shadow-xl relative overflow-hidden">
        {/* Subtle decorative crest/pattern watermark */}
        <div className="absolute right-0 top-0 bottom-0 w-80 bg-gradient-to-l from-blue-600/10 to-transparent pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-500/20 text-sky-300 border border-blue-400/30">
                <FileSpreadsheet className="w-3.5 h-3.5 text-sky-400" />
                <span>Live TTC Committee Timetable</span>
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Verified: EVENSEM2026.xls
              </span>
              <span className="text-xs text-blue-200/70 hidden sm:inline-block">
                • Jan - Jun 2026 Academic Session
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Even Semester 2026 Timetable
            </h1>
            <p className="text-sm text-blue-100/80 leading-relaxed">
              Official university class schedules, lecture theatres, laboratory assignments, and faculty allocations directly synchronized from the JUIT Time Table Committee (TTC).
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-blue-200/90 font-medium">
              <span className="flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-sky-400" />
                6 Semesters (UG & PG)
              </span>
              <span className="flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-sky-400" />
                156 Batches
              </span>
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-sky-400" />
                1,426 Scheduled Classes
              </span>
            </div>
          </div>

          {/* Action Download & External Links */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 flex-shrink-0">
            <a
              id="btn-download-evensem-xls"
              href="/EVENSEM2026.xls"
              download="EVENSEM2026.xls"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-[#0B2545] hover:bg-blue-900/90 text-white font-semibold text-xs sm:text-sm border border-blue-800/80 transition-all shadow-sm hover:shadow-md"
            >
              <Download className="w-4 h-4 text-sky-400" />
              <span>Download .XLS File</span>
            </a>

            <a
              id="btn-source-juit-ttc"
              href="https://www.juit.ac.in/TTC/EVENSEM2026.xls"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs sm:text-sm border border-white/15 transition-all"
            >
              <ExternalLink className="w-4 h-4 text-blue-300" />
              <span>JUIT Web Portal</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main View Mode Selector Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-1.5 overflow-x-auto p-0.5">
          <button
            id="tab-view-explorer"
            onClick={() => setActiveTab('explorer')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'explorer'
                ? 'bg-[#0B2545] text-white shadow-md shadow-blue-950/40'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <List className="w-4 h-4" />
            <span>Class Schedule Explorer</span>
          </button>

          <button
            id="tab-view-matrix"
            onClick={() => setActiveTab('matrix')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'matrix'
                ? 'bg-[#0B2545] text-white shadow-md shadow-blue-950/40'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Grid className="w-4 h-4" />
            <span>Weekly Master Grid</span>
          </button>

          <button
            id="tab-view-map"
            onClick={() => setActiveTab('map')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'map'
                ? 'bg-[#0B2545] text-white shadow-md shadow-blue-950/40'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Map className="w-4 h-4" />
            <span>Campus Map & Room Locator</span>
          </button>
        </div>

        <button
          onClick={() => {
            setChatInitialPrompt(`Can you help me find my class schedule for Even Semester 2026?`);
            setIsChatOpen(true);
          }}
          className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/50 text-xs font-semibold hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          <span>Ask PARTHSAARATHI</span>
        </button>
      </div>

      {/* VIEW: SCHEDULE EXPLORER */}
      {activeTab === 'explorer' && (
        <div className="space-y-5">
          {/* Personalized Student Batch Card */}
          {studentProfile && !studentProfile.isGuest ? (
            <div className="bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-blue-950/40 border border-blue-500/30 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-400/40 flex items-center justify-center text-sky-300 flex-shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-2">
                    <span>Personalized for Enrollment:</span>
                    <span className="font-mono text-sky-300 bg-blue-900/80 px-2 py-0.5 rounded-md border border-blue-500/40 font-bold">
                      {studentProfile.enrollmentNo}
                    </span>
                    {studentProfile.name && (
                      <span className="text-slate-300 font-normal">({studentProfile.name})</span>
                    )}
                  </div>
                  <div className="text-[11px] text-blue-200/80 mt-0.5">
                    Your assigned batch is <strong className="text-white font-mono">{studentProfile.batch}</strong>.
                    {selectedBatch === studentProfile.batch ? (
                      <span className="text-emerald-400 font-semibold ml-1.5 inline-flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Showing your batch classes
                      </span>
                    ) : (
                      <span className="text-amber-300 font-semibold ml-1.5">
                        (Currently showing {selectedBatch === 'ALL' ? 'all batches' : `batch ${selectedBatch}`})
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                {selectedBatch !== studentProfile.batch && (
                  <button
                    onClick={() => setSelectedBatch(studentProfile.batch)}
                    className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-sm"
                  >
                    Reset to My Batch ({studentProfile.batch})
                  </button>
                )}
                <button
                  onClick={() => setIsProfileModalOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold border border-white/15 transition-all"
                >
                  Switch Roll / Batch
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                <User className="w-4 h-4 text-blue-600" />
                <span>Browsing as Guest. Set your student enrollment number and batch to filter your classes automatically.</span>
              </div>
              <button
                onClick={() => setIsProfileModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-[#0B2545] text-white font-bold hover:bg-blue-900 transition-colors flex-shrink-0"
              >
                Set My Roll & Batch
              </button>
            </div>
          )}

          {/* Controls: Semester, Batch, Type, Search */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Semester Dropdown */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Select Semester:
                </label>
                <div className="relative">
                  <select
                    id="select-semester"
                    value={selectedSemesterId}
                    onChange={(e) => {
                      setSelectedSemesterId(e.target.value);
                      setSelectedBatch('ALL');
                    }}
                    className="w-full appearance-none bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-semibold text-xs sm:text-sm rounded-xl px-4 py-2.5 pr-9 focus:outline-none focus:ring-2 focus:ring-blue-600 cursor-pointer"
                  >
                    {semesterOptions.map((sem) => (
                      <option key={sem.id} value={sem.id}>
                        {sem.name} ({sem.year})
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              {/* Batch Dropdown */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center justify-between">
                  <span>Filter by Batch:</span>
                  <span className="text-[11px] text-blue-600 dark:text-blue-400 font-medium">
                    {availableBatches.length} Batches
                  </span>
                </label>
                <div className="relative">
                  <select
                    id="select-batch"
                    value={selectedBatch}
                    onChange={(e) => setSelectedBatch(e.target.value)}
                    className="w-full appearance-none bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-semibold text-xs sm:text-sm rounded-xl px-4 py-2.5 pr-9 focus:outline-none focus:ring-2 focus:ring-blue-600 cursor-pointer"
                  >
                    <option value="ALL">All Batches (Full Semester)</option>
                    {availableBatches.map((b) => (
                      <option key={b} value={b}>
                        Batch: {b}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              {/* Live Search */}
              <div className="space-y-1.5 sm:col-span-2 lg:col-span-1">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Search Timetable:
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="input-search-timetable"
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search Course, Faculty (e.g. PKP), Room (LT2)..."
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white text-xs sm:text-sm rounded-xl pl-9 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs font-bold"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Popular Batch Chips */}
            {topBatches.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-slate-100 dark:border-slate-800">
                <span className="text-[11px] font-bold text-slate-400 mr-1 uppercase">
                  Quick Batch:
                </span>
                <button
                  onClick={() => setSelectedBatch('ALL')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${
                    selectedBatch === 'ALL'
                      ? 'bg-[#0B2545] text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  All
                </button>
                {topBatches.map((b) => (
                  <button
                    key={b}
                    onClick={() => setSelectedBatch(b)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${
                      selectedBatch === b
                        ? 'bg-[#0B2545] text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Weekday Strip */}
          <div className="bg-white dark:bg-slate-900 p-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-x-auto">
            <div className="flex items-center gap-2 min-w-max">
              {DAYS.map((day) => {
                const isSelected = selectedDay === day.code;
                const isToday = (jsDay >= 1 && jsDay <= 6) && DAYS[jsDay - 1].code === day.code;
                const count = countPerDay[day.code] || 0;

                return (
                  <button
                    key={day.code}
                    id={`btn-day-${day.code.toLowerCase()}`}
                    onClick={() => setSelectedDay(day.code)}
                    className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
                      isSelected
                        ? 'bg-[#0B2545] text-white shadow-md shadow-blue-950/40'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <span>{day.name}</span>
                    <span
                      className={`px-1.5 py-0.5 rounded-md text-[10px] font-extrabold ${
                        isSelected
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {count}
                    </span>
                    {isToday && (
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-black uppercase ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950'
                            : 'bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-300'
                        }`}
                      >
                        Today
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Type Filter Pills & Active Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-500 dark:text-slate-400">Class Type:</span>
              <button
                onClick={() => setTypeFilter('ALL')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all ${
                  typeFilter === 'ALL'
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setTypeFilter('Lecture')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all flex items-center gap-1 ${
                  typeFilter === 'Lecture'
                    ? 'bg-blue-800 text-white'
                    : 'bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300'
                }`}
              >
                <BookOpen className="w-3 h-3" />
                <span>Lectures</span>
              </button>
              <button
                onClick={() => setTypeFilter('Practical/Lab')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all flex items-center gap-1 ${
                  typeFilter === 'Practical/Lab'
                    ? 'bg-indigo-700 text-white'
                    : 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-800 dark:text-indigo-300'
                }`}
              >
                <FlaskConical className="w-3 h-3" />
                <span>Labs & Practicals</span>
              </button>
              <button
                onClick={() => setTypeFilter('Tutorial')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all flex items-center gap-1 ${
                  typeFilter === 'Tutorial'
                    ? 'bg-teal-700 text-white'
                    : 'bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-300'
                }`}
              >
                <GraduationCap className="w-3 h-3" />
                <span>Tutorials</span>
              </button>
            </div>

            <span className="text-slate-400 font-medium">
              Showing <strong className="text-slate-700 dark:text-slate-200">{filteredSessions.length}</strong> classes on {DAYS.find(d => d.code === selectedDay)?.name}
            </span>
          </div>

          {/* Session Cards List */}
          <div className="space-y-3">
            {filteredSessions.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-400">
                <Calendar className="w-12 h-12 mx-auto opacity-30 mb-3 text-blue-500" />
                <h3 className="font-bold text-slate-800 dark:text-slate-200 text-base">
                  No Classes Scheduled for this Selection
                </h3>
                <p className="text-xs sm:text-sm mt-1 max-w-md mx-auto">
                  {searchQuery
                    ? `No sessions matching "${searchQuery}". Try clearing search or selecting "All Batches".`
                    : `No classes for batch ${selectedBatch} on ${DAYS.find(d => d.code === selectedDay)?.name}. Enjoy your self-study time!`}
                </p>
                {(selectedBatch !== 'ALL' || searchQuery) && (
                  <button
                    onClick={() => {
                      setSelectedBatch('ALL');
                      setSearchQuery('');
                      setTypeFilter('ALL');
                    }}
                    className="mt-4 px-4 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 text-xs font-semibold hover:bg-blue-100"
                  >
                    Reset All Filters
                  </button>
                )}
              </div>
            ) : (
              filteredSessions.map((session) => {
                const courseTitle = getCourseTitle(session.courseCode);
                const facultyDetail = getFacultyDetail(session.faculty);

                const typeBadgeColors = {
                  'Lecture': 'bg-blue-100 dark:bg-blue-950/70 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800',
                  'Practical/Lab': 'bg-indigo-100 dark:bg-indigo-950/70 text-indigo-800 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
                  'Tutorial': 'bg-teal-100 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300 border-teal-200 dark:border-teal-800'
                }[session.type];

                return (
                  <div
                    key={session.id}
                    className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm hover:border-blue-500/50 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-4">
                      {/* Time Block */}
                      <div className="w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800/60 flex flex-col items-center justify-center flex-shrink-0 text-blue-800 dark:text-blue-300">
                        <Clock className="w-4 h-4" />
                        <span className="text-[10px] font-extrabold mt-0.5">SLOT {session.slotIndex + 1}</span>
                      </div>

                      {/* Content Block */}
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-md text-xs font-extrabold bg-[#0B2545] text-white">
                            {session.time}
                          </span>
                          <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold border ${typeBadgeColors}`}>
                            {session.type}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono">
                            {session.courseCode}
                          </span>
                        </div>

                        <h3 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                          {courseTitle}
                        </h3>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 pt-0.5">
                          {/* Faculty */}
                          <div className="flex items-center gap-1 font-medium">
                            <User className="w-3.5 h-3.5 text-slate-400" />
                            <span>Faculty:</span>
                            <button
                              onClick={() => handleAskFaculty(session.faculty)}
                              className="font-semibold text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                              title="Click to check cabin location"
                            >
                              <span>{facultyDetail.name}</span>
                              {session.faculty && <span className="text-[11px] text-slate-400">({session.faculty})</span>}
                            </button>
                          </div>

                          {/* Room */}
                          <div className="flex items-center gap-1">
                            <span className="font-semibold text-blue-800 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded-md border border-blue-200 dark:border-blue-800/40 inline-flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                              <span>Room: {session.room || 'TBA'}</span>
                            </span>
                          </div>
                        </div>

                        {/* Batches Pills */}
                        {session.batches.length > 0 && (
                          <div className="flex flex-wrap items-center gap-1.5 pt-1">
                            <span className="text-[11px] font-bold text-slate-400 uppercase">
                              Batches:
                            </span>
                            {session.batches.map((b, idx) => (
                              <button
                                key={idx}
                                onClick={() => setSelectedBatch(b)}
                                className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-blue-100 dark:hover:bg-blue-950/60 text-slate-700 dark:text-slate-300 text-[11px] font-semibold transition-colors"
                              >
                                {b}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Actions on right */}
                    <div className="flex sm:flex-row lg:flex-col items-center lg:items-end justify-between lg:justify-center gap-2 border-t lg:border-t-0 pt-3 lg:pt-0 border-slate-100 dark:border-slate-800 flex-shrink-0">
                      <button
                        onClick={() => handleLocateRoom(session.room)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/40 text-xs font-semibold hover:bg-blue-100 transition-colors"
                      >
                        <MapPin className="w-3.5 h-3.5 text-blue-600" />
                        <span>Locate Room on Map</span>
                      </button>

                      <button
                        onClick={() => handleAskSession(session)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-300 transition-colors"
                      >
                        <Sparkles className="w-3 h-3 text-blue-500" />
                        <span>Ask Details</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* VIEW: MASTER GRID MATRIX */}
      {activeTab === 'matrix' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Official JUIT Time Table Grid Matrix (Jan-Jun 2026)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Displays the multi-slot weekly matrix matching the published university timetable board.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <select
                  value={selectedBatch}
                  onChange={(e) => setSelectedBatch(e.target.value)}
                  className="appearance-none bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-semibold text-xs rounded-xl px-3 py-2 pr-8 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="ALL">All Batches (Dense Grid)</option>
                  {availableBatches.map((b) => (
                    <option key={b} value={b}>
                      Batch: {b}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Matrix Table with Horizontal Scroll */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[900px]">
                <thead>
                  <tr className="bg-[#0B1E36] text-white text-xs border-b border-[#0B2545]">
                    <th className="p-3 font-bold sticky left-0 bg-[#0B1E36] z-10 w-24 border-r border-[#0B2545]">
                      DAY / TIME
                    </th>
                    {TIME_SLOTS.map((slot, idx) => (
                      <th key={idx} className="p-3 font-semibold text-[11px] whitespace-nowrap border-r border-[#0B2545]/60">
                        <div>SLOT {idx + 1}</div>
                        <div className="text-[10px] text-sky-300 font-normal">{slot}</div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-xs">
                  {DAYS.map((day) => {
                    return (
                      <tr key={day.code} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                        {/* Sticky Day Column */}
                        <td className="p-3 font-extrabold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800/80 sticky left-0 z-10 border-r border-slate-200 dark:border-slate-800">
                          <div>{day.code}</div>
                          <div className="text-[10px] font-normal text-slate-400">{day.name}</div>
                        </td>

                        {/* 9 Time Slot Columns */}
                        {TIME_SLOTS.map((_, slotIdx) => {
                          const slotClasses = matrixSessions.filter(
                            s => s.day === day.code && s.slotIndex === slotIdx
                          );

                          return (
                            <td key={slotIdx} className="p-2 border-r border-slate-100 dark:border-slate-800/60 align-top max-w-[140px]">
                              {slotClasses.length === 0 ? (
                                <span className="text-slate-300 dark:text-slate-700 text-[10px] block text-center py-2">
                                  —
                                </span>
                              ) : (
                                <div className="space-y-1.5">
                                  {slotClasses.slice(0, 3).map((sc) => {
                                    const isLecture = sc.type === 'Lecture';
                                    const isLab = sc.type === 'Practical/Lab';
                                    const bgColor = isLecture
                                      ? 'bg-blue-50 dark:bg-blue-950/50 border-blue-200 dark:border-blue-800'
                                      : isLab
                                      ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-200 dark:border-indigo-800'
                                      : 'bg-teal-50 dark:bg-teal-950/50 border-teal-200 dark:border-teal-800';

                                    return (
                                      <div
                                        key={sc.id}
                                        onClick={() => handleAskSession(sc)}
                                        className={`p-1.5 rounded-lg border text-[11px] cursor-pointer hover:scale-[1.02] transition-transform ${bgColor}`}
                                        title={`${sc.courseCode} (${sc.type}) | Room: ${sc.room} | Faculty: ${sc.faculty}`}
                                      >
                                        <div className="font-extrabold text-slate-900 dark:text-white truncate">
                                          {sc.courseCode}
                                        </div>
                                        <div className="flex items-center justify-between text-[10px] text-slate-600 dark:text-slate-400 mt-0.5">
                                          <span className="font-bold text-blue-700 dark:text-blue-300">
                                            {sc.room}
                                          </span>
                                          <span>{sc.faculty}</span>
                                        </div>
                                        {sc.batches.length > 0 && (
                                          <div className="text-[9px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
                                            {sc.batches.slice(0, 2).join(', ')}
                                          </div>
                                        )}
                                      </div>
                                    );
                                  })}
                                  {slotClasses.length > 3 && (
                                    <div className="text-[10px] text-blue-600 dark:text-blue-400 font-bold text-center">
                                      +{slotClasses.length - 3} more
                                    </div>
                                  )}
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW: CAMPUS MAP & ROOM LOCATOR */}
      {activeTab === 'map' && (
        <div className="space-y-6">
          {/* Indoor Navigation Upgrade Banner */}
          <div className="bg-gradient-to-r from-blue-700 to-indigo-800 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden group">
            <div className="absolute right-0 top-0 bottom-0 w-64 bg-white/5 skew-x-12 translate-x-20 pointer-events-none" />
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-blue-500/30 text-[10px] font-bold uppercase tracking-widest border border-white/20">New Experience</span>
                  <span className="flex items-center gap-1 text-sky-200">
                    <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                    <span className="text-xs font-bold tracking-tight">Indoor Navigation</span>
                  </span>
                </div>
                <h2 className="text-2xl font-black tracking-tight leading-none">Ground Floor Navigator</h2>
                <p className="text-sm text-blue-100/90 max-w-xl leading-relaxed">
                  Lost on the Ground Floor? Use our new indoor navigation system with route highlighting and turn-by-turn instructions.
                </p>
              </div>
              <button 
                onClick={() => navigate('/map/ground-floor')}
                className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-white text-blue-800 rounded-2xl font-black text-sm shadow-2xl hover:scale-[1.02] active:scale-95 transition-all group-hover:shadow-blue-500/20"
              >
                <Navigation2 className="w-5 h-5" />
                <span>Open Indoor Map</span>
              </button>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <MapPin className="w-4 h-4 text-blue-600" />
                Campus Master Map
              </h3>
            </div>
            <CampusMapView initialBlockId={targetBlockId} />
          </div>
        </div>
      )}
    </div>
  );
};
