import React, { useState, useMemo } from 'react';
import { Search, Filter, Rocket, Sparkles, Plus, ExternalLink, Globe, Instagram, MessageSquare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { BackButton } from './common/BackButton';
import { EmptyState } from './common/EmptyState';
import { useCampus } from '../context/CampusContext';
import { LoadingState } from './common/LoadingState';
import { Club } from '../types';

const CATEGORIES = [
  'All', 'Technical', 'Coding', 'Mathematics', 'Biotechnology', 
  'Bioinformatics', 'IEEE', 'Cultural', 'Sports', 'Literary', 
  'Photography', 'Media', 'Events', 'Innovation'
];

export const ClubsView: React.FC = () => {
  const navigate = useNavigate();
  const { data, isLoading: contextLoading } = useCampus();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  const clubs = data.clubs || [];

  const filteredClubs = useMemo(() => {
    return clubs.filter(club => {
      const matchesSearch = 
        club.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        club.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        club.activities.some(a => a.toLowerCase().includes(searchQuery.toLowerCase())) ||
        club.keywords.some(k => k.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = activeCategory === 'All' || club.categories.includes(activeCategory);
      
      return matchesSearch && matchesCategory;
    });
  }, [clubs, searchQuery, activeCategory]);

  const featuredClubs = useMemo(() => {
    return filteredClubs.filter(c => c.isFeatured);
  }, [filteredClubs]);

  const regularClubs = useMemo(() => {
    return filteredClubs.filter(c => !c.isFeatured);
  }, [filteredClubs]);

  if (contextLoading) return <LoadingState message="Discovering JUIT clubs..." />;

  return (
    <div className="flex-1 overflow-y-auto pb-24">
      <div className="max-w-7xl mx-auto px-4 pt-6 sm:px-6 lg:px-8 space-y-8">
        
        {/* Header */}
        <div className="space-y-4">
          <BackButton />
          <div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-3">
              Clubs & Communities
              <Sparkles className="w-6 h-6 text-blue-500 animate-pulse" />
            </h1>
            <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 max-w-2xl mt-2 leading-relaxed">
              Find your people. Build your skills. Make your JUIT arc count.
            </p>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="space-y-4 sticky top-0 z-20 bg-slate-50/80 dark:bg-slate-950/80 backdrop-blur-md py-2 -mx-4 px-4">
          <div className="relative group">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 group-focus-within:text-blue-500 transition-colors" />
            <input
              type="text"
              placeholder="Search clubs, skills, events..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none transition-all shadow-sm"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 -mx-4 px-4 no-scrollbar">
            {CATEGORIES.map(category => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                  activeCategory === category
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20 ring-2 ring-blue-400/20'
                    : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:border-blue-400'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <AnimatePresence mode="popLayout">
          {filteredClubs.length > 0 ? (
            <div className="space-y-10">
              {/* Featured Section */}
              {featuredClubs.length > 0 && (
                <section className="space-y-4">
                  <div className="flex items-center gap-2 mb-4">
                    <Rocket className="w-5 h-5 text-blue-500" />
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">Featured at JUIT</h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {featuredClubs.map(club => (
                      <ClubCard key={club.id} club={club} isFeatured />
                    ))}
                  </div>
                </section>
              )}

              {/* Regular Clubs */}
              {regularClubs.length > 0 && (
                <section className="space-y-4 pb-8">
                  {featuredClubs.length > 0 && (
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">All Communities</h2>
                  )}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {regularClubs.map(club => (
                      <ClubCard key={club.id} club={club} />
                    ))}
                  </div>
                </section>
              )}
            </div>
          ) : (
            <EmptyState 
              title="No clubs found" 
              description="Try another search or category. Maybe it's time to start a new club?"
              actionLabel="Clear Filters"
              onAction={() => {
                setSearchQuery('');
                setActiveCategory('All');
              }}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const ClubCard: React.FC<{ club: Club; isFeatured?: boolean }> = ({ club, isFeatured }) => {
  const navigate = useNavigate();

  const statusColors = {
    open: 'bg-emerald-500 text-white',
    closed: 'bg-slate-500 text-white',
    unknown: 'bg-amber-500 text-white'
  };

  const statusLabels = {
    open: '🟢 Open',
    closed: '⚪ Closed',
    unknown: '🟡 Unknown'
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -4 }}
      onClick={() => navigate(`/clubs/${club.slug}`)}
      className={`group cursor-pointer rounded-3xl border p-5 transition-all flex flex-col h-full bg-white dark:bg-slate-900 ${
        isFeatured 
          ? 'border-blue-500/30 shadow-xl shadow-blue-500/5 ring-1 ring-blue-500/10' 
          : 'border-slate-200 dark:border-slate-800 hover:border-blue-500/50 shadow-sm'
      }`}
    >
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-50 dark:bg-slate-950 p-2 border border-slate-200 dark:border-slate-800 flex items-center justify-center overflow-hidden transition-transform group-hover:scale-105 shadow-inner">
          {club.logoUrl ? (
            <img 
              src={club.logoUrl} 
              alt={club.logoAlt} 
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="text-xl font-black text-slate-400 uppercase tracking-tighter">
              {club.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
            </div>
          )}
        </div>
        <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${statusColors[club.recruitmentStatus]}`}>
          {statusLabels[club.recruitmentStatus]}
        </div>
      </div>

      <div className="flex-1 space-y-2">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-blue-500 transition-colors">
          {club.name}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
          {club.description}
        </p>
      </div>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {club.categories.slice(0, 3).map(cat => (
          <span key={cat} className="px-2 py-0.5 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 text-[10px] font-bold border border-blue-100 dark:border-blue-800/40">
            {cat}
          </span>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
        <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 group-hover:translate-x-1 transition-transform">
          View Details →
        </span>
        <div className="flex items-center gap-2">
          {club.websiteUrl && <Globe className="w-3.5 h-3.5 text-slate-400" />}
          {club.instagramUrl && <Instagram className="w-3.5 h-3.5 text-slate-400" />}
          {club.discordUrl && <MessageSquare className="w-3.5 h-3.5 text-slate-400" />}
        </div>
      </div>
    </motion.div>
  );
};
