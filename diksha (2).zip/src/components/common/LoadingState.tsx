import React from 'react';

export const LoadingState: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center py-20 px-4 text-center animate-fade-in">
      <div className="relative">
        <div className="w-12 h-12 rounded-full border-4 border-blue-100 dark:border-blue-900/30 border-t-blue-600 animate-spin" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
        </div>
      </div>
      <p className="mt-4 text-sm font-bold text-slate-900 dark:text-white">
        Loading campus data...
      </p>
      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
        JUIT Buddy is fetching the latest updates.
      </p>
    </div>
  );
};
