import React from 'react';
import { LucideIcon, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface InteractiveCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  onClick: () => void;
  className?: string;
}

export const InteractiveCard: React.FC<InteractiveCardProps> = ({
  icon: Icon,
  title,
  description,
  onClick,
  className = ''
}) => {
  return (
    <motion.button
      whileHover={{ y: -4, scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`group w-full text-left p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500/50 shadow-sm hover:shadow-xl hover:shadow-blue-900/10 transition-all duration-200 flex items-center gap-4 ${className}`}
    >
      <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-[#0B2545] flex items-center justify-center text-blue-600 dark:text-sky-400 group-hover:scale-110 transition-transform duration-200 shadow-inner">
        <Icon className="w-6 h-6" />
      </div>
      
      <div className="flex-1 min-w-0">
        <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight leading-tight">
          {title}
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
          {description}
        </p>
      </div>

      <ArrowRight className="w-5 h-5 text-slate-300 dark:text-slate-700 group-hover:text-blue-500 group-hover:translate-x-1 transition-all duration-200" />
    </motion.button>
  );
};
