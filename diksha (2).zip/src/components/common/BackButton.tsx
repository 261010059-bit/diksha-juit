import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface BackButtonProps {
  label?: string;
  className?: string;
}

export const BackButton: React.FC<BackButtonProps> = ({ label = 'Back', className = '' }) => {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate(-1)}
      className={`group flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800/50 hover:bg-slate-200 dark:hover:bg-[#0B2545] text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-sky-300 border border-slate-200 dark:border-slate-800 hover:border-blue-500/30 transition-all duration-200 active:scale-95 shadow-sm hover:shadow-blue-900/20 ${className}`}
    >
      <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform duration-200" />
      <span className="text-xs font-semibold tracking-tight">{label}</span>
    </button>
  );
};
