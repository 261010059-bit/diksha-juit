import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Utensils,
  Store,
  Shirt,
  Calendar,
  BookOpen,
  ArrowRight,
  Sparkles,
  Clock,
  MapPin,
  CheckCircle,
  Coffee,
  GraduationCap,
  CalendarDays,
  Users
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { Weekday } from '../types';
import { InteractiveCard } from './common/InteractiveCard';

export const HomeView: React.FC = () => {
  const navigate = useNavigate();
  const {
    data,
    setIsChatOpen,
    setChatInitialPrompt,
    studentProfile,
    setIsProfileModalOpen
  } = useCampus();

  // Determine current day and time
  const now = new Date();
  const dayNames: Weekday[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const todayKey = dayNames[now.getDay()];
  const currentHour = now.getHours();

  // Tuckshop open: 8 AM (8) to 11 PM (23)
  const isTuckshopOpen = currentHour >= 8 && currentHour < 23;

  // Active meal determination
  let currentMealName = 'Breakfast';
  if (currentHour >= 11 && currentHour < 15) {
    currentMealName = 'Lunch';
  } else if (currentHour >= 15 && currentHour < 19) {
    currentMealName = 'Snacks';
  } else if (currentHour >= 19 || currentHour < 2) {
    currentMealName = 'Dinner';
  }

  const todayMess = data.mess_menu[todayKey] || data.mess_menu.monday;

  const formattedDate = now.toLocaleDateString('en-IN', {
    weekday: 'long',
    month: 'short',
    day: 'numeric'
  });

  const handleAskBuddy = (prompt: string) => {
    setChatInitialPrompt(prompt);
    setIsChatOpen(true);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Hero Welcome Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0B2545] via-[#0F325E] to-[#142C4E] border border-blue-900/60 p-6 sm:p-8 text-white shadow-xl">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-sky-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4 max-w-2xl">
            <div className="flex w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-white p-1 ring-2 ring-blue-300/40 shadow-lg flex-shrink-0 items-center justify-center overflow-hidden">
              <img
                src="/src/assets/images/juit_official_logo_v4_final_1789206375553.jpg"
                alt="JUIT Crest Logo"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/60 border border-blue-500/40 text-sky-200 text-xs font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-sky-300" />
                <span>Waknaghat, Solan • Himachal Pradesh</span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
                Welcome to <span className="text-sky-300">JUIT Guide</span>
              </h1>
              <p className="text-blue-100/90 text-sm sm:text-base leading-relaxed">
                Your instant companion for Annapurna mess menus, tuckshop hours, laundry tracking, batch lecture schedules, and Campus Lynx guides.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              id="btn-home-chat-prompt"
              onClick={() => handleAskBuddy("What is the mess menu today and is tuckshop open?")}
              className="flex items-center justify-center gap-2.5 px-5 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-lg shadow-blue-950/50 border border-blue-400/30 active:scale-95 transition-all"
            >
              <Sparkles className="w-4 h-4 text-sky-200" />
              <span>Ask PARTHSAARATHI AI</span>
            </button>
            <Link
              to="/dining"
              className="flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-[#091D36]/80 hover:bg-[#091D36] text-slate-100 font-semibold text-sm border border-blue-800/60 transition-colors"
            >
              <span>View Mess Menu</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Student Portal Status & Quick Batch Timetable Access */}
      {studentProfile && !studentProfile.isGuest ? (
        <section className="bg-gradient-to-r from-[#0B2545] via-[#142C4E] to-[#0B1E36] rounded-3xl p-5 sm:p-6 text-white border border-blue-800/60 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-sky-300 flex-shrink-0">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-sky-300 uppercase tracking-wider">
                  Student Dashboard
                </span>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-mono font-bold bg-blue-900 text-sky-200 border border-blue-500/40">
                  {studentProfile.enrollmentNo}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-extrabold text-white mt-0.5">
                {studentProfile.name ? `Welcome, ${studentProfile.name}` : `Welcome, Student ${studentProfile.enrollmentNo}`}
              </h3>
              <p className="text-xs text-blue-100/80">
                Assigned Batch: <strong className="text-sky-300 font-mono font-bold">{studentProfile.batch}</strong> • Even Semester 2026
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-shrink-0">
            <Link
              to="/timetable"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold shadow-sm transition-all"
            >
              <Calendar className="w-4 h-4" />
              <span>View Batch {studentProfile.batch} Classes</span>
            </Link>
            <button
              onClick={() => setIsProfileModalOpen(true)}
              className="px-3.5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold border border-white/15 transition-all"
            >
              Switch ID
            </button>
          </div>
        </section>
      ) : (
        <section className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/40 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <GraduationCap className="w-5 h-5 text-blue-700 dark:text-blue-300" />
            <span className="text-slate-700 dark:text-slate-300 font-medium">
              Want personalized timetables and lab reminders? Enter your JUIT Enrollment Number and Batch.
            </span>
          </div>
          <button
            onClick={() => setIsProfileModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-[#0B2545] text-white font-bold hover:bg-blue-900 transition-colors flex-shrink-0"
          >
            Enter Roll & Batch
          </button>
        </section>
      )}

      {/* "Today" Live Status Card */}
      <section className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm transition-all">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-md bg-blue-50 dark:bg-blue-950/70 text-blue-800 dark:text-blue-300 text-xs font-bold uppercase tracking-wider border border-blue-200 dark:border-blue-800/50">
                Live Overview
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {formattedDate}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mt-1">
              Today on Campus
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Live Tuckshop indicator */}
            <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <Store className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <div className="text-left">
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-none">
                  Tuckshop Status
                </p>
                <div className="flex items-center gap-1.5 mt-1">
                  <span className={`w-2 h-2 rounded-full ${isTuckshopOpen ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                  <span className={`text-xs font-bold ${isTuckshopOpen ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                    {isTuckshopOpen ? 'Open Now (Till 11 PM)' : 'Closed (Opens 8 AM)'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Today's Mess Menu Row */}
        <div className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Utensils className="w-5 h-5 text-blue-700 dark:text-blue-400" />
              <h3 className="font-bold text-slate-900 dark:text-white text-base sm:text-lg">
                Annapurna Mess Menu ({todayKey.toUpperCase()})
              </h3>
            </div>
            <Link
              to="/dining"
              className="text-xs sm:text-sm font-semibold text-blue-700 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
            >
              Full 7-Day Menu <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Breakfast */}
            <div className={`p-4 rounded-2xl border transition-all ${
              currentMealName === 'Breakfast'
                ? 'bg-blue-50/80 dark:bg-blue-950/50 border-blue-400 dark:border-blue-700 shadow-sm ring-1 ring-blue-500/20'
                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Breakfast • 7:30 - 9:00 AM
                </span>
                {currentMealName === 'Breakfast' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#0B2545] text-white">
                    Active
                  </span>
                )}
              </div>
              <p className="text-sm font-medium text-slate-800 dark:text-slate-200 leading-snug">
                {todayMess.breakfast}
              </p>
            </div>

            {/* Lunch */}
            <div className={`p-4 rounded-2xl border transition-all ${
              currentMealName === 'Lunch'
                ? 'bg-blue-50/80 dark:bg-blue-950/50 border-blue-400 dark:border-blue-700 shadow-sm ring-1 ring-blue-500/20'
                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Lunch • 12:30 - 2:15 PM
                </span>
                {currentMealName === 'Lunch' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#0B2545] text-white">
                    Active
                  </span>
                )}
              </div>
              <p className="text-sm font-medium text-slate-800 dark:text-slate-200 leading-snug">
                {todayMess.lunch}
              </p>
            </div>

            {/* Snacks */}
            <div className={`p-4 rounded-2xl border transition-all ${
              currentMealName === 'Snacks'
                ? 'bg-blue-50/80 dark:bg-blue-950/50 border-blue-400 dark:border-blue-700 shadow-sm ring-1 ring-blue-500/20'
                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Snacks • 5:00 - 6:15 PM
                </span>
                {currentMealName === 'Snacks' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#0B2545] text-white">
                    Active
                  </span>
                )}
              </div>
              <p className="text-sm font-medium text-slate-800 dark:text-slate-200 leading-snug">
                {todayMess.snacks}
              </p>
            </div>

            {/* Dinner */}
            <div className={`p-4 rounded-2xl border transition-all ${
              currentMealName === 'Dinner'
                ? 'bg-blue-50/80 dark:bg-blue-950/50 border-blue-400 dark:border-blue-700 shadow-sm ring-1 ring-blue-500/20'
                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Dinner • 7:45 - 9:30 PM
                </span>
                {currentMealName === 'Dinner' && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#0B2545] text-white">
                    Active
                  </span>
                )}
              </div>
              <p className="text-sm font-medium text-slate-800 dark:text-slate-200 leading-snug">
                {todayMess.dinner}
              </p>
            </div>

          </div>

          {todayMess.specialNote && (
            <div className="mt-3 text-xs text-blue-800 dark:text-blue-200 font-medium bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 rounded-xl px-3 py-2 flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-blue-600 flex-shrink-0" />
              <span>Special Note: {todayMess.specialNote}</span>
            </div>
          )}
        </div>
      </section>

      {/* Main Campus Services / Resources Section */}
      <section id="section-home-resources" className="space-y-6">
        <div className="space-y-1">
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Campus Resources
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">Everything you need to survive your JUIT arc.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <InteractiveCard
            icon={Utensils}
            title="Dining & Mess"
            description="Weekly menu, timings & tuckshop scenes 🍕"
            onClick={() => navigate('/dining')}
          />
          <InteractiveCard
            icon={Shirt}
            title="Laundry Service"
            description="Track your wash cycles & token status 🧼"
            onClick={() => navigate('/laundry')}
          />
          <InteractiveCard
            icon={CalendarDays}
            title="Timetable & Map"
            description="Don't walk past your classroom twice 💀"
            onClick={() => navigate('/timetable')}
          />
          <InteractiveCard
            icon={BookOpen}
            title="Campus Lynx Guide"
            description="Survival guides for official JUIT portals 💻"
            onClick={() => navigate('/campus-lynx')}
          />
          <InteractiveCard
            icon={GraduationCap}
            title="Faculty Directory"
            description="Find cabins before the 'sir, actually' walk 🎓"
            onClick={() => navigate('/faculty')}
          />
          <InteractiveCard
            icon={Users}
            title="Clubs & Communities"
            description="Find your people & build your JUIT arc 🚀"
            onClick={() => navigate('/clubs')}
          />
          <InteractiveCard
            icon={Sparkles}
            title="Ask JUIT Buddy"
            description="Instant campus info from your AI senior 🤖"
            onClick={() => setIsChatOpen(true)}
            className="!bg-gradient-to-br from-blue-600/5 to-indigo-700/5 border-blue-500/20"
          />
        </div>
      </section>

      {/* Suggested Quick AI Questions Banner */}
      <section className="bg-[#0B1E36] rounded-3xl border border-[#142C4E] p-6 text-white shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-sky-300" />
          <h3 className="font-bold text-base text-slate-100">
            Ask PARTHSAARATHI (Quick Questions)
          </h3>
        </div>
        <p className="text-slate-300 text-xs sm:text-sm mb-4">
          Tap any question to immediately get an answer from the JUIT campus dataset:
        </p>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => handleAskBuddy("What is today's lunch and dinner in Annapurna mess?")}
            className="px-3.5 py-2 rounded-xl text-xs font-medium bg-[#142C4E] hover:bg-[#1C3B68] text-slate-100 border border-blue-600/30 active:scale-95 transition-all text-left"
          >
            🍛 Today's mess menu
          </button>
          <button
            onClick={() => handleAskBuddy("Who is incharge for scholarships at JUIT and what is their cabin?")}
            className="px-3.5 py-2 rounded-xl text-xs font-medium bg-[#142C4E] hover:bg-[#1C3B68] text-slate-100 border border-blue-600/30 active:scale-95 transition-all text-left"
          >
            🎓 Who handles scholarships?
          </button>
          <button
            onClick={() => handleAskBuddy("What is the step-by-step process to download semester fee receipt on Campus Lynx?")}
            className="px-3.5 py-2 rounded-xl text-xs font-medium bg-[#142C4E] hover:bg-[#1C3B68] text-slate-100 border border-blue-600/30 active:scale-95 transition-all text-left"
          >
            📄 How to download fee receipt?
          </button>
          <button
            onClick={() => handleAskBuddy("What are the laundry counter timings and how many clothes are free under hostel fee?")}
            className="px-3.5 py-2 rounded-xl text-xs font-medium bg-[#142C4E] hover:bg-[#1C3B68] text-slate-100 border border-blue-600/30 active:scale-95 transition-all text-left"
          >
            🧺 Laundry timings & cost
          </button>
          <button
            onClick={() => handleAskBuddy("Where is Dr. Pradeep Kumar's cabin located in Block F?")}
            className="px-3.5 py-2 rounded-xl text-xs font-medium bg-[#142C4E] hover:bg-[#1C3B68] text-slate-100 border border-blue-600/30 active:scale-95 transition-all text-left"
          >
            📍 Find Dr. Pradeep's cabin
          </button>
        </div>
      </section>
    </div>
  );
};
