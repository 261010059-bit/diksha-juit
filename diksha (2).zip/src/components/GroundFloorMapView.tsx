import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  ArrowLeft, 
  Search, 
  MapPin, 
  Navigation2, 
  Plus, 
  Minus, 
  RotateCcw, 
  QrCode,
  Info,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useNavigation } from '../context/NavigationContext';
import { useSettings } from '../context/SettingsContext';
import { motion, AnimatePresence } from 'motion/react';
import { MapNode } from '../types';

export const GroundFloorMapView: React.FC = () => {
  const navigate = useNavigate();
  const { settings } = useSettings();
  const { 
    nodes, 
    currentLocation, 
    destination, 
    route, 
    isNavigating, 
    setManualLocation, 
    setDestination, 
    scanQRCode, 
    startNavigation, 
    stopNavigation,
    isOutsideCampus,
    gpsStatus
  } = useNavigation();

  const [searchQuery, setSearchQuery] = useState('');
  const [isLocationPickerOpen, setIsLocationPickerOpen] = useState(false);
  const [isQRScannerOpen, setIsQRScannerOpen] = useState(false);
  const [qrInput, setQrInput] = useState('');
  const [zoom, setZoom] = useState(1);
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, w: 100, h: 160 });
  const [selectedNode, setSelectedNode] = useState<MapNode | null>(null);
  const [activeStepIndex, setActiveStepIndex] = useState(0);

  const mapRef = useRef<SVGSVGElement>(null);

  const filteredNodes = useMemo(() => {
    if (!searchQuery) return [];
    const query = searchQuery.toLowerCase();
    return nodes.filter(n => 
      n.name.toLowerCase().includes(query) ||
      n.category?.toLowerCase().includes(query) ||
      n.keywords?.some(k => k.toLowerCase().includes(query))
    );
  }, [nodes, searchQuery]);

  const handleNodeClick = (node: MapNode) => {
    setSelectedNode(node);
    setSearchQuery('');
  };

  const { isFollowing, setIsFollowing } = useNavigation();

  const handleStartNav = () => {
    if (!currentLocation.nodeId) {
      setIsLocationPickerOpen(true);
    } else {
      startNavigation();
      setSelectedNode(null);
      setIsFollowing(true); // Auto-enable follow when starting nav
    }
  };

  const handleQRSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (scanQRCode(qrInput)) {
      setIsQRScannerOpen(false);
      setQrInput('');
    } else {
      alert('Invalid QR Code. Please try again.');
    }
  };

  const handleRecenter = () => {
    if (currentLocation.nodeId) {
      const node = nodes.find(n => n.id === currentLocation.nodeId);
      if (node?.coordinates) {
        setViewBox(prev => ({
          ...prev,
          x: node.coordinates!.x - prev.w / 2,
          y: node.coordinates!.y - prev.h / 2
        }));
      }
    } else {
      setIsLocationPickerOpen(true);
    }
  };

  // Follow Mode Logic
  useEffect(() => {
    if (isFollowing && currentLocation.nodeId) {
      const node = nodes.find(n => n.id === currentLocation.nodeId);
      if (node?.coordinates) {
        setViewBox(prev => ({
          ...prev,
          x: node.coordinates!.x - prev.w / 2,
          y: node.coordinates!.y - prev.h / 2
        }));
      }
    }
  }, [isFollowing, currentLocation.nodeId, nodes]);

  // Derived states for UI
  const currentLocNode = nodes.find(n => n.id === currentLocation.nodeId);
  const destNode = nodes.find(n => n.id === destination);
  const activeStep = route?.steps[activeStepIndex];

  // Helper to get location status text
  const getLocationSourceText = () => {
    switch (currentLocation.source) {
      case 'qr': return 'Location detected by QR';
      case 'manual': return 'Location set manually';
      case 'gps': return 'Live indoor location';
      default: return 'Location unknown';
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] lg:h-[calc(100vh-100px)] -mt-6 -mx-4 sm:-mx-6 lg:-mx-8 bg-white dark:bg-slate-950 overflow-hidden relative">
      
      {/* Top Search Bar */}
      <div className="absolute top-4 left-4 right-4 z-20 flex flex-col gap-2">
        <div className="flex items-center gap-2 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-2">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1 flex items-center gap-2 px-2">
            <Search className="w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search LRC, LT2, CR1..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent border-none focus:ring-0 text-sm font-medium dark:text-white"
            />
          </div>
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="p-2 text-xs font-bold text-blue-600">
              Clear
            </button>
          )}
        </div>

        {/* Search Results Dropdown */}
        <AnimatePresence>
          {searchQuery && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800"
            >
              {filteredNodes.length > 0 ? filteredNodes.map(node => (
                <button
                  key={node.id}
                  onClick={() => handleNodeClick(node)}
                  className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                >
                  <MapPin className="w-4 h-4 text-blue-500" />
                  <div className="text-left">
                    <p className="text-sm font-bold dark:text-white">{node.name}</p>
                    <p className="text-xs text-slate-500">{node.category}</p>
                  </div>
                </button>
              )) : (
                <div className="p-8 text-center text-slate-500 text-sm">
                  No locations found for "{searchQuery}"
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Map Content */}
      <div className="flex-1 relative overflow-hidden bg-slate-50 dark:bg-slate-900/20">
        <svg 
          ref={mapRef}
          viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`}
          className="w-full h-full touch-none"
          style={{ transition: settings.accessibility.reducedMotion === 'on' ? 'none' : 'all 0.3s ease-out' }}
          onMouseDown={() => setIsFollowing(false)} // Disable follow on user interaction
          onTouchStart={() => setIsFollowing(false)}
        >
          {/* Main Corridor Background */}
          <line 
            x1="50" y1="0" x2="50" y2="155" 
            stroke="currentColor" 
            strokeWidth="10" 
            className="text-slate-200 dark:text-slate-800" 
            strokeLinecap="round"
          />

          {/* Connection Lines (Paths) */}
          {nodes.map(node => node.connections.map(conn => {
            const target = nodes.find(n => n.id === conn.to);
            if (!target || !node.coordinates || !target.coordinates) return null;
            
            const isRouteSegment = route?.path.includes(node.id) && route?.path.includes(target.id);
            const pathIndexNode = route?.path.indexOf(node.id) ?? -1;
            const pathIndexTarget = route?.path.indexOf(target.id) ?? -1;
            const isSequential = Math.abs(pathIndexNode - pathIndexTarget) === 1;

            return (
              <line 
                key={`${node.id}-${conn.to}`}
                x1={node.coordinates.x} y1={node.coordinates.y}
                x2={target.coordinates.x} y2={target.coordinates.y}
                stroke={isRouteSegment && isSequential ? '#3b82f6' : 'currentColor'}
                strokeWidth={isRouteSegment && isSequential ? '4' : '1'}
                className={isRouteSegment && isSequential ? '' : 'text-slate-300 dark:text-slate-700'}
                strokeDasharray={conn.relationship === 'stairs' ? '2 2' : 'none'}
              />
            );
          }))}

          {/* Nodes / Rooms */}
          {nodes.map(node => {
            if (!node.coordinates) return null;
            const isSelected = selectedNode?.id === node.id;
            const isDestination = destination === node.id;
            const isCurrent = currentLocation.nodeId === node.id;

            return (
              <g key={node.id} onClick={() => handleNodeClick(node)} className="cursor-pointer">
                <circle 
                  cx={node.coordinates.x} 
                  cy={node.coordinates.y} 
                  r={isSelected || isDestination ? 4 : 2.5}
                  className={`${
                    isDestination ? 'fill-red-500' : 
                    isCurrent ? 'fill-blue-600' :
                    isSelected ? 'fill-blue-400' : 'fill-slate-400 dark:fill-slate-600'
                  } transition-all duration-300`}
                />
                {(isSelected || isDestination || isCurrent || zoom > 1.5) && (
                  <text 
                    x={node.coordinates.x} 
                    y={node.coordinates.y - 6} 
                    textAnchor="middle" 
                    className="text-[4px] font-bold fill-slate-700 dark:fill-slate-300 pointer-events-none"
                  >
                    {node.name}
                  </text>
                )}
              </g>
            );
          })}

          {/* You Are Here Marker (Blue Dot) */}
          {currentLocNode?.coordinates && (
            <g>
              {/* Accuracy Circle */}
              <circle 
                cx={currentLocNode.coordinates.x} 
                cy={currentLocNode.coordinates.y} 
                r={currentLocation.source === 'gps' ? 12 : 6} 
                className="fill-blue-500/10 animate-pulse"
              />
              <circle 
                cx={currentLocNode.coordinates.x} 
                cy={currentLocNode.coordinates.y} 
                r="3" 
                className="fill-blue-600 stroke-white stroke-[0.5]"
              />
              <text 
                x={currentLocNode.coordinates.x} 
                y={currentLocNode.coordinates.y + 8} 
                textAnchor="middle" 
                className="text-[3px] font-black fill-blue-600 pointer-events-none uppercase tracking-tighter"
              >
                YOU ARE HERE
              </text>
            </g>
          )}
        </svg>

        {/* Map Controls */}
        <div className="absolute right-4 bottom-32 lg:bottom-4 flex flex-col gap-2 z-10">
          <div className="flex flex-col bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <button onClick={() => setZoom(z => Math.min(z + 0.2, 3))} className="p-3 hover:bg-slate-50 dark:hover:bg-slate-800 border-b border-slate-100 dark:border-slate-800">
              <Plus className="w-5 h-5" />
            </button>
            <button onClick={() => setZoom(z => Math.max(z - 0.2, 0.5))} className="p-3 hover:bg-slate-50 dark:hover:bg-slate-800">
              <Minus className="w-5 h-5" />
            </button>
          </div>
          <button 
            onClick={handleRecenter}
            className={`p-3 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 transition-all ${
              isFollowing 
              ? 'bg-blue-600 text-white border-blue-600' 
              : 'bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <RotateCcw className="w-5 h-5" />
          </button>
          {isNavigating && (
            <button 
              onClick={() => setIsFollowing(!isFollowing)}
              className={`p-3 rounded-2xl shadow-xl border transition-all ${
                isFollowing 
                ? 'bg-blue-600 text-white border-blue-600' 
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
              }`}
            >
              <Navigation2 className={`w-5 h-5 ${isFollowing ? 'animate-pulse' : ''}`} />
            </button>
          )}
          <button 
            onClick={() => setIsQRScannerOpen(true)}
            className="p-3 bg-blue-600 text-white rounded-2xl shadow-xl hover:bg-blue-700 transition-colors"
          >
            <QrCode className="w-5 h-5" />
          </button>
        </div>

        {/* Proximity / GPS Info */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-10">
          <AnimatePresence>
            {isOutsideCampus ? (
              <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-amber-100 dark:bg-amber-900/40 border border-amber-200 dark:border-amber-800 px-4 py-2 rounded-full flex items-center gap-2 shadow-lg"
              >
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span className="text-[10px] font-bold text-amber-800 dark:text-amber-200 whitespace-nowrap">
                  You appear to be outside the campus map area.
                </span>
              </motion.div>
            ) : gpsStatus === 'success' && !currentLocation.nodeId && (
              <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-blue-50 dark:bg-blue-900/40 border border-blue-100 dark:border-blue-800 px-4 py-2 rounded-full flex items-center gap-2 shadow-lg"
              >
                <Info className="w-4 h-4 text-blue-600" />
                <span className="text-[10px] font-bold text-blue-800 dark:text-blue-200 whitespace-nowrap">
                  You're near JUIT. For indoor positioning, set your location or scan a QR.
                </span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Bottom Information Sheet */}
      <div className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 shadow-2xl z-30 pb-safe">
        <div className="p-4 space-y-4">
          
          {/* Navigation Mode */}
          {isNavigating && route ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                  <Navigation2 className="w-5 h-5 animate-bounce" />
                  <span className="text-sm font-black uppercase tracking-wider">Navigating to {destNode?.name}</span>
                </div>
                <button onClick={stopNavigation} className="text-xs font-bold text-slate-500 underline">End Navigation</button>
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-2xl border border-blue-100 dark:border-blue-800">
                <div className="flex items-center justify-between mb-2">
                   <p className="text-xs font-bold uppercase tracking-widest text-blue-500">Next Step</p>
                   <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">{getLocationSourceText()}</p>
                </div>
                <p className="text-lg font-black dark:text-white leading-tight">
                  {activeStep?.instruction}
                </p>
                <div className="mt-4 flex items-center justify-between gap-4">
                  <div className="flex gap-2">
                    <button 
                      disabled={activeStepIndex === 0}
                      onClick={() => setActiveStepIndex(i => i - 1)}
                      className="p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl disabled:opacity-30"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button 
                      disabled={activeStepIndex === route.steps.length - 1}
                      onClick={() => setActiveStepIndex(i => i + 1)}
                      className="p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl disabled:opacity-30"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-slate-500 uppercase">Progress</p>
                    <p className="text-sm font-black dark:text-white">Step {activeStepIndex + 1} of {route.steps.length}</p>
                  </div>
                </div>
              </div>

              {activeStepIndex === route.steps.length - 1 && (
                <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-800 flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                  <div>
                    <p className="text-sm font-bold text-emerald-900 dark:text-emerald-100">
                      {currentLocation.source === 'manual' || currentLocation.source === 'qr' ? "Route complete" : "You've arrived"}
                    </p>
                    <p className="text-xs text-emerald-700 dark:text-emerald-300">{destNode?.name} reached.</p>
                  </div>
                </div>
              )}
            </div>
          ) : selectedNode ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-black dark:text-white leading-none">{selectedNode.name}</h3>
                  <p className="text-sm text-slate-500 mt-1">{selectedNode.category}</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => { setDestination(null); setSelectedNode(null); }}
                    className="p-2 bg-slate-100 dark:bg-slate-800 rounded-xl"
                  >
                    <RotateCcw className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl">
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed italic">
                  {selectedNode.description || "No detailed description available for this location."}
                </p>
                <div className="mt-3 flex items-center gap-2 text-[10px] font-bold uppercase text-slate-500">
                  <MapPin className="w-3 h-3" />
                  <span>Located at {selectedNode.branchDirection ? `${selectedNode.branchDirection} side of hallway` : 'Ground Floor Corridor'}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => setDestination(selectedNode.id)}
                  className={`flex-1 py-4 rounded-2xl font-black text-sm transition-all ${
                    destination === selectedNode.id 
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white'
                  }`}
                >
                  {destination === selectedNode.id ? 'Target Set' : 'Set as Destination'}
                </button>
                {destination === selectedNode.id && (
                  <button 
                    onClick={handleStartNav}
                    className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black text-sm shadow-lg shadow-blue-900/20"
                  >
                    Navigate
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-black dark:text-white">Ground Floor Map</h3>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 mt-0.5">
                    <span className="flex items-center gap-1">
                      <div className={`w-2 h-2 rounded-full ${currentLocation.nodeId ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                      {getLocationSourceText()}
                    </span>
                    <span className="w-1 h-1 rounded-full bg-slate-300" />
                    <button 
                      onClick={() => alert('GPS can locate you around campus but usually cannot identify your exact indoor room. For accurate indoor positioning, use a JUIT QR checkpoint or another supported indoor positioning system.')}
                      className="text-blue-600 hover:underline"
                    >
                      How it works?
                    </button>
                  </div>
                </div>
                <button 
                  onClick={() => setIsLocationPickerOpen(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl text-xs font-bold border border-blue-100 dark:border-blue-800 transition-all hover:bg-blue-100"
                >
                  <MapPin className="w-4 h-4" />
                  {currentLocation.nodeId ? nodes.find(n => n.id === currentLocation.nodeId)?.name : '📍 Set My Location'}
                </button>
              </div>

              <div className="flex gap-2">
                <div className="flex-1 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Status</p>
                  <p className="text-xs font-bold dark:text-white">
                    {currentLocation.nodeId ? `Standing at ${currentLocNode?.name}` : 'Waiting for location...'}
                  </p>
                </div>
                <button 
                   onClick={handleRecenter}
                   className="p-4 bg-blue-600 text-white rounded-2xl shadow-lg"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Location Picker Modal */}
      <AnimatePresence>
        {isLocationPickerOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
            onClick={() => setIsLocationPickerOpen(false)}
          >
            <motion.div 
              initial={{ y: 100 }}
              animate={{ y: 0 }}
              exit={{ y: 100 }}
              className="bg-white dark:bg-slate-900 w-full max-w-md rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-6 border-b border-slate-100 dark:border-slate-800">
                <h3 className="text-xl font-black dark:text-white">Where are you now?</h3>
                <p className="text-sm text-slate-500">Select your current indoor location</p>
              </div>
              <div className="max-h-96 overflow-y-auto p-2 grid grid-cols-1 gap-1">
                {nodes.filter(n => n.isVerified).map(node => (
                  <button
                    key={node.id}
                    onClick={() => { setManualLocation(node.id); setIsLocationPickerOpen(false); }}
                    className={`w-full p-4 flex items-center justify-between rounded-2xl transition-all ${
                      currentLocation.nodeId === node.id 
                      ? 'bg-blue-600 text-white'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-900 dark:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-3 text-left">
                      <MapPin className={`w-4 h-4 ${currentLocation.nodeId === node.id ? 'text-blue-200' : 'text-blue-500'}`} />
                      <span className="font-bold text-sm">{node.name}</span>
                    </div>
                    {currentLocation.nodeId === node.id && <CheckCircle2 className="w-4 h-4" />}
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* QR Scanner Simulation Modal */}
      <AnimatePresence>
        {isQRScannerOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden p-8 space-y-6"
            >
              <div className="text-center space-y-2">
                <div className="w-20 h-20 bg-blue-600 text-white rounded-3xl mx-auto flex items-center justify-center shadow-xl mb-4">
                  <QrCode className="w-10 h-10" />
                </div>
                <h3 className="text-xl font-black dark:text-white">Scan JUIT Location QR</h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  Scan the unique QR code posted at campus checkpoints to instantly update your position.
                </p>
              </div>

              <form onSubmit={handleQRSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Simulation: Enter Code</label>
                  <input 
                    autoFocus
                    type="text" 
                    placeholder="e.g. JUIT-GF-MAIN-ENTRANCE"
                    value={qrInput}
                    onChange={(e) => setQrInput(e.target.value)}
                    className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-xl p-4 text-sm font-bold dark:text-white focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="flex gap-2">
                  <button 
                    type="button"
                    onClick={() => setIsQRScannerOpen(false)}
                    className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-bold text-sm"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="flex-2 py-4 bg-blue-600 text-white rounded-2xl font-bold text-sm"
                  >
                    Set Location
                  </button>
                </div>
              </form>

              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex gap-3">
                <Info className="w-5 h-5 text-blue-500 shrink-0" />
                <p className="text-[10px] text-blue-700 dark:text-blue-300 leading-tight">
                  Indoor positioning uses locally placed QR markers. For security and accuracy, only verified JUIT codes are supported.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
