import React, { useState } from 'react';
import {
  MapPin,
  Building2,
  Navigation,
  Compass,
  Info,
  Sparkles,
  CheckCircle2,
  DoorOpen,
  X
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { CampusBlock } from '../types';

interface CampusMapViewProps {
  initialBlockId?: string;
}

export const CampusMapView: React.FC<CampusMapViewProps> = ({ initialBlockId }) => {
  const { data, setIsChatOpen, setChatInitialPrompt } = useCampus();
  const [selectedBlock, setSelectedBlock] = useState<CampusBlock | null>(
    (initialBlockId ? data.campus_map.blocks.find(b => b.id === initialBlockId) : null) ||
    data.campus_map.blocks[0] ||
    null
  );
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const categories = [
    { key: 'all', label: 'All Campus Buildings' },
    { key: 'academic', label: 'Academic & Labs' },
    { key: 'hostel', label: 'Student Hostels' },
    { key: 'amenity', label: 'Dining & Health' },
    { key: 'sports', label: 'Sports & SAC' },
    { key: 'admin', label: 'Administration' },
  ];

  const filteredBlocks = categoryFilter === 'all'
    ? data.campus_map.blocks
    : data.campus_map.blocks.filter(b => b.category === categoryFilter);

  const handleAskLocation = (blockName: string) => {
    setChatInitialPrompt(`How do I reach ${blockName} at JUIT and what cabins are located inside?`);
    setIsChatOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Category filter strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <button
            key={cat.key}
            onClick={() => setCategoryFilter(cat.key)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              categoryFilter === cat.key
                ? 'bg-[#0B2545] text-white shadow-md shadow-blue-950/40'
                : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Vector Interactive Campus Layout Container */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Visual Map Stage */}
        <div className="lg:col-span-2 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 rounded-3xl border border-slate-800 p-6 relative overflow-hidden shadow-lg min-h-[420px] flex flex-col justify-between">
          {/* Mountain Contour Background Decor */}
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#4f46e5" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
              <circle cx="50%" cy="50%" r="220" stroke="#f59e0b" strokeWidth="0.8" strokeDasharray="6 6" fill="none" />
              <circle cx="50%" cy="50%" r="320" stroke="#3b82f6" strokeWidth="0.8" strokeDasharray="8 8" fill="none" />
            </svg>
          </div>

          <div className="relative z-10 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1 rounded-full border border-slate-700">
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              <span>JUIT Waknaghat Hillside Campus Layout</span>
            </div>
            <span className="hidden sm:inline-block">Click any pin to inspect rooms & cabins</span>
          </div>

          {/* Interactive Block Pins on Stage */}
          <div className="relative z-10 w-full h-[320px] my-2">
            {data.campus_map.blocks.map((block) => {
              const isSelected = selectedBlock?.id === block.id;
              const isDimmed = categoryFilter !== 'all' && block.category !== categoryFilter;

              return (
                <button
                  key={block.id}
                  onClick={() => setSelectedBlock(block)}
                  style={{
                    left: `${block.coordinates.x}%`,
                    top: `${block.coordinates.y}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                  className={`absolute group flex flex-col items-center transition-all ${
                    isDimmed ? 'opacity-30 pointer-events-none' : 'opacity-100'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-2xl flex items-center justify-center font-bold shadow-lg transition-all ${
                      isSelected
                        ? 'bg-amber-400 text-slate-950 scale-125 ring-4 ring-amber-400/40'
                        : block.category === 'academic'
                        ? 'bg-indigo-600 text-white hover:scale-110'
                        : block.category === 'hostel'
                        ? 'bg-emerald-600 text-white hover:scale-110'
                        : block.category === 'amenity'
                        ? 'bg-orange-600 text-white hover:scale-110'
                        : block.category === 'sports'
                        ? 'bg-purple-600 text-white hover:scale-110'
                        : 'bg-rose-600 text-white hover:scale-110'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                  </div>
                  <span className={`mt-1 px-2 py-0.5 rounded-md text-[11px] font-bold whitespace-nowrap shadow-md transition-all ${
                    isSelected
                      ? 'bg-amber-400 text-slate-950'
                      : 'bg-slate-900/90 text-slate-200 border border-slate-700'
                  }`}>
                    {block.shortName}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Compass / Key Legend */}
          <div className="relative z-10 flex flex-wrap items-center gap-3 text-[11px] text-slate-400 pt-2 border-t border-slate-800">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-indigo-500" /> Academic</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Hostels</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-orange-500" /> Dining & Health</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-purple-500" /> Sports</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> Admin</span>
          </div>
        </div>

        {/* Selected Block Info Panel */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm flex flex-col justify-between">
          {selectedBlock ? (
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300">
                    {selectedBlock.category}
                  </span>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                    {selectedBlock.name}
                  </h3>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                {selectedBlock.description}
              </p>

              {/* Key Rooms & Cabins inside */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                  <DoorOpen className="w-3.5 h-3.5 text-blue-600" />
                  <span>Key Rooms & Cabins</span>
                </h4>
                <div className="space-y-1">
                  {selectedBlock.keyRooms.map((room, idx) => (
                    <div
                      key={idx}
                      className="text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-2"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
                      <span>{room}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Accessible Features */}
              <div className="space-y-1.5 pt-2">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Amenities & Access
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedBlock.accessibleFeatures.map((feat, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-1 rounded-lg text-[11px] font-medium bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/40"
                    >
                      ✓ {feat}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-3">
                <button
                  onClick={() => handleAskLocation(selectedBlock.name)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-2xl bg-[#0B2545] hover:bg-blue-800 text-white text-xs font-bold shadow-md shadow-blue-950/30 transition-all active:scale-95"
                >
                  <Sparkles className="w-3.5 h-3.5 text-sky-300" />
                  <span>Ask PARTHSAARATHI About This Block</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400">
              <Building2 className="w-10 h-10 mx-auto opacity-40 mb-2" />
              <p className="text-sm">Select any building pin to view details.</p>
            </div>
          )}
        </div>

      </div>

      {/* Quick list of buildings */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
        <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4">
          All JUIT Campus Facilities Directory
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredBlocks.map((block) => (
            <div
              key={block.id}
              onClick={() => setSelectedBlock(block)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                selectedBlock?.id === block.id
                  ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-600 ring-1 ring-blue-600/30'
                  : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {block.name}
                </span>
                <span className="text-[10px] font-semibold text-blue-700 dark:text-blue-400 capitalize">
                  {block.category}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                {block.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
