import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CampusData, LaundryTrackerRecord, StudentProfile } from '../types';
import { INITIAL_CAMPUS_DATA } from '../data/campusData';

interface CampusContextType {
  data: CampusData;
  isLoading: boolean;
  isOffline: boolean;
  lastUpdated: string | null;
  refreshData: () => Promise<void>;
  updateCampusSection: (section: string, newData: unknown, passcode: string) => Promise<{ success: boolean; message: string }>;
  // Student Profile
  studentProfile: StudentProfile | null;
  saveStudentProfile: (profile: StudentProfile) => void;
  logoutStudent: () => void;
  isProfileModalOpen: boolean;
  setIsProfileModalOpen: (open: boolean) => void;
  // Laundry tracker
  laundryRecords: LaundryTrackerRecord[];
  addLaundryRecord: (record: Omit<LaundryTrackerRecord, 'id'>) => void;
  updateLaundryStatus: (id: string, status: LaundryTrackerRecord['status']) => void;
  deleteLaundryRecord: (id: string) => void;
  // Chat modal state
  isChatOpen: boolean;
  setIsChatOpen: (open: boolean) => void;
  chatInitialPrompt: string | null;
  setChatInitialPrompt: (prompt: string | null) => void;
}

const CampusContext = createContext<CampusContextType | undefined>(undefined);

const LOCAL_STORAGE_DATA_KEY = 'juit_campus_data_cache_v1';
const LOCAL_STORAGE_LAUNDRY_KEY = 'juit_laundry_tracker_records_v1';
const LOCAL_STORAGE_STUDENT_KEY = 'juit_student_profile_v1';

export const CampusProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<CampusData>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_DATA_KEY);
      if (cached) {
        return JSON.parse(cached);
      }
    } catch {
      // Fallback
    }
    return INITIAL_CAMPUS_DATA;
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [chatInitialPrompt, setChatInitialPrompt] = useState<string | null>(null);

  // Student Profile state
  const [studentProfile, setStudentProfile] = useState<StudentProfile | null>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_STUDENT_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return null;
  });

  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  const saveStudentProfile = (profile: StudentProfile) => {
    setStudentProfile(profile);
    try {
      localStorage.setItem(LOCAL_STORAGE_STUDENT_KEY, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save student profile to localStorage:', e);
    }
  };

  const logoutStudent = () => {
    setStudentProfile(null);
    try {
      localStorage.removeItem(LOCAL_STORAGE_STUDENT_KEY);
    } catch (e) {
      console.error('Failed to clear student profile:', e);
    }
  };

  // Laundry tracker state
  const [laundryRecords, setLaundryRecords] = useState<LaundryTrackerRecord[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_LAUNDRY_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return [
      {
        id: 'rec-sample-1',
        tokenNumber: 'JUIT-L-241',
        clothesCount: 14,
        dropDate: new Date(Date.now() - 24 * 3600 * 1000).toISOString().split('T')[0],
        expectedDate: new Date(Date.now() + 24 * 3600 * 1000).toISOString().split('T')[0],
        status: 'In Wash',
        notes: 'Includes 2 bedsheets and 3 hoodies'
      }
    ];
  });

  // Save laundry records to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_LAUNDRY_KEY, JSON.stringify(laundryRecords));
    } catch (e) {
      console.error('Failed to save laundry tracker:', e);
    }
  }, [laundryRecords]);

  // Online/offline listener
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const refreshData = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/campus-data');
      if (res.ok) {
        const json = await res.json();
        if (json.data) {
          setData(json.data);
          setLastUpdated(json.lastUpdated || new Date().toISOString());
          localStorage.setItem(LOCAL_STORAGE_DATA_KEY, JSON.stringify(json.data));
          setIsOffline(false);
        }
      }
    } catch (err) {
      console.warn('Could not fetch latest campus data from server, falling back to cached local storage.', err);
      setIsOffline(true);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const updateCampusSection = async (section: string, newData: unknown, passcode: string) => {
    try {
      const res = await fetch('/api/campus-data/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section, data: newData, passcode })
      });
      const result = await res.json();
      if (res.ok && result.status === 'success') {
        setData(result.data);
        localStorage.setItem(LOCAL_STORAGE_DATA_KEY, JSON.stringify(result.data));
        return { success: true, message: 'Updated successfully' };
      }
      return { success: false, message: result.error || 'Update failed' };
    } catch {
      return { success: false, message: 'Network error occurred while saving.' };
    }
  };

  const addLaundryRecord = (record: Omit<LaundryTrackerRecord, 'id'>) => {
    const newRecord: LaundryTrackerRecord = {
      ...record,
      id: 'rec-' + Date.now()
    };
    setLaundryRecords(prev => [newRecord, ...prev]);
  };

  const updateLaundryStatus = (id: string, status: LaundryTrackerRecord['status']) => {
    setLaundryRecords(prev => prev.map(rec => rec.id === id ? { ...rec, status } : rec));
  };

  const deleteLaundryRecord = (id: string) => {
    setLaundryRecords(prev => prev.filter(rec => rec.id !== id));
  };

  return (
    <CampusContext.Provider
      value={{
        data,
        isLoading,
        isOffline,
        lastUpdated,
        refreshData,
        updateCampusSection,
        studentProfile,
        saveStudentProfile,
        logoutStudent,
        isProfileModalOpen,
        setIsProfileModalOpen,
        laundryRecords,
        addLaundryRecord,
        updateLaundryStatus,
        deleteLaundryRecord,
        isChatOpen,
        setIsChatOpen,
        chatInitialPrompt,
        setChatInitialPrompt,
      }}
    >
      {children}
    </CampusContext.Provider>
  );
};

export const useCampus = (): CampusContextType => {
  const context = useContext(CampusContext);
  if (!context) {
    throw new Error('useCampus must be used within a CampusProvider');
  }
  return context;
};
