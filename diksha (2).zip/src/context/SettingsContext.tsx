import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AppSettings, AccessibilitySettings } from '../types';

interface SettingsContextType {
  settings: AppSettings;
  setTheme: (theme: AppSettings['theme']) => void;
  setAccessibility: (updates: Partial<AccessibilitySettings>) => void;
  setAcademicYear: (year: string) => void;
  resetSettings: () => void;
  // Computed values
  effectiveTheme: 'light' | 'dark';
  currentTime: Date;
  timeZone: string;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'juit-guide-settings-v1';

const DEFAULT_ACCESSIBILITY: AccessibilitySettings = {
  textSize: 'default',
  reducedMotion: 'system',
  highContrast: 'system',
};

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'system',
  accessibility: DEFAULT_ACCESSIBILITY,
  academicYear: '2026-27',
};

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Merge with defaults to handle new keys
        return {
          ...DEFAULT_SETTINGS,
          ...parsed,
          accessibility: {
            ...DEFAULT_ACCESSIBILITY,
            ...(parsed.accessibility || {}),
          },
        };
      }
    } catch (e) {
      console.error('Failed to parse settings:', e);
    }
    return DEFAULT_SETTINGS;
  });

  const [systemTheme, setSystemTheme] = useState<'light' | 'dark'>(
    window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  );

  const [currentTime, setCurrentTime] = useState(new Date());

  // Update system theme listener
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemTheme(e.matches ? 'dark' : 'light');
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  // Update clock every minute
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  // Save settings to localStorage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  // Apply settings to document
  useEffect(() => {
    const root = window.document.documentElement;
    const effectiveTheme = settings.theme === 'system' ? systemTheme : settings.theme;

    // Apply theme
    if (effectiveTheme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }

    // Apply text size
    root.classList.remove('text-size-large', 'text-size-extra-large');
    if (settings.accessibility.textSize === 'large') {
      root.classList.add('text-size-large');
    } else if (settings.accessibility.textSize === 'extra-large') {
      root.classList.add('text-size-extra-large');
    }

    // Apply reduced motion
    const effectiveMotion = settings.accessibility.reducedMotion === 'system' 
      ? (window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'on' : 'off')
      : settings.accessibility.reducedMotion;
    
    if (effectiveMotion === 'on') {
      root.classList.add('reduced-motion');
    } else {
      root.classList.remove('reduced-motion');
    }

    // Apply high contrast
    const effectiveContrast = settings.accessibility.highContrast === 'system'
      ? (window.matchMedia('(prefers-contrast: more)').matches ? 'on' : 'off')
      : settings.accessibility.highContrast;

    if (effectiveContrast === 'on') {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
  }, [settings, systemTheme]);

  const setTheme = (theme: AppSettings['theme']) => {
    setSettings(prev => ({ ...prev, theme }));
  };

  const setAccessibility = (updates: Partial<AccessibilitySettings>) => {
    setSettings(prev => ({
      ...prev,
      accessibility: { ...prev.accessibility, ...updates },
    }));
  };

  const setAcademicYear = (academicYear: string) => {
    setSettings(prev => ({ ...prev, academicYear }));
  };

  const resetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
  };

  const effectiveTheme = settings.theme === 'system' ? systemTheme : settings.theme;
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  return (
    <SettingsContext.Provider
      value={{
        settings,
        setTheme,
        setAccessibility,
        setAcademicYear,
        resetSettings,
        effectiveTheme,
        currentTime,
        timeZone,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
