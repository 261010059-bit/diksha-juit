import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { MapNode, UserLocation, NavigationRoute, NavigationStep } from '../types';
import { GROUND_FLOOR_GRAPH } from '../data/mapData';

interface NavigationContextType {
  nodes: MapNode[];
  currentLocation: UserLocation;
  destination: string | null;
  route: NavigationRoute | null;
  isNavigating: boolean;
  setManualLocation: (nodeId: string) => void;
  setDestination: (nodeId: string | null) => void;
  scanQRCode: (code: string) => boolean;
  startNavigation: () => void;
  stopNavigation: () => void;
  recenter: () => void;
  isOutsideCampus: boolean;
  gpsStatus: 'idle' | 'locating' | 'success' | 'error';
  accuracy: number | null;
  isFollowing: boolean;
  setIsFollowing: (following: boolean) => void;
}

const NavigationContext = createContext<NavigationContextType | undefined>(undefined);

export const NavigationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [nodes] = useState<MapNode[]>(GROUND_FLOOR_GRAPH);
  const [currentLocation, setCurrentLocation] = useState<UserLocation>({
    nodeId: null,
    source: 'unknown',
    timestamp: Date.now()
  });
  const [destination, setDestinationState] = useState<string | null>(null);
  const [route, setRoute] = useState<NavigationRoute | null>(null);
  const [isNavigating, setIsNavigating] = useState(false);
  const [isOutsideCampus, setIsOutsideCampus] = useState(false);
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'locating' | 'success' | 'error'>('idle');
  const [accuracy, setAccuracy] = useState<number | null>(null);
  const [isFollowing, setIsFollowing] = useState(false);

  // JUIT Coordinates (approximate center of academic block)
  const JUIT_LAT = 31.0166;
  const JUIT_LNG = 77.0702;
  const CAMPUS_RADIUS_METERS = 500;

  useEffect(() => {
    if (navigator.geolocation) {
      setGpsStatus('locating');
      const watchId = navigator.geolocation.watchPosition(
        (pos) => {
          const { latitude, longitude, accuracy } = pos.coords;
          setAccuracy(accuracy);
          
          // Calculate distance to JUIT
          const dist = calculateDistance(latitude, longitude, JUIT_LAT, JUIT_LNG);
          if (dist > CAMPUS_RADIUS_METERS) {
            setIsOutsideCampus(true);
          } else {
            setIsOutsideCampus(false);
          }
          setGpsStatus('success');
        },
        () => {
          setGpsStatus('error');
        },
        { enableHighAccuracy: true }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, []);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // meters
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c;
  };

  const findPath = useCallback((startId: string, endId: string): string[] | null => {
    const queue: [string, string[]][] = [[startId, [startId]]];
    const visited = new Set<string>();

    while (queue.length > 0) {
      const [currentId, path] = queue.shift()!;
      if (currentId === endId) return path;

      if (!visited.has(currentId)) {
        visited.add(currentId);
        const node = nodes.find(n => n.id === currentId);
        if (node) {
          for (const conn of node.connections) {
            queue.push([conn.to, [...path, conn.to]]);
          }
        }
      }
    }
    return null;
  }, [nodes]);

  const generateInstructions = useCallback((path: string[]): NavigationStep[] => {
    const steps: NavigationStep[] = [];
    
    for (let i = 0; i < path.length; i++) {
      const currentId = path[i];
      const currentNode = nodes.find(n => n.id === currentId)!;
      
      if (i === 0) {
        steps.push({
          instruction: `Start at ${currentNode.name}.`,
          targetNodeId: currentId,
          type: 'start'
        });
        
        // Add immediate move instruction if path exists
        if (path.length > 1) {
          const nextNode = nodes.find(n => n.id === path[1])!;
          steps.push({
            instruction: `Walk toward the ${nextNode.name}.`,
            targetNodeId: path[1],
            type: 'move'
          });
        }
      } else if (i === path.length - 1) {
        const prevId = path[i-1];
        const prevNode = nodes.find(n => n.id === prevId)!;
        const connectionToCurrent = prevNode.connections.find(c => c.to === currentId);
        
        let sideText = '';
        if (connectionToCurrent?.side === 'left') sideText = ' on your LEFT';
        if (connectionToCurrent?.side === 'right') sideText = ' on your RIGHT';

        steps.push({
          instruction: `${currentNode.name} is${sideText}.`,
          targetNodeId: currentId,
          type: 'arrival'
        });
      } else {
        const nextId = path[i+1];
        const prevId = path[i-1];
        const connectionToNext = currentNode.connections.find(c => c.to === nextId);
        
        let directionText = 'Continue straight';
        if (connectionToNext?.direction.includes('left')) directionText = `Turn LEFT at the ${currentNode.name}`;
        if (connectionToNext?.direction.includes('right')) directionText = `Turn RIGHT at the ${currentNode.name}`;
        if (connectionToNext?.relationship === 'stairs') directionText = 'Take the stairs';
        if (connectionToNext?.relationship === 'lift') directionText = 'Take the lift';
        
        if (currentNode.type === 'corridor' && connectionToNext?.direction === 'straight') {
          directionText = `Continue along the hallway toward ${nodes.find(n => n.id === nextId)?.name}`;
        }

        steps.push({
          instruction: directionText,
          targetNodeId: currentId,
          type: 'move'
        });
      }
    }
    
    return steps.filter((step, index, self) => 
      index === 0 || step.instruction !== self[index-1].instruction
    );
  }, [nodes]);

  const setManualLocation = (nodeId: string) => {
    setCurrentLocation({
      nodeId,
      source: 'manual',
      timestamp: Date.now()
    });
  };

  const setDestination = (nodeId: string | null) => {
    setDestinationState(nodeId);
    if (!nodeId) {
      setRoute(null);
      setIsNavigating(false);
    }
  };

  const scanQRCode = (code: string): boolean => {
    const node = nodes.find(n => n.qrCode === code);
    if (node) {
      setCurrentLocation({
        nodeId: node.id,
        source: 'qr',
        timestamp: Date.now()
      });
      return true;
    }
    return false;
  };

  const startNavigation = () => {
    if (currentLocation.nodeId && destination) {
      const path = findPath(currentLocation.nodeId, destination);
      if (path) {
        setRoute({
          path,
          steps: generateInstructions(path)
        });
        setIsNavigating(true);
      }
    }
  };

  const stopNavigation = () => {
    setIsNavigating(false);
    setRoute(null);
  };

  const recenter = () => {
    // This will be handled by the component using this context
  };

  return (
    <NavigationContext.Provider value={{
      nodes,
      currentLocation,
      destination,
      route,
      isNavigating,
      setManualLocation,
      setDestination,
      scanQRCode,
      startNavigation,
      stopNavigation,
      recenter,
      isOutsideCampus,
      gpsStatus,
      accuracy,
      isFollowing,
      setIsFollowing
    }}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = () => {
  const context = useContext(NavigationContext);
  if (context === undefined) {
    throw new Error('useNavigation must be used within a NavigationProvider');
  }
  return context;
};
