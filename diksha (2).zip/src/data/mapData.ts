import { MapNode } from '../types';

export const GROUND_FLOOR_GRAPH: MapNode[] = [
  {
    id: 'main-entrance',
    name: 'Main Entrance',
    type: 'entrance',
    category: 'Entrance',
    description: 'The primary entry point to the academic block.',
    coordinates: { x: 50, y: 5 },
    isVerified: true,
    qrCode: 'JUIT-GF-MAIN-ENTRANCE',
    connections: [
      { to: 'audi', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'audi',
    name: 'Auditorium',
    type: 'room',
    category: 'Facility',
    description: 'The main university auditorium.',
    coordinates: { x: 50, y: 15 },
    isVerified: true,
    qrCode: 'JUIT-GF-AUDI',
    connections: [
      { to: 'main-entrance', direction: 'back', relationship: 'corridor' },
      { to: 'reception', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'reception',
    name: 'Reception area',
    type: 'poi',
    category: 'Admin',
    description: 'Information and reception desk.',
    coordinates: { x: 50, y: 25 },
    isVerified: true,
    qrCode: 'JUIT-GF-RECEPTION',
    branchDirection: 'right',
    connections: [
      { to: 'audi', direction: 'back', relationship: 'corridor' },
      { to: 'lift-area', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'lift-area',
    name: 'Restroom / Lift area',
    type: 'corridor',
    category: 'Transition',
    coordinates: { x: 50, y: 35 },
    isVerified: true,
    branchDirection: 'right', // Restroom is right
    connections: [
      { to: 'reception', direction: 'back', relationship: 'corridor' },
      { to: 'lift', direction: 'right', relationship: 'branch' },
      { to: 'stairs-1', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'lift',
    name: 'Lift',
    type: 'lift',
    category: 'Transition',
    coordinates: { x: 65, y: 35 },
    isVerified: true,
    qrCode: 'JUIT-GF-LIFT',
    connections: [
      { to: 'lift-area', direction: 'left', relationship: 'corridor' }
    ]
  },
  {
    id: 'stairs-1',
    name: 'Stairs 1',
    type: 'stairs',
    category: 'Transition',
    coordinates: { x: 50, y: 45 },
    isVerified: true,
    connections: [
      { to: 'lift-area', direction: 'back', relationship: 'corridor' },
      { to: 'lt2', direction: 'right', relationship: 'branch' },
      { to: 'saraswati-statue', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'lt2',
    name: 'LT2',
    type: 'room',
    category: 'Lecture Theater',
    description: 'Large Lecture Theater 2.',
    coordinates: { x: 75, y: 45 },
    isVerified: true,
    qrCode: 'JUIT-GF-LT2',
    branchDirection: 'right',
    keywords: ['lecture', 'theater', 'classroom', 'hall'],
    connections: [
      { to: 'stairs-1', direction: 'left', relationship: 'corridor' }
    ]
  },
  {
    id: 'saraswati-statue',
    name: 'Saraswati Mata Statue',
    type: 'poi',
    category: 'Landmark',
    description: 'The central landmark statue.',
    coordinates: { x: 50, y: 55 },
    isVerified: true,
    branchDirection: 'left',
    keywords: ['landmark', 'murti', 'statue', 'center'],
    connections: [
      { to: 'stairs-1', direction: 'back', relationship: 'corridor' },
      { to: 'lrc', direction: 'straight', relationship: 'corridor', side: 'right' },
      { to: 'drinking-water', direction: 'straight', relationship: 'corridor', side: 'left' }
    ]
  },
  {
    id: 'lrc',
    name: 'LRC',
    type: 'room',
    category: 'Library',
    description: 'Learning Resource Centre (Library).',
    coordinates: { x: 75, y: 65 },
    isVerified: true,
    qrCode: 'JUIT-GF-LRC',
    branchDirection: 'right',
    keywords: ['library', 'books', 'study', 'reading'],
    connections: [
      { to: 'saraswati-statue', direction: 'along-corridor', relationship: 'corridor' },
      { to: 'dlc', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'drinking-water',
    name: 'Drinking Water',
    type: 'poi',
    category: 'Amenity',
    coordinates: { x: 25, y: 65 },
    isVerified: true,
    branchDirection: 'left',
    keywords: ['water', 'pyaau', 'thirsty'],
    connections: [
      { to: 'saraswati-statue', direction: 'along-corridor', relationship: 'corridor' }
    ]
  },
  {
    id: 'dlc',
    name: 'DLC',
    type: 'room',
    category: 'Lab',
    description: 'Digital Learning Centre.',
    coordinates: { x: 75, y: 75 },
    isVerified: true,
    qrCode: 'JUIT-GF-DLC',
    branchDirection: 'right',
    keywords: ['lab', 'digital', 'computer'],
    connections: [
      { to: 'lrc', direction: 'back', relationship: 'corridor' },
      { to: 'lower-level', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'lower-level',
    name: 'Lower Level',
    type: 'corridor',
    category: 'Transition',
    coordinates: { x: 50, y: 85 },
    isVerified: true,
    qrCode: 'JUIT-GF-LOWER-LEVEL',
    branchDirection: 'right',
    keywords: ['basement', 'down', 'level'],
    connections: [
      { to: 'dlc', direction: 'back', relationship: 'corridor' },
      { to: 'cr1-stairs', direction: 'right', relationship: 'stairs', side: 'right' },
      { to: 'stairs-2', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'cr1-stairs',
    name: 'Stairs to CR1',
    type: 'stairs',
    category: 'Transition',
    coordinates: { x: 65, y: 85 },
    isVerified: true,
    keywords: ['stairs', 'up', 'cr1'],
    connections: [
      { to: 'lower-level', direction: 'left', relationship: 'corridor' },
      { to: 'cr1', direction: 'up', relationship: 'stairs', side: 'straight' }
    ]
  },
  {
    id: 'cr1',
    name: 'CR1',
    type: 'room',
    category: 'Classroom',
    description: 'Classroom 1 on the upper mezzanine.',
    coordinates: { x: 80, y: 85 },
    isVerified: true,
    qrCode: 'JUIT-GF-CR1',
    keywords: ['classroom', 'study', 'class'],
    connections: [
      { to: 'cr1-stairs', direction: 'down', relationship: 'stairs' }
    ]
  },
  {
    id: 'stairs-2',
    name: 'Stairs 2',
    type: 'stairs',
    category: 'Transition',
    coordinates: { x: 50, y: 95 },
    isVerified: true,
    qrCode: 'JUIT-GF-STAIRS-2',
    keywords: ['stairs', 'exit', 'green'],
    connections: [
      { to: 'lower-level', direction: 'back', relationship: 'corridor' },
      { to: 'door-to-green', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'door-to-green',
    name: 'Door to Green',
    type: 'entrance',
    category: 'Exit',
    description: 'Exit towards the green area.',
    coordinates: { x: 25, y: 105 },
    isVerified: true,
    branchDirection: 'left',
    keywords: ['exit', 'green', 'outside', 'door'],
    connections: [
      { to: 'stairs-2', direction: 'along-corridor', relationship: 'corridor' },
      { to: 'cr3-cr4', direction: 'straight', relationship: 'corridor', side: 'left' }
    ]
  },
  {
    id: 'cr3-cr4',
    name: 'CR3 / CR4',
    type: 'room',
    category: 'Classroom',
    coordinates: { x: 25, y: 115 },
    isVerified: true,
    branchDirection: 'left',
    keywords: ['classroom', 'class', 'study'],
    connections: [
      { to: 'door-to-green', direction: 'back', relationship: 'corridor' },
      { to: 'cl8-cl9', direction: 'straight', relationship: 'corridor', side: 'right' }
    ]
  },
  {
    id: 'cl8-cl9',
    name: 'CL8 / CL9',
    type: 'room',
    category: 'Lab',
    coordinates: { x: 75, y: 125 },
    isVerified: true,
    branchDirection: 'right',
    keywords: ['lab', 'computer', 'digital'],
    connections: [
      { to: 'cr3-cr4', direction: 'back', relationship: 'corridor' },
      { to: 'admission-cell', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'admission-cell',
    name: 'Admission Cell',
    type: 'room',
    category: 'Admin',
    coordinates: { x: 50, y: 135 },
    isVerified: true,
    qrCode: 'JUIT-GF-ADMISSION',
    keywords: ['admission', 'admin', 'office', 'help'],
    connections: [
      { to: 'cl8-cl9', direction: 'back', relationship: 'corridor' },
      { to: 'parents-lounge', direction: 'straight', relationship: 'corridor' }
    ]
  },
  {
    id: 'parents-lounge',
    name: 'Parents Lounge',
    type: 'room',
    category: 'Admin',
    coordinates: { x: 50, y: 145 },
    isVerified: true,
    qrCode: 'JUIT-GF-PARENTS-LOUNGE',
    keywords: ['parents', 'lounge', 'waiting', 'admin'],
    connections: [
      { to: 'admission-cell', direction: 'back', relationship: 'corridor' }
    ]
  }
];
