import { EvenSemData } from '../types';

export const EVEN_SEM_2026_DATA: EvenSemData = {
  "semesterOptions": [
    {
      "id": "btech_2",
      "name": "B.Tech 2nd Sem",
      "year": "1st Year"
    },
    {
      "id": "btech_4",
      "name": "B.Tech 4th Sem",
      "year": "2nd Year"
    },
    {
      "id": "btech_6",
      "name": "B.Tech 6th Sem",
      "year": "3rd Year"
    },
    {
      "id": "btech_8",
      "name": "B.Tech 8th Sem",
      "year": "4th Year"
    },
    {
      "id": "mtech_2",
      "name": "M.Tech / M.Sc 2nd Sem",
      "year": "PG 1st Year"
    },
    {
      "id": "mtech_4",
      "name": "M.Tech / M.Sc 4th Sem & PhD",
      "year": "PG 2nd Year"
    }
  ],
  "sessions": [
    {
      "id": "btech_2_MON_2_17wdt0",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "PKP",
      "room": "DLC,LT2",
      "raw": "L-25B11MA211   25BT04,25BT05,25BT06   (PKP) DLC,LT2"
    },
    {
      "id": "btech_2_MON_6_e9q3va",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT11"
      ],
      "faculty": "FSL",
      "room": "CL5_2",
      "raw": "P-25B17CI271 25BT11 (FSL) CL5_2"
    },
    {
      "id": "btech_2_MON_7_bdxlgi",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT11"
      ],
      "faculty": "FSL",
      "room": "CL5_2",
      "raw": "P-25B17CI271 25BT11 (FSL) CL5_2"
    },
    {
      "id": "btech_2_MON_0_dssw24",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT02"
      ],
      "faculty": "HSR",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT02 (HSR) PHLAB2"
    },
    {
      "id": "btech_2_MON_1_myovwt",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT02"
      ],
      "faculty": "HSR",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT02 (HSR) PHLAB2"
    },
    {
      "id": "btech_2_MON_2_gws0ta",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI212",
      "batches": [
        "25BT20",
        "25BT21"
      ],
      "faculty": "SSA",
      "room": "CR17",
      "raw": "T-25B11CI212 25BT20,25BT21 (SSA) CR17"
    },
    {
      "id": "btech_2_MON_4_83fvl1",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "24B11EC211",
      "batches": [
        "BACK_ECE"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "L-24B11EC211 BACK_ECE (RKU) TR4"
    },
    {
      "id": "btech_2_MON_5_kqptv2",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT22"
      ],
      "faculty": "SSA",
      "room": "TR2",
      "raw": "T-25B11CI211 25BT22 (SSA) TR2"
    },
    {
      "id": "btech_2_MON_1_96wrhg",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "SKK",
      "room": "CR6",
      "raw": "L-18B11PH211 25BT10,25BT11,25BT12 (SKK) CR6"
    },
    {
      "id": "btech_2_MON_2_d7c14d",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "HSR",
      "room": "CR6",
      "raw": "L-18B11PH211 25BT13,25BT14,25BT15 (HSR) CR6"
    },
    {
      "id": "btech_2_MON_3_0zb1mn",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "23BB1HS211",
      "batches": [
        "25W11"
      ],
      "faculty": "TNS",
      "room": "DLC,CR12",
      "raw": "L-23BB1HS211 25W11 (TNS) DLC,CR12"
    },
    {
      "id": "btech_2_MON_6_ontky0",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25BC1CI212/25B11CI415",
      "batches": [
        "25Q11",
        "24H11"
      ],
      "faculty": "DBK",
      "room": "CR12",
      "raw": "T-25BC1CI212/25B11CI415 25Q11,24H11 (DBK) CR12"
    },
    {
      "id": "btech_2_MON_7_5ba946",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT12"
      ],
      "faculty": "SKK",
      "room": "TR1",
      "raw": "T-18B11PH211 25BT12 (SKK) TR1"
    },
    {
      "id": "btech_2_MON_1_9da666",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "24B11MA212",
      "batches": [
        "25BT20",
        "25BT21",
        "25BT22"
      ],
      "faculty": "MDS",
      "room": "CR16",
      "raw": "L-24B11MA212 25BT20,25BT21,25BT22 (MDS) CR16"
    },
    {
      "id": "btech_2_MON_4_711kcj",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT13"
      ],
      "faculty": "HSR",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT13 (HSR) PHLAB1"
    },
    {
      "id": "btech_2_MON_5_j3piu2",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT13"
      ],
      "faculty": "HSR",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT13 (HSR) PHLAB1"
    },
    {
      "id": "btech_2_MON_1_gldprb",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "23BB1HS213",
      "batches": [
        "25W11"
      ],
      "faculty": "TGM",
      "room": "TR6",
      "raw": "L-23BB1HS213 25W11 (TGM) TR6"
    },
    {
      "id": "btech_2_MON_6_r9d6j0",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT15"
      ],
      "faculty": "SKT",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT15 (SKT) PHLAB1"
    },
    {
      "id": "btech_2_MON_7_pfpb40",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT15"
      ],
      "faculty": "SKT",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT15 (SKT) PHLAB1"
    },
    {
      "id": "btech_2_MON_0_hox7m4",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25BC7CI271",
      "batches": [
        "25Q11"
      ],
      "faculty": "RIV",
      "room": "CL5_1",
      "raw": "P-25BC7CI271 25Q11 (RIV) CL5_1"
    },
    {
      "id": "btech_2_MON_1_feqyf5",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25BC7CI271",
      "batches": [
        "25Q11"
      ],
      "faculty": "RIV",
      "room": "CL5_1",
      "raw": "P-25BC7CI271 25Q11 (RIV) CL5_1"
    },
    {
      "id": "btech_2_MON_2_d9kijd",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25BC1CI212/25B11CI415",
      "batches": [
        "25Q11",
        "24H11"
      ],
      "faculty": "DBK",
      "room": "CR11",
      "raw": "L-25BC1CI212/25B11CI415 25Q11,24H11 (DBK) CR11"
    },
    {
      "id": "btech_2_MON_4_8df97f",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT01",
        "25BT02"
      ],
      "faculty": "ABC",
      "room": "CR18",
      "raw": "T-23B11HS211 25BT01,25BT02 (ABC) CR18"
    },
    {
      "id": "btech_2_MON_6_vx5dg6",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT12"
      ],
      "faculty": "NKT",
      "room": "TR5",
      "raw": "T-25B11MA211 25BT12 (NKT) TR5"
    },
    {
      "id": "btech_2_MON_1_4jpyid",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT09"
      ],
      "faculty": "RKB",
      "room": "TR2",
      "raw": "T-25B11MA211 25BT09 (RKB) TR2"
    },
    {
      "id": "btech_2_MON_2_zrpkxi",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT10"
      ],
      "faculty": "HR4",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT10 (HR4) LANGULAB"
    },
    {
      "id": "btech_2_MON_3_9vfg25",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT04"
      ],
      "faculty": "HAZ",
      "room": "CR17",
      "raw": "T-18B11PH211 25BT04 (HAZ) CR17"
    },
    {
      "id": "btech_2_MON_5_fhy1j6",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT05"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT05 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_MON_6_6lzqaa",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT05"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT05 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_MON_7_4dymkj",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT05"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT05 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_MON_0_j19y14",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT20"
      ],
      "faculty": "HR1",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT20 (HR1) GDROOM"
    },
    {
      "id": "btech_2_MON_1_hnbt97",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "RAD",
      "room": "CR5",
      "raw": "L-25B11MA211   25BT13,25BT14,25BT15 (RAD) CR5"
    },
    {
      "id": "btech_2_MON_6_uqjkhp",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT02"
      ],
      "faculty": "DGA",
      "room": "CL9_2",
      "raw": "P-25B17CI271 25BT02 (DGA) CL9_2"
    },
    {
      "id": "btech_2_MON_7_ejst7c",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT02"
      ],
      "faculty": "DGA",
      "room": "CL9_2",
      "raw": "P-25B17CI271 25BT02 (DGA) CL9_2"
    },
    {
      "id": "btech_2_MON_0_z8xwi4",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT01"
      ],
      "faculty": "RS3",
      "room": "TR3",
      "raw": "T-25B11MA211 25BT01 (RS3) TR3"
    },
    {
      "id": "btech_2_MON_2_wan8rl",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT02"
      ],
      "faculty": "PBB",
      "room": "TR2",
      "raw": "T-18B11PH211 25BT02 (PBB) TR2"
    },
    {
      "id": "btech_2_MON_4_ecivwv",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09",
        "BACK"
      ],
      "faculty": "SBA",
      "room": "DLC,CR8",
      "raw": "L-18B11PH211   25BT07,25BT08,25BT09,BACK (SBA) DLC,CR8"
    },
    {
      "id": "btech_2_MON_5_ztm0yk",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "FSL",
      "room": "CR8",
      "raw": "L-25B11CI211 25BT10,25BT11,25BT12 (FSL) CR8"
    },
    {
      "id": "btech_2_MON_6_i8a2bl",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "ABC",
      "room": "CR11",
      "raw": "T-23B11HS211 25BT21,25BT22 (ABC) CR11"
    },
    {
      "id": "btech_2_MON_1_fwk24t",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT17",
        "25BT18"
      ],
      "faculty": "RTK",
      "room": "CR11",
      "raw": "T-23B11HS211 25BT17,25BT18 (RTK) CR11"
    },
    {
      "id": "btech_2_MON_2_w93d0q",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT11"
      ],
      "faculty": "NKT",
      "room": "TR5",
      "raw": "T-25B11MA211 25BT11 (NKT) TR5"
    },
    {
      "id": "btech_2_MON_4_3lk93g",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WPH532",
      "batches": [
        "AMS_BACK"
      ],
      "faculty": "VSA",
      "room": "TR7",
      "raw": "L-18B1WPH532 AMS_BACK (VSA) TR7"
    },
    {
      "id": "btech_2_MON_5_mluian",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT06"
      ],
      "faculty": "PLK",
      "room": "TR5",
      "raw": "T-25B11CI211   25BT06 (PLK) TR5"
    },
    {
      "id": "btech_2_MON_6_jjip70",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT16"
      ],
      "faculty": "RIV",
      "room": "CL3_2",
      "raw": "P-25B17CI271 25BT16 (RIV) CL3_2"
    },
    {
      "id": "btech_2_MON_7_eboefy",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT16"
      ],
      "faculty": "RIV",
      "room": "CL3_2",
      "raw": "P-25B17CI271 25BT16 (RIV) CL3_2"
    },
    {
      "id": "btech_2_MON_0_62oclj",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT03"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT03 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_2_MON_1_xc9r74",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT03"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT03 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_2_MON_2_xg9k55",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT03"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT03 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_2_MON_4_0k508n",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT11"
      ],
      "faculty": "FSL",
      "room": "TR1",
      "raw": "T-25B11CI211 25BT11 (FSL) TR1"
    },
    {
      "id": "btech_2_MON_5_xg6o70",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT17"
      ],
      "faculty": "HAZ",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT17 (HAZ) PHLAB2"
    },
    {
      "id": "btech_2_MON_6_bolg57",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT17"
      ],
      "faculty": "HAZ",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT17 (HAZ) PHLAB2"
    },
    {
      "id": "btech_2_MON_7_tshlz1",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH212",
      "batches": [
        "25BT20",
        "25BT21",
        "25BT22"
      ],
      "faculty": "RRS",
      "room": "DLC,CR12",
      "raw": "L-18B11PH212 25BT20,25BT21,25BT22 (RRS) DLC,CR12"
    },
    {
      "id": "btech_2_MON_1_33q287",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "ABC",
      "room": "CR4",
      "raw": "L-23B11HS211   25BT04,25BT05,25BT06   (ABC) CR4"
    },
    {
      "id": "btech_2_MON_2_vg01aq",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09"
      ],
      "faculty": "RKB",
      "room": "CR2",
      "raw": "L-25B11MA211   25BT07,25BT08,25BT09   (RKB) CR2"
    },
    {
      "id": "btech_2_MON_5_1p5or0",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT15"
      ],
      "faculty": "RAD",
      "room": "TR6",
      "raw": "T-25B11MA211 25BT15 (RAD) TR6"
    },
    {
      "id": "btech_2_MON_6_5e1btk",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT04"
      ],
      "faculty": "PKP",
      "room": "TR2",
      "raw": "T-25B11MA211 25BT04 (PKP) TR2"
    },
    {
      "id": "btech_2_MON_7_r29doq",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT03",
        "25BT04"
      ],
      "faculty": "NJL",
      "room": "CR11",
      "raw": "T-23B11HS211 25BT03,25BT04 (NJL) CR11"
    },
    {
      "id": "btech_2_MON_0_jbtbs1",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "PLK",
      "room": "CR9",
      "raw": "L-25B11CI211   25BT04,25BT05,25BT06   (PLK) CR9"
    },
    {
      "id": "btech_2_MON_1_7jub98",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT16"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT16 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_MON_2_3bwbzq",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT16"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT16 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_MON_3_4lagt8",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT16"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT16 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_MON_4_ztvg7a",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT17"
      ],
      "faculty": "AKS",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT17 (AKS) GDROOM"
    },
    {
      "id": "btech_2_MON_5_piauzo",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT14"
      ],
      "faculty": "AKR",
      "room": "TR4",
      "raw": "T-25B11CI211 25BT14 (AKR) TR4"
    },
    {
      "id": "btech_2_MON_6_1fecs5",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT06"
      ],
      "faculty": "PLK",
      "room": "CL8_2",
      "raw": "P-25B17CI271 25BT06 (PLK) CL8_2"
    },
    {
      "id": "btech_2_MON_7_mctdg0",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT06"
      ],
      "faculty": "PLK",
      "room": "CL8_2",
      "raw": "P-25B17CI271 25BT06 (PLK) CL8_2"
    },
    {
      "id": "btech_2_MON_3_w8sy48",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "HR6",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT21,25BT22 (HR6) LANGULAB"
    },
    {
      "id": "btech_2_MON_6_sm1kzd",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "23BB1HS213",
      "batches": [
        "25W11"
      ],
      "faculty": "TGM",
      "room": "TR7",
      "raw": "T-23BB1HS213 25W11 (TGM) TR7"
    },
    {
      "id": "btech_2_MON_0_k3ple7",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT15"
      ],
      "faculty": "HR5",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT15 (HR5) LANGULAB"
    },
    {
      "id": "btech_2_MON_1_13giqa",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT08"
      ],
      "faculty": "NSA",
      "room": "TR4",
      "raw": "T-25B11CI211   25BT08 (NSA) TR4"
    },
    {
      "id": "btech_2_MON_3_vpti40",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT19"
      ],
      "faculty": "VDN",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT19 (VDN) GDROOM"
    },
    {
      "id": "btech_2_MON_5_qjiidf",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT19"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT19 (ABJ) WORKLAB"
    },
    {
      "id": "btech_2_MON_6_mpjftg",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT19"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT19 (ABJ) WORKLAB"
    },
    {
      "id": "btech_2_MON_7_dfjsgx",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT19"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT19 (ABJ) WORKLAB"
    },
    {
      "id": "btech_2_MON_2_ilfomn",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT12"
      ],
      "faculty": "NJL",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT12 (NJL) GDROOM"
    },
    {
      "id": "btech_2_MON_6_cry20m",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT14"
      ],
      "faculty": "AKR",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT14 (AKR) CL5_1"
    },
    {
      "id": "btech_2_MON_7_md7cfv",
      "semesterId": "btech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT14"
      ],
      "faculty": "AKR",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT14 (AKR) CL5_1"
    },
    {
      "id": "btech_2_TUE_0_5hskwb",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18"
      ],
      "faculty": "HST",
      "room": "LT2",
      "raw": "L-25B11CI211 25BT16,25BT17,25BT18 (HST) LT2"
    },
    {
      "id": "btech_2_TUE_1_1c5742",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT09",
        "25BT10"
      ],
      "faculty": "HR1",
      "room": "CR8",
      "raw": "T-23B11HS211 25BT09,25BT10 (HR1) CR8"
    },
    {
      "id": "btech_2_TUE_2_wrjqj8",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI272",
      "batches": [
        "25BT20"
      ],
      "faculty": "RIV",
      "room": "CL8_1",
      "raw": "P-25B17CI272 25BT20 (RIV) CL8_1"
    },
    {
      "id": "btech_2_TUE_3_xdyu5r",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI272",
      "batches": [
        "25BT20"
      ],
      "faculty": "RIV",
      "room": "CL8_1",
      "raw": "P-25B17CI272 25BT20 (RIV) CL8_1"
    },
    {
      "id": "btech_2_TUE_0_p019ci",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT09"
      ],
      "faculty": "AKS",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT09 (AKS) GDROOM"
    },
    {
      "id": "btech_2_TUE_1_68fajb",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "PBB",
      "room": "CR9",
      "raw": "L-18B11PH211   25BT01,25BT02,25BT03    (PBB) CR9"
    },
    {
      "id": "btech_2_TUE_2_atdrqg",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT01"
      ],
      "faculty": "DGA",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT01 (DGA) CL5_1"
    },
    {
      "id": "btech_2_TUE_3_l8sgb4",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT01"
      ],
      "faculty": "DGA",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT01 (DGA) CL5_1"
    },
    {
      "id": "btech_2_TUE_5_unij1g",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09"
      ],
      "faculty": "NSA",
      "room": "DLC,CR10",
      "raw": "L-25B11CI211   25BT07,25BT08,25BT09   (NSA) DLC,CR10"
    },
    {
      "id": "btech_2_TUE_6_hy6nzh",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT02"
      ],
      "faculty": "RS5",
      "room": "TR7",
      "raw": "T-25B11MA211 25BT02 (RS5) TR7"
    },
    {
      "id": "btech_2_TUE_7_s5yfm5",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT07"
      ],
      "faculty": "AKS",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT07 (AKS) GDROOM"
    },
    {
      "id": "btech_2_TUE_0_k4lcsw",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT08"
      ],
      "faculty": "NSA",
      "room": "CL8_2",
      "raw": "P-25B17CI271 25BT08 (NSA) CL8_2"
    },
    {
      "id": "btech_2_TUE_1_cgwu0f",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT08"
      ],
      "faculty": "NSA",
      "room": "CL8_2",
      "raw": "P-25B17CI271 25BT08 (NSA) CL8_2"
    },
    {
      "id": "btech_2_TUE_2_em2bat",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "AKR",
      "room": "CR10",
      "raw": "L-25B11CI211 25BT13,25BT14,25BT15 (AKR) CR10"
    },
    {
      "id": "btech_2_TUE_5_a47b9d",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT12"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT12 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_TUE_6_rx4asi",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT12"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT12 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_TUE_7_336y90",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT12"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT12 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_TUE_0_6740j0",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT14"
      ],
      "faculty": "HR5",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT14 (HR5) LANGULAB"
    },
    {
      "id": "btech_2_TUE_1_lyl3ju",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "RAD",
      "room": "CR5",
      "raw": "L-25B11MA211   25BT13,25BT14,25BT15 (RAD) CR5"
    },
    {
      "id": "btech_2_TUE_3_obzuov",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "23BB1HS211",
      "batches": [
        "25W11"
      ],
      "faculty": "TNS",
      "room": "DLC,CR16",
      "raw": "L-23BB1HS211 25W11 (TNS) DLC,CR16"
    },
    {
      "id": "btech_2_TUE_4_842tqv",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09",
        "BACK"
      ],
      "faculty": "SBA",
      "room": "CR8",
      "raw": "L-18B11PH211   25BT07,25BT08,25BT09,BACK (SBA) CR8"
    },
    {
      "id": "btech_2_TUE_5_yswia5",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25BC1CI211",
      "batches": [
        "25Q11"
      ],
      "faculty": "SRT",
      "room": "TR7",
      "raw": "L-25BC1CI211 25Q11 (SRT) TR7"
    },
    {
      "id": "btech_2_TUE_6_s4x5f4",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT20",
        "25BT21",
        "25BT22",
        "25Q11",
        "25W11"
      ],
      "faculty": "RTK",
      "room": "DLC,LT2",
      "raw": "L-23B11HS211 25BT20,25BT21,25BT22,25Q11,25W11 (RTK) DLC,LT2"
    },
    {
      "id": "btech_2_TUE_0_4aitao",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "MDS",
      "room": "CR9",
      "raw": "L-25B11MA211   25BT01,25BT02,25BT03    (MDS) CR9"
    },
    {
      "id": "btech_2_TUE_2_0520k3",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT171",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "HSD",
      "room": "UG2",
      "raw": "P-25B17BT171 25BT21,25BT22 (HSD) UG2"
    },
    {
      "id": "btech_2_TUE_3_dgrng8",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT171",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "HSD",
      "room": "UG2",
      "raw": "P-25B17BT171 25BT21,25BT22 (HSD) UG2"
    },
    {
      "id": "btech_2_TUE_5_tlrc5t",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT13"
      ],
      "faculty": "RAD",
      "room": "TR6",
      "raw": "T-25B11MA211 25BT13 (RAD) TR6"
    },
    {
      "id": "btech_2_TUE_6_c0reqy",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT18"
      ],
      "faculty": "SKT",
      "room": "TR1",
      "raw": "T-18B11PH211 25BT18 (SKT) TR1"
    },
    {
      "id": "btech_2_TUE_7_v7kjmi",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "DGA",
      "room": "CR7",
      "raw": "L-25B11CI211   25BT01,25BT02,25BT03    (DGA) CR7"
    },
    {
      "id": "btech_2_TUE_0_k0emfy",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT06"
      ],
      "faculty": "RRS",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT06 (RRS) PHLAB2"
    },
    {
      "id": "btech_2_TUE_1_so2lj0",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT06"
      ],
      "faculty": "RRS",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT06 (RRS) PHLAB2"
    },
    {
      "id": "btech_2_TUE_5_air2n7",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT06"
      ],
      "faculty": "HAZ",
      "room": "TR4",
      "raw": "T-18B11PH211 25BT06 (HAZ) TR4"
    },
    {
      "id": "btech_2_TUE_6_vol4pb",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT06"
      ],
      "faculty": "PKP",
      "room": "TR4",
      "raw": "T-25B11MA211 25BT06 (PKP) TR4"
    },
    {
      "id": "btech_2_TUE_0_3aqp45",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25BC1CI213",
      "batches": [
        "25Q11"
      ],
      "faculty": "SRT",
      "room": "CR11",
      "raw": "L-25BC1CI213 25Q11 (SRT) CR11"
    },
    {
      "id": "btech_2_TUE_2_1l4vpq",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT03"
      ],
      "faculty": "RS4",
      "room": "TR3",
      "raw": "T-25B11MA211 25BT03 (RS4) TR3"
    },
    {
      "id": "btech_2_TUE_3_ojv1pf",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT19"
      ],
      "faculty": "RS6",
      "room": "CR12",
      "raw": "T-25B11MA211 25BT19 (RS6) CR12"
    },
    {
      "id": "btech_2_TUE_5_o69jpa",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT15"
      ],
      "faculty": "ASR",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT15 (ASR) WORKLAB"
    },
    {
      "id": "btech_2_TUE_6_knzvn0",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT15"
      ],
      "faculty": "ASR",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT15 (ASR) WORKLAB"
    },
    {
      "id": "btech_2_TUE_7_t16pz0",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT15"
      ],
      "faculty": "ASR",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT15 (ASR) WORKLAB"
    },
    {
      "id": "btech_2_TUE_0_dy0bg7",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT07"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT07 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_TUE_1_4cia41",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT07"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT07 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_TUE_2_d5ld38",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT07"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT07 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_TUE_4_j2b25c",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT10"
      ],
      "faculty": "FSL",
      "room": "CL8_2",
      "raw": "P-25B17CI271 25BT10 (FSL) CL8_2"
    },
    {
      "id": "btech_2_TUE_5_w48dch",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT10"
      ],
      "faculty": "FSL",
      "room": "CL8_2",
      "raw": "P-25B17CI271 25BT10 (FSL) CL8_2"
    },
    {
      "id": "btech_2_TUE_7_dotirr",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT08"
      ],
      "faculty": "SBA",
      "room": "TR6",
      "raw": "T-18B11PH211 25BT08 (SBA) TR6"
    },
    {
      "id": "btech_2_TUE_0_dhqakr",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT05"
      ],
      "faculty": "PLK",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT05 (PLK) CL5_1"
    },
    {
      "id": "btech_2_TUE_1_fdakmp",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT05"
      ],
      "faculty": "PLK",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT05 (PLK) CL5_1"
    },
    {
      "id": "btech_2_TUE_2_c5tgum",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25BC7CI273",
      "batches": [
        "25Q11"
      ],
      "faculty": "SRT",
      "room": "CL3_1",
      "raw": "P-25BC7CI273 25Q11 (SRT) CL3_1"
    },
    {
      "id": "btech_2_TUE_3_t4fsiu",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25BC7CI273",
      "batches": [
        "25Q11"
      ],
      "faculty": "SRT",
      "room": "CL3_1",
      "raw": "P-25BC7CI273 25Q11 (SRT) CL3_1"
    },
    {
      "id": "btech_2_TUE_5_38oo2n",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT20"
      ],
      "faculty": "HR6",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT20 (HR6) LANGULAB"
    },
    {
      "id": "btech_2_TUE_6_zhwve1",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT09"
      ],
      "faculty": "PBB",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT09 (PBB) PHLAB2"
    },
    {
      "id": "btech_2_TUE_7_uwb9xr",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT09"
      ],
      "faculty": "PBB",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT09 (PBB) PHLAB2"
    },
    {
      "id": "btech_2_TUE_0_njhi5h",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT15"
      ],
      "faculty": "HSR",
      "room": "TR1",
      "raw": "L-18B11PH211 25BT15 (HSR) TR1"
    },
    {
      "id": "btech_2_TUE_1_7ysb3q",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA213",
      "batches": [
        "25Q11",
        "24P11"
      ],
      "faculty": "NKT",
      "room": "CR16",
      "raw": "L-25B11MA213 25Q11,24P11 (NKT) CR16"
    },
    {
      "id": "btech_2_TUE_2_4iodjf",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "SKK",
      "room": "CR2",
      "raw": "L-18B11PH211 25BT10,25BT11,25BT12 (SKK) CR2"
    },
    {
      "id": "btech_2_TUE_4_hizeek",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT18"
      ],
      "faculty": "VSA",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT18 (VSA) PHLAB2"
    },
    {
      "id": "btech_2_TUE_5_u69g4m",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT18"
      ],
      "faculty": "VSA",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT18 (VSA) PHLAB2"
    },
    {
      "id": "btech_2_TUE_6_7waegt",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT10"
      ],
      "faculty": "SKK",
      "room": "TR3",
      "raw": "T-18B11PH211 25BT10 (SKK) TR3"
    },
    {
      "id": "btech_2_TUE_7_0hffv1",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT10"
      ],
      "faculty": "FSL",
      "room": "TR7",
      "raw": "T-25B11CI211 25BT10 (FSL) TR7"
    },
    {
      "id": "btech_2_TUE_2_uydj3f",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT05"
      ],
      "faculty": "HAZ",
      "room": "TR4",
      "raw": "T-18B11PH211 25BT05 (HAZ) TR4"
    },
    {
      "id": "btech_2_TUE_3_xyptpt",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "HSR",
      "room": "CR6",
      "raw": "L-18B11PH211 25BT13,25BT14,25BT15 (HSR) CR6"
    },
    {
      "id": "btech_2_TUE_6_anmquf",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT07",
        "25BT08"
      ],
      "faculty": "ABC",
      "room": "CR11",
      "raw": "T-23B11HS211 25BT07,25BT08 (ABC) CR11"
    },
    {
      "id": "btech_2_TUE_7_g0enwr",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT13"
      ],
      "faculty": "AKR",
      "room": "TR1",
      "raw": "T-25B11CI211 25BT13 (AKR) TR1"
    },
    {
      "id": "btech_2_TUE_1_pvx1pn",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18",
        "25BT19"
      ],
      "faculty": "MDS",
      "room": "LT3",
      "raw": "L-25B11MA211 25BT16,25BT17,25BT18,25BT19 (MDS) LT3"
    },
    {
      "id": "btech_2_TUE_5_4y07s2",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT19",
        "25BT22"
      ],
      "faculty": "SSA",
      "room": "CR8",
      "raw": "L-25B11CI211 25BT19,25BT22 (SSA) CR8"
    },
    {
      "id": "btech_2_TUE_0_iyy7pl",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "NKT",
      "room": "CR6",
      "raw": "L-25B11MA211 25BT10,25BT11,25BT12 (NKT) CR6"
    },
    {
      "id": "btech_2_TUE_2_piiu8t",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18",
        "25BT19"
      ],
      "faculty": "SKT",
      "room": "LT2",
      "raw": "L-18B11PH211 25BT16,25BT17,25BT18,25BT19 (SKT) LT2"
    },
    {
      "id": "btech_2_TUE_7_b71p1i",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA213",
      "batches": [
        "25Q11",
        "24P11"
      ],
      "faculty": "NKT",
      "room": "CR16",
      "raw": "T-25B11MA213 25Q11,24P11 (NKT) CR16"
    },
    {
      "id": "btech_2_TUE_1_pewr7l",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "23BB1HS213",
      "batches": [
        "25W11"
      ],
      "faculty": "TGM",
      "room": "TR5",
      "raw": "L-23BB1HS213 25W11 (TGM) TR5"
    },
    {
      "id": "btech_2_TUE_3_co9xvl",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "PLK",
      "room": "CR8",
      "raw": "L-25B11CI211   25BT04,25BT05,25BT06   (PLK) CR8"
    },
    {
      "id": "btech_2_TUE_5_850o2y",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT02"
      ],
      "faculty": "DGA",
      "room": "TR3",
      "raw": "T-25B11CI211   25BT02 (DGA) TR3"
    },
    {
      "id": "btech_2_TUE_7_5sy9ot",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH212",
      "batches": [
        "25BT20",
        "25BT21",
        "25BT22"
      ],
      "faculty": "RRS",
      "room": "CR11",
      "raw": "L-18B11PH212 25BT20,25BT21,25BT22 (RRS) CR11"
    },
    {
      "id": "btech_2_TUE_0_kkr4hd",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT04"
      ],
      "faculty": "HAZ",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT04 (HAZ) PHLAB1"
    },
    {
      "id": "btech_2_TUE_1_0wm60u",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT04"
      ],
      "faculty": "HAZ",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT04 (HAZ) PHLAB1"
    },
    {
      "id": "btech_2_TUE_2_5m78i4",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT04"
      ],
      "faculty": "HR2",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT04 (HR2) LANGULAB"
    },
    {
      "id": "btech_2_TUE_5_y1duqt",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23BB1HS212",
      "batches": [
        "25W11"
      ],
      "faculty": "ASA",
      "room": "TR5",
      "raw": "L-23BB1HS212 25W11 (ASA) TR5"
    },
    {
      "id": "btech_2_TUE_2_jzomur",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT08"
      ],
      "faculty": "RKB",
      "room": "TR6",
      "raw": "T-25B11MA211 25BT08 (RKB) TR6"
    },
    {
      "id": "btech_2_TUE_6_ziqb9a",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT14"
      ],
      "faculty": "HSR",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT14 (HSR) PHLAB1"
    },
    {
      "id": "btech_2_TUE_7_cgb9y0",
      "semesterId": "btech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT14"
      ],
      "faculty": "HSR",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT14 (HSR) PHLAB1"
    },
    {
      "id": "btech_2_WED_5_llidcu",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT12"
      ],
      "faculty": "FSL",
      "room": "TR1",
      "raw": "T-25B11CI211 25BT12 (FSL) TR1"
    },
    {
      "id": "btech_2_WED_0_t5yts0",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "PKP",
      "room": "CR4",
      "raw": "L-25B11MA211   25BT04,25BT05,25BT06   (PKP) CR4"
    },
    {
      "id": "btech_2_WED_2_sa7bv1",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18",
        "25BT19"
      ],
      "faculty": "MDS",
      "room": "LT3",
      "raw": "L-25B11MA211 25BT16,25BT17,25BT18,25BT19 (MDS) LT3"
    },
    {
      "id": "btech_2_WED_3_nm3pjn",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18",
        "25BT19"
      ],
      "faculty": "SKT",
      "room": "DLC,LT3",
      "raw": "L-18B11PH211 25BT16,25BT17,25BT18,25BT19 (SKT) DLC,LT3"
    },
    {
      "id": "btech_2_WED_4_j8p5x1",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT04"
      ],
      "faculty": "TGM",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT04 (TGM) GDROOM"
    },
    {
      "id": "btech_2_WED_5_hjgfol",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI212",
      "batches": [
        "25BT20",
        "25BT21"
      ],
      "faculty": "SSA",
      "room": "CR17",
      "raw": "L-25B11CI212 25BT20,25BT21 (SSA) CR17"
    },
    {
      "id": "btech_2_WED_0_hi0l0o",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "24B11MA212",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "RS7",
      "room": "CR12",
      "raw": "T-24B11MA212 25BT21,25BT22 (RS7) CR12"
    },
    {
      "id": "btech_2_WED_5_1z18fz",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23BBWHS231",
      "batches": [
        "25W11"
      ],
      "faculty": "ANU",
      "room": "TR7",
      "raw": "L-23BBWHS231 25W11 (ANU) TR7"
    },
    {
      "id": "btech_2_WED_6_5gli1d",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI272",
      "batches": [
        "25BT21"
      ],
      "faculty": "RIV",
      "room": "CL9_1",
      "raw": "P-25B17CI272 25BT21 (RIV) CL9_1"
    },
    {
      "id": "btech_2_WED_7_q9cpyp",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI272",
      "batches": [
        "25BT21"
      ],
      "faculty": "RIV",
      "room": "CL9_1",
      "raw": "P-25B17CI272 25BT21 (RIV) CL9_1"
    },
    {
      "id": "btech_2_WED_1_i7dkt0",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09"
      ],
      "faculty": "NSA",
      "room": "CR9",
      "raw": "L-25B11CI211   25BT07,25BT08,25BT09   (NSA) CR9"
    },
    {
      "id": "btech_2_WED_2_yht8r4",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "HAZ",
      "room": "CR7",
      "raw": "L-18B11PH211   25BT04,25BT05,25BT06   (HAZ) CR7"
    },
    {
      "id": "btech_2_WED_5_3mh77i",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT08"
      ],
      "faculty": "ADP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT08 (ADP) DRAWR,CAD"
    },
    {
      "id": "btech_2_WED_6_cviovr",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT08"
      ],
      "faculty": "ADP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT08 (ADP) DRAWR,CAD"
    },
    {
      "id": "btech_2_WED_7_90eb6l",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT08"
      ],
      "faculty": "ADP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT08 (ADP) DRAWR,CAD"
    },
    {
      "id": "btech_2_WED_0_fv4nx4",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT01"
      ],
      "faculty": "HR2",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT01 (HR2) LANGULAB"
    },
    {
      "id": "btech_2_WED_1_pfwkpg",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT01"
      ],
      "faculty": "TGM",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT01 (TGM) GDROOM"
    },
    {
      "id": "btech_2_WED_2_4sd1xd",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CE411",
      "batches": [
        "24D11"
      ],
      "faculty": "AKG",
      "room": "CR15",
      "raw": "L-18B11CE411 24D11 (AKG) CR15"
    },
    {
      "id": "btech_2_WED_3_bl0f40",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT05",
        "25BT06"
      ],
      "faculty": "NJL",
      "room": "CR11",
      "raw": "T-23B11HS211 25BT05,25BT06 (NJL) CR11"
    },
    {
      "id": "btech_2_WED_4_867tiu",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WPH532",
      "batches": [
        "AMS_BACK"
      ],
      "faculty": "VSA",
      "room": "TR7",
      "raw": "L-18B1WPH532 AMS_BACK (VSA) TR7"
    },
    {
      "id": "btech_2_WED_5_y1ussd",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "NJL",
      "room": "CR4",
      "raw": "L-23B11HS211   25BT01,25BT02,25BT03    (NJL) CR4"
    },
    {
      "id": "btech_2_WED_6_dxbhix",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT03"
      ],
      "faculty": "SKT",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT03 (SKT) PHLAB2"
    },
    {
      "id": "btech_2_WED_7_l4focs",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT03"
      ],
      "faculty": "SKT",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT03 (SKT) PHLAB2"
    },
    {
      "id": "btech_2_WED_0_kk2j9g",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT09"
      ],
      "faculty": "SBA",
      "room": "TR5",
      "raw": "T-18B11PH211 25BT09 (SBA) TR5"
    },
    {
      "id": "btech_2_WED_1_b381ex",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT16"
      ],
      "faculty": "RS3",
      "room": "TR7",
      "raw": "T-25B11MA211 25BT16 (RS3) TR7"
    },
    {
      "id": "btech_2_WED_2_0b32ks",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "AKR",
      "room": "CR5",
      "raw": "L-25B11CI211 25BT13,25BT14,25BT15 (AKR) CR5"
    },
    {
      "id": "btech_2_WED_3_9kcryk",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT09"
      ],
      "faculty": "NSA",
      "room": "CR9",
      "raw": "T-25B11CI211   25BT09 (NSA) CR9"
    },
    {
      "id": "btech_2_WED_5_drlknu",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT16"
      ],
      "faculty": "SKT",
      "room": "CR1",
      "raw": "T-18B11PH211 25BT16 (SKT) CR1"
    },
    {
      "id": "btech_2_WED_0_smfves",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25BC1CI212/25B11CI415",
      "batches": [
        "25Q11",
        "24H11"
      ],
      "faculty": "DBK",
      "room": "CR11",
      "raw": "L-25BC1CI212/25B11CI415 25Q11,24H11 (DBK) CR11"
    },
    {
      "id": "btech_2_WED_2_b6gj2c",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25Q11",
        "25W11"
      ],
      "faculty": "HR1",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25Q11,25W11 (HR1) GDROOM"
    },
    {
      "id": "btech_2_WED_6_gmj8hf",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11MA212",
      "batches": [
        "25BT20"
      ],
      "faculty": "RS7",
      "room": "TR5",
      "raw": "T-24B11MA212 25BT20 (RS7) TR5"
    },
    {
      "id": "btech_2_WED_7_z7i0hr",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18"
      ],
      "faculty": "HST",
      "room": "DLC,LT2",
      "raw": "L-25B11CI211 25BT16,25BT17,25BT18 (HST) DLC,LT2"
    },
    {
      "id": "btech_2_WED_1_9ekhuv",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "RAD",
      "room": "DLC,CR5",
      "raw": "L-25B11MA211   25BT13,25BT14,25BT15 (RAD) DLC,CR5"
    },
    {
      "id": "btech_2_WED_3_o14oss",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "23BBWHS231",
      "batches": [
        "25W11"
      ],
      "faculty": "ANU",
      "room": "TR1",
      "raw": "T-23BBWHS231 25W11 (ANU) TR1"
    },
    {
      "id": "btech_2_WED_4_knxq4o",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT07"
      ],
      "faculty": "HR4",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT07 (HR4) LANGULAB"
    },
    {
      "id": "btech_2_WED_5_c8j8mm",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT18"
      ],
      "faculty": "VDN",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT18 (VDN) GDROOM"
    },
    {
      "id": "btech_2_WED_6_txdmuj",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT19",
        "25BT22"
      ],
      "faculty": "SSA",
      "room": "CL1",
      "raw": "P-25B17CI271 25BT19,25BT22 (SSA) CL1"
    },
    {
      "id": "btech_2_WED_7_9fzs6g",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT19",
        "25BT22"
      ],
      "faculty": "SSA",
      "room": "CL1",
      "raw": "P-25B17CI271 25BT19,25BT22 (SSA) CL1"
    },
    {
      "id": "btech_2_WED_8_7wmdlp",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "18B11MA211",
      "batches": [
        "BACK"
      ],
      "faculty": "MAT_R",
      "room": "CR2",
      "raw": "L-18B11MA211 BACK (MAT_R) CR2"
    },
    {
      "id": "btech_2_WED_0_22avp9",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT02"
      ],
      "faculty": "ADP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT02 (ADP) DRAWR,CAD"
    },
    {
      "id": "btech_2_WED_1_q9usaj",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT02"
      ],
      "faculty": "ADP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT02 (ADP) DRAWR,CAD"
    },
    {
      "id": "btech_2_WED_2_3lbwzd",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT02"
      ],
      "faculty": "ADP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT02 (ADP) DRAWR,CAD"
    },
    {
      "id": "btech_2_WED_6_7n46gm",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25Q11",
        "25W11"
      ],
      "faculty": "HR6",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25Q11,25W11 (HR6) LANGULAB"
    },
    {
      "id": "btech_2_WED_0_uultzv",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT20"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB1",
      "raw": "P-25B17GE171 25BT20 (ABJ) WORKLAB1"
    },
    {
      "id": "btech_2_WED_1_7wdm90",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT20"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB1",
      "raw": "P-25B17GE171 25BT20 (ABJ) WORKLAB1"
    },
    {
      "id": "btech_2_WED_2_5ysbpt",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT20"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB1",
      "raw": "P-25B17GE171 25BT20 (ABJ) WORKLAB1"
    },
    {
      "id": "btech_2_WED_3_2jzh23",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11MA213",
      "batches": [
        "25Q11",
        "24P11"
      ],
      "faculty": "NKT",
      "room": "CR16",
      "raw": "L-25B11MA213 25Q11,24P11 (NKT) CR16"
    },
    {
      "id": "btech_2_WED_5_ufsoby",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25BC1CI212/25B11CI415",
      "batches": [
        "25Q11",
        "24H11"
      ],
      "faculty": "DBK",
      "room": "CR12",
      "raw": "L-25BC1CI212/25B11CI415 25Q11,24H11 (DBK) CR12"
    },
    {
      "id": "btech_2_WED_0_4muw31",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "23BB1HS212",
      "batches": [
        "25W11"
      ],
      "faculty": "ASA",
      "room": "TR4",
      "raw": "L-23BB1HS212 25W11 (ASA) TR4"
    },
    {
      "id": "btech_2_WED_1_abk1gc",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "SUV",
      "room": "WORKLAB2",
      "raw": "P-25B17GE171 25BT21,25BT22 (SUV) WORKLAB2"
    },
    {
      "id": "btech_2_WED_2_qk46cj",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "SUV",
      "room": "WORKLAB2",
      "raw": "P-25B17GE171 25BT21,25BT22 (SUV) WORKLAB2"
    },
    {
      "id": "btech_2_WED_3_n3afds",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "SUV",
      "room": "WORKLAB2",
      "raw": "P-25B17GE171 25BT21,25BT22 (SUV) WORKLAB2"
    },
    {
      "id": "btech_2_WED_4_myeh4e",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "RTK",
      "room": "CR8",
      "raw": "L-23B11HS211 25BT10,25BT11,25BT12 (RTK) CR8"
    },
    {
      "id": "btech_2_WED_6_r5xl0z",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT16"
      ],
      "faculty": "VDN",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT16 (VDN) GDROOM"
    },
    {
      "id": "btech_2_WED_0_6teldp",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "RTK",
      "room": "CR5",
      "raw": "L-23B11HS211 25BT13,25BT14,25BT15 (RTK) CR5"
    },
    {
      "id": "btech_2_WED_1_lh4bdg",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT18"
      ],
      "faculty": "HR6",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT18 (HR6) LANGULAB"
    },
    {
      "id": "btech_2_WED_0_o45w80",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "NKT",
      "room": "CR8",
      "raw": "L-25B11MA211 25BT10,25BT11,25BT12 (NKT) CR8"
    },
    {
      "id": "btech_2_WED_1_w8bmuf",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT11",
        "25BT12"
      ],
      "faculty": "HR1",
      "room": "CR17",
      "raw": "T-23B11HS211 25BT11,25BT12 (HR1) CR17"
    },
    {
      "id": "btech_2_WED_2_gmy3ca",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09"
      ],
      "faculty": "NJL",
      "room": "CR2",
      "raw": "L-23B11HS211   25BT07,25BT08,25BT09   (NJL) CR2"
    },
    {
      "id": "btech_2_WED_4_qjqhv3",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT13"
      ],
      "faculty": "AKR",
      "room": "CL3_2",
      "raw": "P-25B17CI271 25BT13 (AKR) CL3_2"
    },
    {
      "id": "btech_2_WED_5_hz61xb",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT13"
      ],
      "faculty": "AKR",
      "room": "CL3_2",
      "raw": "P-25B17CI271 25BT13 (AKR) CL3_2"
    },
    {
      "id": "btech_2_WED_6_w7l389",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT05"
      ],
      "faculty": "VSA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT05 (VSA) PHLAB1"
    },
    {
      "id": "btech_2_WED_7_li9dyk",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT05"
      ],
      "faculty": "VSA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT05 (VSA) PHLAB1"
    },
    {
      "id": "btech_2_WED_0_izbr8f",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT03"
      ],
      "faculty": "DGA",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT03 (DGA) CL5_1"
    },
    {
      "id": "btech_2_WED_1_2qz0a4",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT03"
      ],
      "faculty": "DGA",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT03 (DGA) CL5_1"
    },
    {
      "id": "btech_2_WED_2_zei5v6",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "SKK",
      "room": "CR6",
      "raw": "L-18B11PH211 25BT10,25BT11,25BT12 (SKK) CR6"
    },
    {
      "id": "btech_2_WED_3_n0w9oi",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT14"
      ],
      "faculty": "RAD",
      "room": "TR6",
      "raw": "T-25B11MA211 25BT14 (RAD) TR6"
    },
    {
      "id": "btech_2_WED_5_q7dqjl",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT11"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT11 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_WED_6_lfoghj",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT11"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT11 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_WED_7_9dgwd3",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT11"
      ],
      "faculty": "RRA",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT11 (RRA) WORKLAB"
    },
    {
      "id": "btech_2_WED_0_kgolhm",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT08"
      ],
      "faculty": "AKS",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT08 (AKS) GDROOM"
    },
    {
      "id": "btech_2_WED_1_dvm41e",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT19"
      ],
      "faculty": "SSA",
      "room": "CR12",
      "raw": "T-25B11CI211 25BT19 (SSA) CR12"
    },
    {
      "id": "btech_2_WED_4_e4sk8i",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "24B11EC211",
      "batches": [
        "BACK_ECE"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "L-24B11EC211 BACK_ECE (RKU) TR4"
    },
    {
      "id": "btech_2_WED_7_8onpgv",
      "semesterId": "btech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT13"
      ],
      "faculty": "HR5",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT13 (HR5) LANGULAB"
    },
    {
      "id": "btech_2_THU_0_j1pfw2",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT19"
      ],
      "faculty": "SBA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT19 (SBA) PHLAB1"
    },
    {
      "id": "btech_2_THU_1_vvq2xh",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT19"
      ],
      "faculty": "SBA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT19 (SBA) PHLAB1"
    },
    {
      "id": "btech_2_THU_2_6xzd2l",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "MDS",
      "room": "CR8",
      "raw": "L-25B11MA211   25BT01,25BT02,25BT03    (MDS) CR8"
    },
    {
      "id": "btech_2_THU_5_1s75ey",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09",
        "BACK"
      ],
      "faculty": "SBA",
      "room": "CR7",
      "raw": "L-18B11PH211   25BT07,25BT08,25BT09,BACK (SBA) CR7"
    },
    {
      "id": "btech_2_THU_6_0nr3d4",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09"
      ],
      "faculty": "NSA",
      "room": "CR9",
      "raw": "L-25B11CI211   25BT07,25BT08,25BT09   (NSA) CR9"
    },
    {
      "id": "btech_2_THU_1_qn4kbo",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "PBB",
      "room": "CR9",
      "raw": "L-18B11PH211   25BT01,25BT02,25BT03    (PBB) CR9"
    },
    {
      "id": "btech_2_THU_3_3xpgv4",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT01"
      ],
      "faculty": "DGA",
      "room": "TR2",
      "raw": "T-25B11CI211   25BT01 (DGA) TR2"
    },
    {
      "id": "btech_2_THU_6_3wb2n0",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT12"
      ],
      "faculty": "FSL",
      "room": "CL3_2",
      "raw": "P-25B17CI271 25BT12 (FSL) CL3_2"
    },
    {
      "id": "btech_2_THU_7_1nw5r8",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT12"
      ],
      "faculty": "FSL",
      "room": "CL3_2",
      "raw": "P-25B17CI271 25BT12 (FSL) CL3_2"
    },
    {
      "id": "btech_2_THU_0_lxufg5",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT14"
      ],
      "faculty": "VDN",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT14 (VDN) GDROOM"
    },
    {
      "id": "btech_2_THU_3_v34db5",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT19",
        "25BT20"
      ],
      "faculty": "RTK",
      "room": "CR11",
      "raw": "T-23B11HS211 25BT19,25BT20 (RTK) CR11"
    },
    {
      "id": "btech_2_THU_5_t32s96",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI212",
      "batches": [
        "25BT20",
        "25BT21"
      ],
      "faculty": "SSA",
      "room": "CR17",
      "raw": "L-25B11CI212 25BT20,25BT21 (SSA) CR17"
    },
    {
      "id": "btech_2_THU_0_l037i2",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT04"
      ],
      "faculty": "PLK",
      "room": "CL8_1",
      "raw": "P-25B17CI271 25BT04 (PLK) CL8_1"
    },
    {
      "id": "btech_2_THU_1_9qvjic",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT04"
      ],
      "faculty": "PLK",
      "room": "CL8_1",
      "raw": "P-25B17CI271 25BT04 (PLK) CL8_1"
    },
    {
      "id": "btech_2_THU_2_hkqcm8",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT05"
      ],
      "faculty": "PKP",
      "room": "TR2",
      "raw": "T-25B11MA211 25BT05 (PKP) TR2"
    },
    {
      "id": "btech_2_THU_3_r6jqd6",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT12"
      ],
      "faculty": "HR5",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT12 (HR5) LANGULAB"
    },
    {
      "id": "btech_2_THU_0_gs3tsq",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT18"
      ],
      "faculty": "RS6",
      "room": "TR7",
      "raw": "T-25B11MA211 25BT18 (RS6) TR7"
    },
    {
      "id": "btech_2_THU_2_7zxhdx",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09"
      ],
      "faculty": "NJL",
      "room": "LT3",
      "raw": "L-23B11HS211   25BT07,25BT08,25BT09   (NJL) LT3"
    },
    {
      "id": "btech_2_THU_3_wzttes",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT07"
      ],
      "faculty": "RKB",
      "room": "TR6",
      "raw": "T-25B11MA211 25BT07 (RKB) TR6"
    },
    {
      "id": "btech_2_THU_4_a54vnd",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "24B11EC211",
      "batches": [
        "BACK_ECE"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "L-24B11EC211 BACK_ECE (RKU) TR4"
    },
    {
      "id": "btech_2_THU_0_pg51kc",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11MA212",
      "batches": [
        "25BT20",
        "25BT21",
        "25BT22"
      ],
      "faculty": "MDS",
      "room": "CR17",
      "raw": "L-24B11MA212 25BT20,25BT21,25BT22 (MDS) CR17"
    },
    {
      "id": "btech_2_THU_1_qtjn7t",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT05"
      ],
      "faculty": "HR2",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT05 (HR2) LANGULAB"
    },
    {
      "id": "btech_2_THU_3_99dgcz",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH212",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "RRS",
      "room": "TR3",
      "raw": "T-18B11PH212 25BT21,25BT22 (RRS) TR3"
    },
    {
      "id": "btech_2_THU_5_7tg0r4",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23BBWHS231",
      "batches": [
        "25W11"
      ],
      "faculty": "ANU",
      "room": "TR5",
      "raw": "L-23BBWHS231 25W11 (ANU) TR5"
    },
    {
      "id": "btech_2_THU_7_yjq8p3",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09"
      ],
      "faculty": "RKB",
      "room": "CR7",
      "raw": "L-25B11MA211   25BT07,25BT08,25BT09   (RKB) CR7"
    },
    {
      "id": "btech_2_THU_0_k24om8",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT15",
        "25BT16"
      ],
      "faculty": "RTK",
      "room": "CR18",
      "raw": "T-23B11HS211 25BT15,25BT16 (RTK) CR18"
    },
    {
      "id": "btech_2_THU_1_viiuop",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT13"
      ],
      "faculty": "NJL",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT13 (NJL) GDROOM"
    },
    {
      "id": "btech_2_THU_2_9lzmbj",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT18"
      ],
      "faculty": "FSL",
      "room": "CL9_1",
      "raw": "P-25B17CI271 25BT18 (FSL) CL9_1"
    },
    {
      "id": "btech_2_THU_3_uo842o",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT18"
      ],
      "faculty": "FSL",
      "room": "CL9_1",
      "raw": "P-25B17CI271 25BT18 (FSL) CL9_1"
    },
    {
      "id": "btech_2_THU_7_sqhxf3",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH212",
      "batches": [
        "25BT20",
        "25BT21",
        "25BT22"
      ],
      "faculty": "RRS",
      "room": "CR12",
      "raw": "L-18B11PH212 25BT20,25BT21,25BT22 (RRS) CR12"
    },
    {
      "id": "btech_2_THU_0_er98g9",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25BC1CI213",
      "batches": [
        "25Q11"
      ],
      "faculty": "SRT",
      "room": "CR11",
      "raw": "L-25BC1CI213 25Q11 (SRT) CR11"
    },
    {
      "id": "btech_2_THU_1_qq5iml",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT16"
      ],
      "faculty": "HST",
      "room": "CR19",
      "raw": "T-25B11CI211 25BT16 (HST) CR19"
    },
    {
      "id": "btech_2_THU_2_f8eh5s",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "RTK",
      "room": "CR6",
      "raw": "L-23B11HS211 25BT13,25BT14,25BT15 (RTK) CR6"
    },
    {
      "id": "btech_2_THU_3_j1kb6b",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT02"
      ],
      "faculty": "TGM",
      "room": "TR1",
      "raw": "T-25B17HS271 25BT02 (TGM) TR1"
    },
    {
      "id": "btech_2_THU_4_76wsfc",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT15"
      ],
      "faculty": "AKR",
      "room": "CL8_1",
      "raw": "P-25B17CI271 25BT15 (AKR) CL8_1"
    },
    {
      "id": "btech_2_THU_5_pprwfm",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT15"
      ],
      "faculty": "AKR",
      "room": "CL8_1",
      "raw": "P-25B17CI271 25BT15 (AKR) CL8_1"
    },
    {
      "id": "btech_2_THU_0_yewvfy",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "NKT",
      "room": "CR6",
      "raw": "L-25B11MA211 25BT10,25BT11,25BT12 (NKT) CR6"
    },
    {
      "id": "btech_2_THU_2_1dz4ws",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "23BB1HS213",
      "batches": [
        "25W11"
      ],
      "faculty": "TGM",
      "room": "TR7",
      "raw": "L-23BB1HS213 25W11 (TGM) TR7"
    },
    {
      "id": "btech_2_THU_4_ly4t8j",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "HAZ",
      "room": "CR8",
      "raw": "L-18B11PH211   25BT04,25BT05,25BT06   (HAZ) CR8"
    },
    {
      "id": "btech_2_THU_6_lz4m7z",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT05"
      ],
      "faculty": "TGM",
      "room": "TR6",
      "raw": "T-25B17HS271 25BT05 (TGM) TR6"
    },
    {
      "id": "btech_2_THU_8_quyez5",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "18B11MA211",
      "batches": [
        "BACK"
      ],
      "faculty": "MAT_R",
      "room": "CR2",
      "raw": "L-18B11MA211 BACK (MAT_R) CR2"
    },
    {
      "id": "btech_2_THU_0_6fh864",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT17"
      ],
      "faculty": "NJP",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT17 (NJP) WORKLAB"
    },
    {
      "id": "btech_2_THU_1_m2tx1f",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT17"
      ],
      "faculty": "NJP",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT17 (NJP) WORKLAB"
    },
    {
      "id": "btech_2_THU_2_rhlttq",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT17"
      ],
      "faculty": "NJP",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT17 (NJP) WORKLAB"
    },
    {
      "id": "btech_2_THU_3_d6d3ld",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT14"
      ],
      "faculty": "HSR",
      "room": "CR12",
      "raw": "L-18B11PH211 25BT14 (HSR) CR12"
    },
    {
      "id": "btech_2_THU_4_ypt860",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT17"
      ],
      "faculty": "RIV",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT17 (RIV) CL5_1"
    },
    {
      "id": "btech_2_THU_5_wvcylp",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT17"
      ],
      "faculty": "RIV",
      "room": "CL5_1",
      "raw": "P-25B17CI271 25BT17 (RIV) CL5_1"
    },
    {
      "id": "btech_2_THU_6_t6a1l2",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "23BB1HS211",
      "batches": [
        "25W11"
      ],
      "faculty": "TNS",
      "room": "DLC,TR5",
      "raw": "L-23BB1HS211 25W11 (TNS) DLC,TR5"
    },
    {
      "id": "btech_2_THU_0_3vui2e",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "23BB1HS212",
      "batches": [
        "25W11"
      ],
      "faculty": "ASA",
      "room": "TR5",
      "raw": "L-23BB1HS212 25W11 (ASA) TR5"
    },
    {
      "id": "btech_2_THU_1_o7jqnt",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT20",
        "25BT21",
        "25BT22",
        "25Q11",
        "25W11"
      ],
      "faculty": "RTK",
      "room": "DLC,LT2",
      "raw": "L-23B11HS211 25BT20,25BT21,25BT22,25Q11,25W11 (RTK) DLC,LT2"
    },
    {
      "id": "btech_2_THU_2_7j4o7w",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT04"
      ],
      "faculty": "PLK",
      "room": "TR5",
      "raw": "T-25B11CI211   25BT04 (PLK) TR5"
    },
    {
      "id": "btech_2_THU_4_lsrf3z",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT09"
      ],
      "faculty": "HR4",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT09 (HR4) LANGULAB"
    },
    {
      "id": "btech_2_THU_0_3bacpl",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "DGA",
      "room": "CR7",
      "raw": "L-25B11CI211   25BT01,25BT02,25BT03    (DGA) CR7"
    },
    {
      "id": "btech_2_THU_2_kt1dwy",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25BC1CI211",
      "batches": [
        "25Q11"
      ],
      "faculty": "SRT",
      "room": "TR3",
      "raw": "L-25BC1CI211 25Q11 (SRT) TR3"
    },
    {
      "id": "btech_2_THU_3_ki4wyz",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT11"
      ],
      "faculty": "AKS",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT11 (AKS) GDROOM"
    },
    {
      "id": "btech_2_THU_5_e8gwdd",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT04"
      ],
      "faculty": "CPG",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT04 (CPG) DRAWR,CAD"
    },
    {
      "id": "btech_2_THU_6_8rsfk2",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT04"
      ],
      "faculty": "CPG",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT04 (CPG) DRAWR,CAD"
    },
    {
      "id": "btech_2_THU_7_ccuo9g",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT04"
      ],
      "faculty": "CPG",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT04 (CPG) DRAWR,CAD"
    },
    {
      "id": "btech_2_THU_0_7k44fh",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT13"
      ],
      "faculty": "HSR",
      "room": "TR3",
      "raw": "L-18B11PH211 25BT13 (HSR) TR3"
    },
    {
      "id": "btech_2_THU_1_g8e9ub",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "FSL",
      "room": "CR2",
      "raw": "L-25B11CI211 25BT10,25BT11,25BT12 (FSL) CR2"
    },
    {
      "id": "btech_2_THU_2_ynij9k",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT19"
      ],
      "faculty": "SKT",
      "room": "TR6",
      "raw": "T-18B11PH211 25BT19 (SKT) TR6"
    },
    {
      "id": "btech_2_THU_5_cc36wg",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT11"
      ],
      "faculty": "VSA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT11 (VSA) PHLAB1"
    },
    {
      "id": "btech_2_THU_6_qkp21w",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT11"
      ],
      "faculty": "VSA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT11 (VSA) PHLAB1"
    },
    {
      "id": "btech_2_THU_0_513oh8",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT08"
      ],
      "faculty": "SKT",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT08 (SKT) PHLAB2"
    },
    {
      "id": "btech_2_THU_1_l660os",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT08"
      ],
      "faculty": "SKT",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT08 (SKT) PHLAB2"
    },
    {
      "id": "btech_2_THU_2_p5gzrd",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT16"
      ],
      "faculty": "SBA",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT16 (SBA) PHLAB2"
    },
    {
      "id": "btech_2_THU_3_wsj6z9",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT16"
      ],
      "faculty": "SBA",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT16 (SBA) PHLAB2"
    },
    {
      "id": "btech_2_THU_6_7ah7jw",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT17"
      ],
      "faculty": "HST",
      "room": "CR6",
      "raw": "T-25B11CI211 25BT17 (HST) CR6"
    },
    {
      "id": "btech_2_THU_0_gvk8tg",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT06"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT06 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_2_THU_1_8bklkx",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT06"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT06 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_2_THU_2_t10r1o",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT06"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT06 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_2_THU_5_q8yzjy",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT13",
        "25BT14"
      ],
      "faculty": "HR2",
      "room": "CR11",
      "raw": "T-23B11HS211 25BT13,25BT14 (HR2) CR11"
    },
    {
      "id": "btech_2_THU_7_7n40l9",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT15"
      ],
      "faculty": "AKR",
      "room": "TR2",
      "raw": "T-25B11CI211 25BT15 (AKR) TR2"
    },
    {
      "id": "btech_2_THU_0_x5ny3f",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT07"
      ],
      "faculty": "NSA",
      "room": "CL8_2",
      "raw": "P-25B17CI271 25BT07 (NSA) CL8_2"
    },
    {
      "id": "btech_2_THU_1_wax7bj",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT07"
      ],
      "faculty": "NSA",
      "room": "CL8_2",
      "raw": "P-25B17CI271 25BT07 (NSA) CL8_2"
    },
    {
      "id": "btech_2_THU_5_bgw9f0",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT18"
      ],
      "faculty": "ASR",
      "room": "WORKLAB",
      "raw": "P-25B17GE172 25BT18 (ASR) WORKLAB"
    },
    {
      "id": "btech_2_THU_6_hc0rif",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT18"
      ],
      "faculty": "ASR",
      "room": "WORKLAB",
      "raw": "P-25B17GE172 25BT18 (ASR) WORKLAB"
    },
    {
      "id": "btech_2_THU_7_1jdfys",
      "semesterId": "btech_2",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT18"
      ],
      "faculty": "ASR",
      "room": "WORKLAB",
      "raw": "P-25B17GE172 25BT18 (ASR) WORKLAB"
    },
    {
      "id": "btech_2_FRI_2_0kv3zm",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "HAZ",
      "room": "DLC,CR7",
      "raw": "L-18B11PH211   25BT04,25BT05,25BT06   (HAZ) DLC,CR7"
    },
    {
      "id": "btech_2_FRI_0_93bcwo",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "PKP",
      "room": "CR4",
      "raw": "L-25B11MA211   25BT04,25BT05,25BT06   (PKP) CR4"
    },
    {
      "id": "btech_2_FRI_1_y6o31p",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT07",
        "25BT08",
        "25BT09"
      ],
      "faculty": "RKB",
      "room": "CR2",
      "raw": "L-25B11MA211   25BT07,25BT08,25BT09   (RKB) CR2"
    },
    {
      "id": "btech_2_FRI_3_8y2low",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT03"
      ],
      "faculty": "TGM",
      "room": "CR4",
      "raw": "T-25B17HS271 25BT03 (TGM) CR4"
    },
    {
      "id": "btech_2_FRI_6_umfua8",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "DGA",
      "room": "CR7",
      "raw": "L-25B11CI211   25BT01,25BT02,25BT03    (DGA) CR7"
    },
    {
      "id": "btech_2_FRI_2_0l5iao",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CE413",
      "batches": [
        "24D11"
      ],
      "faculty": "ADP",
      "room": "CR15",
      "raw": "L-24B11CE413 24D11 (ADP) CR15"
    },
    {
      "id": "btech_2_FRI_5_9gpejj",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18",
        "25BT19"
      ],
      "faculty": "ABC",
      "room": "DLC",
      "raw": "L-23B11HS211 25BT16,25BT17,25BT18,25BT19 (ABC) DLC"
    },
    {
      "id": "btech_2_FRI_6_ekugeo",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT12"
      ],
      "faculty": "SBA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT12 (SBA) PHLAB1"
    },
    {
      "id": "btech_2_FRI_7_crqkws",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT12"
      ],
      "faculty": "SBA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT12 (SBA) PHLAB1"
    },
    {
      "id": "btech_2_FRI_1_xdq7rg",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT19",
        "25BT22"
      ],
      "faculty": "SSA",
      "room": "CR5",
      "raw": "L-25B11CI211 25BT19,25BT22 (SSA) CR5"
    },
    {
      "id": "btech_2_FRI_2_tvrccg",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT16"
      ],
      "faculty": "HR5",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT16 (HR5) LANGULAB"
    },
    {
      "id": "btech_2_FRI_3_wog30c",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH212",
      "batches": [
        "25BT20"
      ],
      "faculty": "RRS",
      "room": "TR6",
      "raw": "T-18B11PH212 25BT20 (RRS) TR6"
    },
    {
      "id": "btech_2_FRI_4_nyl9e2",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11EC211",
      "batches": [
        "BACK_ECE"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "T-24B11EC211 BACK_ECE (RKU) TR4"
    },
    {
      "id": "btech_2_FRI_6_jb6qlp",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18",
        "25BT19"
      ],
      "faculty": "MDS",
      "room": "LT3",
      "raw": "L-25B11MA211 25BT16,25BT17,25BT18,25BT19 (MDS) LT3"
    },
    {
      "id": "btech_2_FRI_7_0cvi2y",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT06"
      ],
      "faculty": "AKS",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT06 (AKS) GDROOM"
    },
    {
      "id": "btech_2_FRI_0_011kfn",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "HSR",
      "room": "CR9",
      "raw": "L-18B11PH211 25BT13,25BT14,25BT15 (HSR) CR9"
    },
    {
      "id": "btech_2_FRI_1_5mrsmp",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT03"
      ],
      "faculty": "DGA",
      "room": "TR3",
      "raw": "T-25B11CI211   25BT03 (DGA) TR3"
    },
    {
      "id": "btech_2_FRI_2_gpxtjn",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "23BB1HS211",
      "batches": [
        "25W11"
      ],
      "faculty": "TNS",
      "room": "CR18",
      "raw": "T-23BB1HS211 25W11 (TNS) CR18"
    },
    {
      "id": "btech_2_FRI_5_4lf1al",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT21",
        "25BT22"
      ],
      "faculty": "HR1",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT21,25BT22 (HR1) GDROOM"
    },
    {
      "id": "btech_2_FRI_6_0mu3g0",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT10"
      ],
      "faculty": "HSR",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT10 (HSR) PHLAB2"
    },
    {
      "id": "btech_2_FRI_7_ye1rur",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT10"
      ],
      "faculty": "HSR",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT10 (HSR) PHLAB2"
    },
    {
      "id": "btech_2_FRI_2_f43d8l",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT13",
        "25BT14",
        "25BT15"
      ],
      "faculty": "AKR",
      "room": "CR4",
      "raw": "L-25B11CI211 25BT13,25BT14,25BT15 (AKR) CR4"
    },
    {
      "id": "btech_2_FRI_4_jqiy0f",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WPH532",
      "batches": [
        "AMS_BACK"
      ],
      "faculty": "VSA",
      "room": "TR7",
      "raw": "L-18B1WPH532 AMS_BACK (VSA) TR7"
    },
    {
      "id": "btech_2_FRI_5_fbawd3",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23BBWHS231",
      "batches": [
        "25W11"
      ],
      "faculty": "ANU",
      "room": "TR7",
      "raw": "L-23BBWHS231 25W11 (ANU) TR7"
    },
    {
      "id": "btech_2_FRI_7_8lnw0m",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT01"
      ],
      "faculty": "PBB",
      "room": "TR6",
      "raw": "T-18B11PH211 25BT01 (PBB) TR6"
    },
    {
      "id": "btech_2_FRI_0_z3ydaf",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT10"
      ],
      "faculty": "AKS",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT10 (AKS) GDROOM"
    },
    {
      "id": "btech_2_FRI_1_adri1v",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT10"
      ],
      "faculty": "NKT",
      "room": "CR12",
      "raw": "T-25B11MA211 25BT10 (NKT) CR12"
    },
    {
      "id": "btech_2_FRI_2_eibr9n",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT17"
      ],
      "faculty": "SKT",
      "room": "TR5",
      "raw": "T-18B11PH211 25BT17 (SKT) TR5"
    },
    {
      "id": "btech_2_FRI_3_jznyoj",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "23BB1HS212",
      "batches": [
        "25W11"
      ],
      "faculty": "ASA",
      "room": "TR1",
      "raw": "T-23BB1HS212 25W11 (ASA) TR1"
    },
    {
      "id": "btech_2_FRI_4_xunn5y",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT17"
      ],
      "faculty": "HR5",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT17 (HR5) LANGULAB"
    },
    {
      "id": "btech_2_FRI_5_ilfxqm",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT09"
      ],
      "faculty": "CPG",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT09 (CPG) DRAWR,CAD"
    },
    {
      "id": "btech_2_FRI_6_73e8dg",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT09"
      ],
      "faculty": "CPG",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT09 (CPG) DRAWR,CAD"
    },
    {
      "id": "btech_2_FRI_7_g1l5tv",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT09"
      ],
      "faculty": "CPG",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT09 (CPG) DRAWR,CAD"
    },
    {
      "id": "btech_2_FRI_8_pqh08s",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "18B11MA211",
      "batches": [
        "BACK"
      ],
      "faculty": "MAT_R",
      "room": "CR2",
      "raw": "L-18B11MA211 BACK (MAT_R) CR2"
    },
    {
      "id": "btech_2_FRI_0_26x1wx",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT03"
      ],
      "faculty": "HR2",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT03 (HR2) LANGULAB"
    },
    {
      "id": "btech_2_FRI_2_j3buc5",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT18"
      ],
      "faculty": "HST",
      "room": "TR4",
      "raw": "T-25B11CI211 25BT18 (HST) TR4"
    },
    {
      "id": "btech_2_FRI_3_3x60go",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "RTK",
      "room": "DLC,CR8",
      "raw": "L-23B11HS211 25BT10,25BT11,25BT12 (RTK) DLC,CR8"
    },
    {
      "id": "btech_2_FRI_4_o2dknf",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT01"
      ],
      "faculty": "HAZ",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT01 (HAZ) PHLAB2"
    },
    {
      "id": "btech_2_FRI_5_bcsu4p",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT01"
      ],
      "faculty": "HAZ",
      "room": "PHLAB2",
      "raw": "P-18B17PH271 25BT01 (HAZ) PHLAB2"
    },
    {
      "id": "btech_2_FRI_6_41v0l9",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT06"
      ],
      "faculty": "HR4",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT06 (HR4) LANGULAB"
    },
    {
      "id": "btech_2_FRI_0_neggtr",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT07"
      ],
      "faculty": "SBA",
      "room": "TR4",
      "raw": "T-18B11PH211 25BT07 (SBA) TR4"
    },
    {
      "id": "btech_2_FRI_1_ymq38d",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT171",
      "batches": [
        "25BT20"
      ],
      "faculty": "HSD",
      "room": "UG2",
      "raw": "P-25B17BT171 25BT20 (HSD) UG2"
    },
    {
      "id": "btech_2_FRI_2_86oxfy",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT171",
      "batches": [
        "25BT20"
      ],
      "faculty": "HSD",
      "room": "UG2",
      "raw": "P-25B17BT171 25BT20 (HSD) UG2"
    },
    {
      "id": "btech_2_FRI_3_1nsq5x",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT15"
      ],
      "faculty": "AKS",
      "room": "GDROOM",
      "raw": "T-25B17HS271 25BT15 (AKS) GDROOM"
    },
    {
      "id": "btech_2_FRI_5_x8sajr",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "PLK",
      "room": "CR6",
      "raw": "L-25B11CI211   25BT04,25BT05,25BT06   (PLK) CR6"
    },
    {
      "id": "btech_2_FRI_7_q7l5ji",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT11"
      ],
      "faculty": "HR4",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT11 (HR4) LANGULAB"
    },
    {
      "id": "btech_2_FRI_0_jthypn",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11MA212",
      "batches": [
        "25BT20",
        "25BT21",
        "25BT22"
      ],
      "faculty": "MDS",
      "room": "CR17",
      "raw": "L-24B11MA212 25BT20,25BT21,25BT22 (MDS) CR17"
    },
    {
      "id": "btech_2_FRI_1_qcq2ac",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "23B11HS211",
      "batches": [
        "25Q11",
        "25W11"
      ],
      "faculty": "RTK",
      "room": "TR2",
      "raw": "T-23B11HS211 25Q11,25W11 (RTK) TR2"
    },
    {
      "id": "btech_2_FRI_2_5khp2r",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT03"
      ],
      "faculty": "PBB",
      "room": "TR6",
      "raw": "T-18B11PH211 25BT03 (PBB) TR6"
    },
    {
      "id": "btech_2_FRI_5_qhhcr9",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT08"
      ],
      "faculty": "HR4",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT08 (HR4) LANGULAB"
    },
    {
      "id": "btech_2_FRI_6_1a85oo",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT11"
      ],
      "faculty": "SKK",
      "room": "TR7",
      "raw": "T-18B11PH211 25BT11 (SKK) TR7"
    },
    {
      "id": "btech_2_FRI_0_gepq0k",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT01"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT01 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_FRI_1_p9zepk",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT01"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT01 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_FRI_2_y13dzx",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE172",
      "batches": [
        "25BT01"
      ],
      "faculty": "NJP",
      "room": "DRAWR,CAD",
      "raw": "P-25B17GE172 25BT01 (NJP) DRAWR,CAD"
    },
    {
      "id": "btech_2_FRI_3_jkil62",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT02"
      ],
      "faculty": "HR2",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT02 (HR2) LANGULAB"
    },
    {
      "id": "btech_2_FRI_5_6lj3vd",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25BC1CI211",
      "batches": [
        "25Q11"
      ],
      "faculty": "SRT",
      "room": "TR6",
      "raw": "T-25BC1CI211 25Q11 (SRT) TR6"
    },
    {
      "id": "btech_2_FRI_6_3g7kb4",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI212",
      "batches": [
        "25BT20",
        "25BT21"
      ],
      "faculty": "SSA",
      "room": "CR16",
      "raw": "L-25B11CI212 25BT20,25BT21 (SSA) CR16"
    },
    {
      "id": "btech_2_FRI_7_38rmwp",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT07"
      ],
      "faculty": "NSA",
      "room": "TR1",
      "raw": "T-25B11CI211   25BT07 (NSA) TR1"
    },
    {
      "id": "btech_2_FRI_3_gzmzjj",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25BC1CI211",
      "batches": [
        "25Q11"
      ],
      "faculty": "SRT",
      "room": "TR7",
      "raw": "L-25BC1CI211 25Q11 (SRT) TR7"
    },
    {
      "id": "btech_2_FRI_4_mj7giz",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT04",
        "25BT05",
        "25BT06"
      ],
      "faculty": "ABC",
      "room": "CR4",
      "raw": "L-23B11HS211   25BT04,25BT05,25BT06   (ABC) CR4"
    },
    {
      "id": "btech_2_FRI_5_fwcqk3",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT10",
        "25BT11",
        "25BT12"
      ],
      "faculty": "FSL",
      "room": "CR9",
      "raw": "L-25B11CI211 25BT10,25BT11,25BT12 (FSL) CR9"
    },
    {
      "id": "btech_2_FRI_6_5yc4hy",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT05"
      ],
      "faculty": "PLK",
      "room": "TR2",
      "raw": "T-25B11CI211   25BT05 (PLK) TR2"
    },
    {
      "id": "btech_2_FRI_0_ppr0zc",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18"
      ],
      "faculty": "HST",
      "room": "LT2",
      "raw": "L-25B11CI211 25BT16,25BT17,25BT18 (HST) LT2"
    },
    {
      "id": "btech_2_FRI_2_wfurs5",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT09"
      ],
      "faculty": "NSA",
      "room": "CL11",
      "raw": "P-25B17CI271 25BT09 (NSA) CL11"
    },
    {
      "id": "btech_2_FRI_3_eqni44",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI271",
      "batches": [
        "25BT09"
      ],
      "faculty": "NSA",
      "room": "CL11",
      "raw": "P-25B17CI271 25BT09 (NSA) CL11"
    },
    {
      "id": "btech_2_FRI_5_kmfp9g",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT14"
      ],
      "faculty": "ASR",
      "room": "WORKLAB1",
      "raw": "P-25B17GE171 25BT14 (ASR) WORKLAB1"
    },
    {
      "id": "btech_2_FRI_6_wztf2u",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT14"
      ],
      "faculty": "ASR",
      "room": "WORKLAB1",
      "raw": "P-25B17GE171 25BT14 (ASR) WORKLAB1"
    },
    {
      "id": "btech_2_FRI_7_wwlpok",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT14"
      ],
      "faculty": "ASR",
      "room": "WORKLAB1",
      "raw": "P-25B17GE171 25BT14 (ASR) WORKLAB1"
    },
    {
      "id": "btech_2_FRI_2_uzfr1h",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT07"
      ],
      "faculty": "SBA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT07 (SBA) PHLAB1"
    },
    {
      "id": "btech_2_FRI_3_mkkqvr",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17PH271",
      "batches": [
        "25BT07"
      ],
      "faculty": "SBA",
      "room": "PHLAB1",
      "raw": "P-18B17PH271 25BT07 (SBA) PHLAB1"
    },
    {
      "id": "btech_2_FRI_5_nbm094",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT13"
      ],
      "faculty": "RRA",
      "room": "WORKLAB2",
      "raw": "P-25B17GE171 25BT13 (RRA) WORKLAB2"
    },
    {
      "id": "btech_2_FRI_6_m2tk4q",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT13"
      ],
      "faculty": "RRA",
      "room": "WORKLAB2",
      "raw": "P-25B17GE171 25BT13 (RRA) WORKLAB2"
    },
    {
      "id": "btech_2_FRI_7_nmagtg",
      "semesterId": "btech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT13"
      ],
      "faculty": "RRA",
      "room": "WORKLAB2",
      "raw": "P-25B17GE171 25BT13 (RRA) WORKLAB2"
    },
    {
      "id": "btech_2_SAT_0_z4bqnj",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT10"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT10 (ABJ) WORKLAB"
    },
    {
      "id": "btech_2_SAT_1_e6903c",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT10"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT10 (ABJ) WORKLAB"
    },
    {
      "id": "btech_2_SAT_2_rst5zc",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17GE171",
      "batches": [
        "25BT10"
      ],
      "faculty": "ABJ",
      "room": "WORKLAB",
      "raw": "P-25B17GE171 25BT10 (ABJ) WORKLAB"
    },
    {
      "id": "btech_2_SAT_2_eb52ck",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "PBB",
      "room": "DLC,CR4",
      "raw": "L-18B11PH211   25BT01,25BT02,25BT03    (PBB) DLC,CR4"
    },
    {
      "id": "btech_2_SAT_3_lxszt4",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18",
        "25BT19"
      ],
      "faculty": "ABC",
      "room": "LT3",
      "raw": "L-23B11HS211 25BT16,25BT17,25BT18,25BT19 (ABC) LT3"
    },
    {
      "id": "btech_2_SAT_0_2r6iul",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI211",
      "batches": [
        "25BT19",
        "25BT22"
      ],
      "faculty": "SSA",
      "room": "CR8",
      "raw": "L-25B11CI211 25BT19,25BT22 (SSA) CR8"
    },
    {
      "id": "btech_2_SAT_0_3k4lt0",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "23B11HS211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "NJL",
      "room": "CR6",
      "raw": "L-23B11HS211   25BT01,25BT02,25BT03 (NJL) CR6"
    },
    {
      "id": "btech_2_SAT_0_xkq77k",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT17"
      ],
      "faculty": "RS4",
      "room": "TR5",
      "raw": "T-25B11MA211 25BT17 (RS4) TR5"
    },
    {
      "id": "btech_2_SAT_1_aryifp",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA211",
      "batches": [
        "25BT01",
        "25BT02",
        "25BT03"
      ],
      "faculty": "MDS",
      "room": "CR9",
      "raw": "L-25B11MA211   25BT01,25BT02,25BT03    (MDS) CR9"
    },
    {
      "id": "btech_2_SAT_2_fwxj8g",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B17HS271",
      "batches": [
        "25BT19"
      ],
      "faculty": "HR6",
      "room": "LANGULAB",
      "raw": "T-25B17HS271 25BT19 (HR6) LANGULAB"
    },
    {
      "id": "btech_2_SAT_0_0j2din",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11MA213",
      "batches": [
        "25Q11",
        "24P11"
      ],
      "faculty": "NKT",
      "room": "CR16",
      "raw": "L-25B11MA213 25Q11,24P11 (NKT) CR16"
    },
    {
      "id": "btech_2_SAT_1_n7v66e",
      "semesterId": "btech_2",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11PH211",
      "batches": [
        "25BT16",
        "25BT17",
        "25BT18",
        "25BT19"
      ],
      "faculty": "SKT",
      "room": "LT3",
      "raw": "L-18B11PH211 25BT16,25BT17,25BT18,25BT19 (SKT) LT3"
    },
    {
      "id": "btech_4_MON_0_bt8os1",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A17"
      ],
      "faculty": "SMA",
      "room": "CL6",
      "raw": "P-25B17CI476 24A17 (SMA) CL6"
    },
    {
      "id": "btech_4_MON_1_svb3fl",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A17"
      ],
      "faculty": "SMA",
      "room": "CL6",
      "raw": "P-25B17CI476 24A17 (SMA) CL6"
    },
    {
      "id": "btech_4_MON_2_cm7fa5",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24J11"
      ],
      "faculty": "MGN",
      "room": "CL3_2",
      "raw": "P-25B17CI473 24J11 (MGN) CL3_2"
    },
    {
      "id": "btech_4_MON_3_k8ehqx",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24J11"
      ],
      "faculty": "MGN",
      "room": "CL3_2",
      "raw": "P-25B17CI473 24J11 (MGN) CL3_2"
    },
    {
      "id": "btech_4_MON_6_n9euyk",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "RVS",
      "room": "DLC,CR8",
      "raw": "L-25B11CI412 24A17,24A18,24A19 (RVS) DLC,CR8"
    },
    {
      "id": "btech_4_MON_7_vh8dvc",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "24BB1HS413",
      "batches": [
        "24W11"
      ],
      "faculty": "TGM",
      "room": "TR3",
      "raw": "L-24BB1HS413 24W11 (TGM) TR3"
    },
    {
      "id": "btech_4_MON_0_9hyfw4",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B21[24A14"
      ],
      "faculty": "SSA",
      "room": "CL3_1",
      "raw": "P-25B1WCI471 B21[24A14] (SSA) CL3_1"
    },
    {
      "id": "btech_4_MON_1_q2dvoz",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B21[24A14"
      ],
      "faculty": "SSA",
      "room": "CL3_1",
      "raw": "P-25B1WCI471 B21[24A14] (SSA) CL3_1"
    },
    {
      "id": "btech_4_MON_2_hs79pd",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "RKI",
      "room": "CL4",
      "raw": "P-24B17CI471 24J12,24K11 (RKI) CL4"
    },
    {
      "id": "btech_4_MON_3_uu6ded",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "RKI",
      "room": "CL4",
      "raw": "P-24B17CI471 24J12,24K11 (RKI) CL4"
    },
    {
      "id": "btech_4_MON_6_165pyk",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "24BB1HS411",
      "batches": [
        "24W11"
      ],
      "faculty": "ANU",
      "room": "TR1",
      "raw": "L-24BB1HS411 24W11 (ANU) TR1"
    },
    {
      "id": "btech_4_MON_0_0rp7gh",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A15"
      ],
      "faculty": "PKG",
      "room": "CL5_2",
      "raw": "P-25B17CI476 24A15 (PKG) CL5_2"
    },
    {
      "id": "btech_4_MON_1_h8tmyv",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A15"
      ],
      "faculty": "PKG",
      "room": "CL5_2",
      "raw": "P-25B17CI476 24A15 (PKG) CL5_2"
    },
    {
      "id": "btech_4_MON_2_bptrfi",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "SWT",
      "room": "CR5",
      "raw": "L-25B11CI411 24I11,24I12,24I13 (SWT) CR5"
    },
    {
      "id": "btech_4_MON_3_43iio0",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT411",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "SML",
      "room": "TR7",
      "raw": "L-25B11BT411 24E11, 24F11  (SML) TR7"
    },
    {
      "id": "btech_4_MON_6_ne4ucp",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT415",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "JTV",
      "room": "TR3",
      "raw": "L-25B11BT415 24E11,24F11 (JTV) TR3"
    },
    {
      "id": "btech_4_MON_0_ys36vf",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CE412",
      "batches": [
        "24D11"
      ],
      "faculty": "ABJ",
      "room": "CR15",
      "raw": "L-24B11CE412 24D11 (ABJ) CR15"
    },
    {
      "id": "btech_4_MON_1_gk9j7e",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "VNS",
      "room": "LT3",
      "raw": "L-25B11CI413 24J11,24J12,24K11 (VNS) LT3"
    },
    {
      "id": "btech_4_MON_2_uq1u7r",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "B2[24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "AYS",
      "room": "CR8",
      "raw": "L-25B1WCI431 B2[24A14,24A15,24A16]  (AYS) CR8"
    },
    {
      "id": "btech_4_MON_3_ie3z9e",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WEC431",
      "batches": [
        "24B11",
        "24H11"
      ],
      "faculty": "VKB",
      "room": "TR4",
      "raw": "L-25B1WEC431 24B11,24H11 (VKB) TR4"
    },
    {
      "id": "btech_4_MON_6_sic5qo",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25BS7MA471",
      "batches": [
        "24P11"
      ],
      "faculty": "SST",
      "room": "CL1",
      "raw": "P-25BS7MA471 24P11 (SST) CL1"
    },
    {
      "id": "btech_4_MON_7_tyhxle",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25BS7MA471",
      "batches": [
        "24P11"
      ],
      "faculty": "SST",
      "room": "CL1",
      "raw": "P-25BS7MA471 24P11 (SST) CL1"
    },
    {
      "id": "btech_4_MON_0_frpgx6",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24BB7HS471",
      "batches": [
        "24W11"
      ],
      "faculty": "NTJ",
      "room": "CL7",
      "raw": "P-24BB7HS471 24W11 (NTJ) CL7"
    },
    {
      "id": "btech_4_MON_1_cugfl1",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24BB7HS471",
      "batches": [
        "24W11"
      ],
      "faculty": "NTJ",
      "room": "CL7",
      "raw": "P-24BB7HS471 24W11 (NTJ) CL7"
    },
    {
      "id": "btech_4_MON_3_iv46th",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "PNS",
      "room": "CR2",
      "raw": "L-25B11GE411 24I11,24I12,24I13 (PNS) CR2"
    },
    {
      "id": "btech_4_MON_6_jaz1j0",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A16"
      ],
      "faculty": "PKG",
      "room": "CL4",
      "raw": "P-25B17CI476 24A16 (PKG) CL4"
    },
    {
      "id": "btech_4_MON_7_5atxrz",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A16"
      ],
      "faculty": "PKG",
      "room": "CL4",
      "raw": "P-25B17CI476 24A16 (PKG) CL4"
    },
    {
      "id": "btech_4_MON_0_0n11sl",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24I12"
      ],
      "faculty": "MSD",
      "room": "ECL5",
      "raw": "P-25B17CI471 24I12 (MSD) ECL5"
    },
    {
      "id": "btech_4_MON_1_ttf88s",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24I12"
      ],
      "faculty": "MSD",
      "room": "ECL5",
      "raw": "P-25B17CI471 24I12 (MSD) ECL5"
    },
    {
      "id": "btech_4_MON_2_5twc0c",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WBT432",
      "batches": [
        "24E11"
      ],
      "faculty": "UDB",
      "room": "CR16",
      "raw": "L-25B1WBT432 24E11 (UDB) CR16"
    },
    {
      "id": "btech_4_MON_3_55d1x4",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "ARV",
      "room": "CR7",
      "raw": "L-25B11CI412 24A14,24A15,24A16 (ARV) CR7"
    },
    {
      "id": "btech_4_MON_5_k3z6cy",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "24BBWHS431",
      "batches": [
        "24W11"
      ],
      "faculty": "ASA",
      "room": "TR3",
      "raw": "T-24BBWHS431 24W11 (ASA) TR3"
    },
    {
      "id": "btech_4_MON_6_1qit4e",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24C11",
        "24I14"
      ],
      "faculty": "MNK",
      "room": "CR6",
      "raw": "L-25B11CI414 24A110,24L11,24N11,24C11,24I14 (MNK) CR6"
    },
    {
      "id": "btech_4_MON_7_54ut51",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A110",
        "24F11",
        "24C11",
        "24D11",
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "PNS",
      "room": "CR2",
      "raw": "L-25B11GE411 24A110,24F11,24C11,24D11,24L11,24N11,24I14 (PNS) CR2"
    },
    {
      "id": "btech_4_MON_0_l2s8vu",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "AMN",
      "room": "CL8_1",
      "raw": "P-25B17CI473 24C11, 24P11,24F11 (AMN) CL8_1"
    },
    {
      "id": "btech_4_MON_1_dmdyz7",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "AMN",
      "room": "CL8_1",
      "raw": "P-25B17CI473 24C11, 24P11,24F11 (AMN) CL8_1"
    },
    {
      "id": "btech_4_MON_2_bm2n8o",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "B3[24A17",
        "24A18",
        "24A19",
        "24E11",
        "24F11"
      ],
      "faculty": "ATA",
      "room": "CR7",
      "raw": "L-25B1WCI431  B3[24A17,24A18,24A19,24E11,24F11] (ATA) CR7"
    },
    {
      "id": "btech_4_MON_3_vcau1y",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "24BB1HS414",
      "batches": [
        "24W11"
      ],
      "faculty": "DLR",
      "room": "TR6",
      "raw": "L-24BB1HS414 24W11 (DLR) TR6"
    },
    {
      "id": "btech_4_MON_6_5stmyz",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BT411",
      "batches": [
        "OTO"
      ],
      "faculty": "HSD",
      "room": "CABIN",
      "raw": "L-18B11BT411 OTO (HSD) CABIN"
    },
    {
      "id": "btech_4_MON_7_imqaik",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "MSD",
      "room": "CR5",
      "raw": "L-25B11CI411 24J11,24J12,24K11 (MSD) CR5"
    },
    {
      "id": "btech_4_MON_0_e1blls",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "SKS",
      "room": "CR16",
      "raw": "T-25B11CI412 24L11,24N11,24I14 (SKS) CR16"
    },
    {
      "id": "btech_4_MON_1_wfek89",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CE414",
      "batches": [
        "24D11"
      ],
      "faculty": "KKR",
      "room": "CR14",
      "raw": "L-24B11CE414 24D11 (KKR) CR14"
    },
    {
      "id": "btech_4_MON_2_hgjcy2",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A11"
      ],
      "faculty": "AKJ",
      "room": "CL9_1",
      "raw": "P-25B17CI472 24A11 (AKJ) CL9_1"
    },
    {
      "id": "btech_4_MON_3_n01l7x",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A11"
      ],
      "faculty": "AKJ",
      "room": "CL9_1",
      "raw": "P-25B17CI472 24A11 (AKJ) CL9_1"
    },
    {
      "id": "btech_4_MON_5_s5joy5",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS431",
      "batches": [],
      "faculty": "TGM",
      "room": "CR6",
      "raw": "L-25B1WHS431  (TGM) CR6"
    },
    {
      "id": "btech_4_MON_6_h1h9jz",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "RKI",
      "room": "LT2",
      "raw": "L-25B11CI414 24I11,24I12,24I13 (RKI) LT2"
    },
    {
      "id": "btech_4_MON_7_86sd7i",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "AVA",
      "room": "CR7",
      "raw": "L-25B11CI412 24I11,24I12,24I13 (AVA) CR7"
    },
    {
      "id": "btech_4_MON_0_2gplc3",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A12"
      ],
      "faculty": "HSL",
      "room": "ECL3",
      "raw": "P-25B17CI471 24A12 (HSL) ECL3"
    },
    {
      "id": "btech_4_MON_1_163gk7",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A12"
      ],
      "faculty": "HSL",
      "room": "ECL3",
      "raw": "P-25B17CI471 24A12 (HSL) ECL3"
    },
    {
      "id": "btech_4_MON_5_6holmi",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS432",
      "batches": [],
      "faculty": "DLR",
      "room": "CR9",
      "raw": "L-25B1WHS432  (DLR) CR9"
    },
    {
      "id": "btech_4_MON_6_hdyv2h",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC471",
      "batches": [
        "24B11"
      ],
      "faculty": "ALK",
      "room": "ECL5",
      "raw": "P-25B17EC471 24B11 (ALK) ECL5"
    },
    {
      "id": "btech_4_MON_7_qzgme9",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC471",
      "batches": [
        "24B11"
      ],
      "faculty": "ALK",
      "room": "ECL5",
      "raw": "P-25B17EC471 24B11 (ALK) ECL5"
    },
    {
      "id": "btech_4_MON_8_6z55am",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI433/25B1WCI835",
      "batches": [
        "B6[From",
        "all",
        "batches",
        "24E11",
        "24F11",
        "CS-IT[MCSE]BI81"
      ],
      "faculty": "AYS",
      "room": "LT2",
      "raw": "L-25B1WCI433/25B1WCI835 B6[From all batches],24E11,24F11,CS-IT[MCSE]BI81 (AYS) LT2"
    },
    {
      "id": "btech_4_MON_0_f3zdxm",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A11"
      ],
      "faculty": "ALK",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A11 (ALK) ECL4"
    },
    {
      "id": "btech_4_MON_1_gqa0sv",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A11"
      ],
      "faculty": "ALK",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A11 (ALK) ECL4"
    },
    {
      "id": "btech_4_MON_2_uwoa6k",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24BB1HS412",
      "batches": [
        "24W11"
      ],
      "faculty": "TNS",
      "room": "TR7",
      "raw": "L-24BB1HS412 24W11 (TNS) TR7"
    },
    {
      "id": "btech_4_MON_3_mopdih",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A18"
      ],
      "faculty": "RVS",
      "room": "CR18",
      "raw": "T-25B11CI412 24A18 (RVS) CR18"
    },
    {
      "id": "btech_4_MON_5_7p2toc",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS433",
      "batches": [],
      "faculty": "NJL",
      "room": "CR2",
      "raw": "L-25B1WHS433  (NJL) CR2"
    },
    {
      "id": "btech_4_MON_6_qpfl6q",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC476",
      "batches": [
        "24G11"
      ],
      "faculty": "SHR",
      "room": "ECL8",
      "raw": "P-25B17EC476 24G11 (SHR) ECL8"
    },
    {
      "id": "btech_4_MON_7_lk5ixt",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC476",
      "batches": [
        "24G11"
      ],
      "faculty": "SHR",
      "room": "ECL8",
      "raw": "P-25B17EC476 24G11 (SHR) ECL8"
    },
    {
      "id": "btech_4_MON_0_j4t76t",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24J11",
        "24J12",
        "24K11",
        "25W11"
      ],
      "faculty": "RRA",
      "room": "CR2",
      "raw": "L-25B11GE411 24J11,24J12,24K11,25W11 (RRA) CR2"
    },
    {
      "id": "btech_4_MON_1_b7qq1a",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "PDG",
      "room": "CR8",
      "raw": "L-25B11CI411 24A110,24L11,24N11,24I14 (PDG) CR8"
    },
    {
      "id": "btech_4_MON_2_n4u11z",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A12"
      ],
      "faculty": "RBT",
      "room": "CL6",
      "raw": "P-25B17CI473 24A12 (RBT) CL6"
    },
    {
      "id": "btech_4_MON_3_enb431",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A12"
      ],
      "faculty": "RBT",
      "room": "CL6",
      "raw": "P-25B17CI473 24A12 (RBT) CL6"
    },
    {
      "id": "btech_4_MON_5_mmvwts",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS434",
      "batches": [],
      "faculty": "RTK",
      "room": "LT3",
      "raw": "L-25B1WHS434  (RTK) LT3"
    },
    {
      "id": "btech_4_MON_6_f21p94",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "AKJ",
      "room": "CR7",
      "raw": "L-25B11CI412 24A11,24A12,24A13 (AKJ) CR7"
    },
    {
      "id": "btech_4_MON_7_s86z02",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "AMN",
      "room": "CR6",
      "raw": "L-25B11CI413 24A17,24A18,24A19 (AMN) CR6"
    },
    {
      "id": "btech_4_MON_0_sq5oy1",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11BT413",
      "batches": [
        "24E11"
      ],
      "faculty": "ABH",
      "room": "TR1",
      "raw": "L-25B11BT413 24E11 (ABH) TR1"
    },
    {
      "id": "btech_4_MON_1_l4b29z",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11BT414",
      "batches": [
        "24E11"
      ],
      "faculty": "RJK",
      "room": "CR19",
      "raw": "L-25B11BT414 24E11 (RJK) CR19"
    },
    {
      "id": "btech_4_MON_2_w74roo",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A13",
        "24G11"
      ],
      "faculty": "PKG",
      "room": "CL11",
      "raw": "P-25B17CI476 24A13,24G11 (PKG) CL11"
    },
    {
      "id": "btech_4_MON_3_3v5uas",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A13",
        "24G11"
      ],
      "faculty": "PKG",
      "room": "CL11",
      "raw": "P-25B17CI476 24A13,24G11 (PKG) CL11"
    },
    {
      "id": "btech_4_MON_6_23imz3",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CE411",
      "batches": [
        "24D11"
      ],
      "faculty": "CPG",
      "room": "CR13",
      "raw": "L-25B11CE411 24D11 (CPG) CR13"
    },
    {
      "id": "btech_4_MON_7_nhnius",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "RBT",
      "room": "LT2",
      "raw": "L-25B11CI413 24A11,24A12,24A13 (RBT) LT2"
    },
    {
      "id": "btech_4_MON_0_h5h0jf",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B13[24A13"
      ],
      "faculty": "ATA",
      "room": "CL9_2",
      "raw": "P-25B1WCI471 B13[24A13] (ATA) CL9_2"
    },
    {
      "id": "btech_4_MON_1_9yz3uc",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B13[24A13"
      ],
      "faculty": "ATA",
      "room": "CL9_2",
      "raw": "P-25B1WCI471 B13[24A13] (ATA) CL9_2"
    },
    {
      "id": "btech_4_MON_2_rsd1uq",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17MA471",
      "batches": [
        "24P11"
      ],
      "faculty": "SST",
      "room": "CL1",
      "raw": "P-25B17MA471 24P11 (SST) CL1"
    },
    {
      "id": "btech_4_MON_3_1lloaz",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17MA471",
      "batches": [
        "24P11"
      ],
      "faculty": "SST",
      "room": "CL1",
      "raw": "P-25B17MA471 24P11 (SST) CL1"
    },
    {
      "id": "btech_4_MON_6_3bw4mb",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17C472",
      "batches": [
        "24A15"
      ],
      "faculty": "ARV",
      "room": "CL9_1",
      "raw": "P-25B17C472 24A15 (ARV) CL9_1"
    },
    {
      "id": "btech_4_MON_7_38zom9",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17C472",
      "batches": [
        "24A15"
      ],
      "faculty": "ARV",
      "room": "CL9_1",
      "raw": "P-25B17C472 24A15 (ARV) CL9_1"
    },
    {
      "id": "btech_4_MON_0_ov6tgm",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B51[24I11",
        "24I13"
      ],
      "faculty": "HST",
      "room": "CL4",
      "raw": "P-25B1WCI471 B51[24I11,24I13] (HST) CL4"
    },
    {
      "id": "btech_4_MON_1_uojbfi",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B51[24I11",
        "24I13"
      ],
      "faculty": "HST",
      "room": "CL4",
      "raw": "P-25B1WCI471 B51[24I11,24I13] (HST) CL4"
    },
    {
      "id": "btech_4_MON_2_jypz5m",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "PDG",
      "room": "ECL4",
      "raw": "P-25B17CI471 24L11,24N11,24I14 (PDG) ECL4"
    },
    {
      "id": "btech_4_MON_3_xkp0xf",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "PDG",
      "room": "ECL4",
      "raw": "P-25B17CI471 24L11,24N11,24I14 (PDG) ECL4"
    },
    {
      "id": "btech_4_MON_7_2ag306",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT412",
      "batches": [
        "24E11"
      ],
      "faculty": "AKN",
      "room": "CR17",
      "raw": "L-25B11BT412 24E11 (AKN) CR17"
    },
    {
      "id": "btech_4_MON_0_qxkfp1",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC412",
      "batches": [
        "24B11",
        "24G11",
        "24H11"
      ],
      "faculty": "PRG",
      "room": "TR2",
      "raw": "L-25B11EC412 24B11,24G11,24H11 (PRG) TR2"
    },
    {
      "id": "btech_4_MON_1_02i2sl",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC413",
      "batches": [
        "24B11",
        "24G11"
      ],
      "faculty": "VKB",
      "room": "CR1",
      "raw": "L-25B11EC413 24B11,24G11 (VKB) CR1"
    },
    {
      "id": "btech_4_MON_6_ll3k4y",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "AVA",
      "room": "CR17",
      "raw": "T-25B11CI412 24J12,24K11 (AVA) CR17"
    },
    {
      "id": "btech_4_MON_1_98kub4",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI416",
      "batches": [
        "24H11"
      ],
      "faculty": "EMP",
      "room": "ECL8,TR3",
      "raw": "L-25B11CI416 24H11 (EMP) ECL8,TR3"
    },
    {
      "id": "btech_4_MON_2_ocpzf5",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CE472",
      "batches": [
        "24D11"
      ],
      "faculty": "ADP",
      "room": "HILAB",
      "raw": "P-24B17CE472 24D11 (ADP) HILAB"
    },
    {
      "id": "btech_4_MON_3_lc8r24",
      "semesterId": "btech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CE472",
      "batches": [
        "24D11"
      ],
      "faculty": "ADP",
      "room": "HILAB",
      "raw": "P-24B17CE472 24D11 (ADP) HILAB"
    },
    {
      "id": "btech_4_TUE_0_23tko5",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "ALK",
      "room": "CR7",
      "raw": "L-25B11CI411 24A11,24A12,24A13 (ALK) CR7"
    },
    {
      "id": "btech_4_TUE_6_soz0lb",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "VNS",
      "room": "CL6",
      "raw": "P-25B17CI473 24J12,24K11 (VNS) CL6"
    },
    {
      "id": "btech_4_TUE_7_trcxg6",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "VNS",
      "room": "CL6",
      "raw": "P-25B17CI473 24J12,24K11 (VNS) CL6"
    },
    {
      "id": "btech_4_TUE_1_8qtotb",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "PDG",
      "room": "CR7",
      "raw": "L-25B11CI411 24A110,24L11,24N11,24I14 (PDG) CR7"
    },
    {
      "id": "btech_4_TUE_2_cff6y9",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A13"
      ],
      "faculty": "RVS",
      "room": "CL9_2",
      "raw": "P-25B17CI472 24A13 (RVS) CL9_2"
    },
    {
      "id": "btech_4_TUE_3_r8uj2b",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A13"
      ],
      "faculty": "RVS",
      "room": "CL9_2",
      "raw": "P-25B17CI472 24A13 (RVS) CL9_2"
    },
    {
      "id": "btech_4_TUE_6_2h3jy0",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B23[24A16"
      ],
      "faculty": "HRI",
      "room": "CL3_2",
      "raw": "P-25B1WCI471 B23[24A16] (HRI) CL3_2"
    },
    {
      "id": "btech_4_TUE_7_72ev24",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B23[24A16"
      ],
      "faculty": "HRI",
      "room": "CL3_2",
      "raw": "P-25B1WCI471 B23[24A16] (HRI) CL3_2"
    },
    {
      "id": "btech_4_TUE_1_w2lqh1",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "24BB1HS412",
      "batches": [
        "24W11"
      ],
      "faculty": "TNS",
      "room": "TR6",
      "raw": "L-24BB1HS412 24W11 (TNS) TR6"
    },
    {
      "id": "btech_4_TUE_2_lor3wp",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "AVA",
      "room": "DLC,CR9",
      "raw": "L-25B11CI412 24I11,24I12,24I13 (AVA) DLC,CR9"
    },
    {
      "id": "btech_4_TUE_3_stvxuk",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT413",
      "batches": [
        "24E11"
      ],
      "faculty": "ABH",
      "room": "CR9",
      "raw": "L-25B11BT413 24E11 (ABH) CR9"
    },
    {
      "id": "btech_4_TUE_6_deaw02",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24J11"
      ],
      "faculty": "ALK",
      "room": "ECL4",
      "raw": "P-25B17CI471 24J11 (ALK) ECL4"
    },
    {
      "id": "btech_4_TUE_7_2trw2l",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24J11"
      ],
      "faculty": "ALK",
      "room": "ECL4",
      "raw": "P-25B17CI471 24J11 (ALK) ECL4"
    },
    {
      "id": "btech_4_TUE_1_tzklyr",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "ATA",
      "room": "CR10",
      "raw": "L-25B1WCI431 24A11,24A12,24A13 (ATA) CR10"
    },
    {
      "id": "btech_4_TUE_3_eodbnz",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "24B11CI411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "HST",
      "room": "LT3",
      "raw": "L-24B11CI411 24I11,24I12,24I13 (HST) LT3"
    },
    {
      "id": "btech_4_TUE_6_hq85v7",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B11[24A11"
      ],
      "faculty": "ATA",
      "room": "CL9_2",
      "raw": "P-25B1WCI471 B11[24A11] (ATA) CL9_2"
    },
    {
      "id": "btech_4_TUE_7_qk2v28",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B11[24A11"
      ],
      "faculty": "ATA",
      "room": "CL9_2",
      "raw": "P-25B1WCI471 B11[24A11] (ATA) CL9_2"
    },
    {
      "id": "btech_4_TUE_0_6dz5y8",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24C11",
        "24I14"
      ],
      "faculty": "MNK",
      "room": "DLC,CR10",
      "raw": "L-25B11CI414 24A110,24L11,24N11,24C11,24I14 (MNK) DLC,CR10"
    },
    {
      "id": "btech_4_TUE_1_ilmktv",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "RRA",
      "room": "CR2",
      "raw": "L-25B11GE411 24A17,24A18,24A19 (RRA) CR2"
    },
    {
      "id": "btech_4_TUE_2_fq3cfg",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "AMN",
      "room": "LT3",
      "raw": "L-25B11CI413  24A110,24L11,24N11, 24I14,24C11,24P11,24F11 (AMN) LT3"
    },
    {
      "id": "btech_4_TUE_3_c0qzb7",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11EC415",
      "batches": [
        "24G11"
      ],
      "faculty": "HSL",
      "room": "TR5",
      "raw": "L-25B11EC415 24G11 (HSL) TR5"
    },
    {
      "id": "btech_4_TUE_6_j63298",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI473",
      "batches": [
        "B61[24A11",
        "24A14",
        "24A15",
        "24A16",
        "26A17",
        "24A19"
      ],
      "faculty": "AYS",
      "room": "ECL7",
      "raw": "P-25B1WCI473 B61[24A11,24A14,24A15,24A16,26A17,24A19] (AYS) ECL7"
    },
    {
      "id": "btech_4_TUE_7_vztxww",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI473",
      "batches": [
        "B61[24A11",
        "24A14",
        "24A15",
        "24A16",
        "26A17",
        "24A19"
      ],
      "faculty": "AYS",
      "room": "ECL7",
      "raw": "P-25B1WCI473 B61[24A11,24A14,24A15,24A16,26A17,24A19] (AYS) ECL7"
    },
    {
      "id": "btech_4_TUE_0_848uuj",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24I12"
      ],
      "faculty": "AVA",
      "room": "CL3_1",
      "raw": "P-25B17CI472 24I12 (AVA) CL3_1"
    },
    {
      "id": "btech_4_TUE_1_6iaxvo",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24I12"
      ],
      "faculty": "AVA",
      "room": "CL3_1",
      "raw": "P-25B17CI472 24I12 (AVA) CL3_1"
    },
    {
      "id": "btech_4_TUE_2_nbf7qw",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B53[24J11",
        "24J12"
      ],
      "faculty": "GVN",
      "room": "CL4",
      "raw": "P-25B1WCI471 B53[24J11,24J12] (GVN) CL4"
    },
    {
      "id": "btech_4_TUE_3_g19tes",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B53[24J11",
        "24J12"
      ],
      "faculty": "GVN",
      "room": "CL4",
      "raw": "P-25B1WCI471 B53[24J11,24J12] (GVN) CL4"
    },
    {
      "id": "btech_4_TUE_8_ajy6wl",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS432",
      "batches": [],
      "faculty": "DLR",
      "room": "LT3",
      "raw": "L-25B1WHS432  (DLR) LT3"
    },
    {
      "id": "btech_4_TUE_0_xhayzv",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBT631",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "GPL",
      "room": "CR12",
      "raw": "L-18B1WBT631 24E11,24F11 (GPL) CR12"
    },
    {
      "id": "btech_4_TUE_3_tj1c5v",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CE411",
      "batches": [
        "24D11"
      ],
      "faculty": "CPG",
      "room": "TR9",
      "raw": "T-25B11CE411 24D11 (CPG) TR9"
    },
    {
      "id": "btech_4_TUE_5_zvivzz",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS431",
      "batches": [],
      "faculty": "TGM",
      "room": "CR6",
      "raw": "L-25B1WHS431  (TGM) CR6"
    },
    {
      "id": "btech_4_TUE_6_p2k8j5",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "PNS",
      "room": "CR2",
      "raw": "L-25B11GE411 24I11,24I12,24I13 (PNS) CR2"
    },
    {
      "id": "btech_4_TUE_7_35k8v9",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24I11"
      ],
      "faculty": "AVA",
      "room": "CR17",
      "raw": "T-25B11CI412 24I11 (AVA) CR17"
    },
    {
      "id": "btech_4_TUE_8_rdz4ib",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS433",
      "batches": [],
      "faculty": "NJL",
      "room": "CR5",
      "raw": "L-25B1WHS433  (NJL) CR5"
    },
    {
      "id": "btech_4_TUE_0_eutmww",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "AKR",
      "room": "CR1",
      "raw": "L-25B11CI414 24A17,24A18,24A19 (AKR) CR1"
    },
    {
      "id": "btech_4_TUE_1_wmafyb",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC411",
      "batches": [
        "24B11",
        "24G11"
      ],
      "faculty": "ALK",
      "room": "TR3",
      "raw": "L-25B11EC411 24B11,24G11 (ALK) TR3"
    },
    {
      "id": "btech_4_TUE_2_f5b3gz",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24BBWHS431",
      "batches": [
        "24W11"
      ],
      "faculty": "ASA",
      "room": "CR18",
      "raw": "L-24BBWHS431 24W11 (ASA) CR18"
    },
    {
      "id": "btech_4_TUE_3_pyv6d0",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "AMN",
      "room": "CR7",
      "raw": "L-25B11CI413 24A17,24A18,24A19 (AMN) CR7"
    },
    {
      "id": "btech_4_TUE_5_z6qz2p",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS432",
      "batches": [],
      "faculty": "DLR",
      "room": "CR9",
      "raw": "L-25B1WHS432  (DLR) CR9"
    },
    {
      "id": "btech_4_TUE_6_em9bvk",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT415",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "JTV",
      "room": "CR12",
      "raw": "L-25B11BT415 24E11, 24F11 (JTV) CR12"
    },
    {
      "id": "btech_4_TUE_7_zaa02x",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A110",
        "24F11",
        "24C11",
        "24D11",
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "PNS",
      "room": "DLC,CR2",
      "raw": "L-25B11GE411 24A110,24F11,24C11,24D11,24L11,24N11,24I14 (PNS) DLC,CR2"
    },
    {
      "id": "btech_4_TUE_8_c6g490",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS434",
      "batches": [],
      "faculty": "RTK",
      "room": "LT2",
      "raw": "L-25B1WHS434  (RTK) LT2"
    },
    {
      "id": "btech_4_TUE_1_bfki78",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24J11",
        "24J12",
        "24K11",
        "24E11",
        "24F11"
      ],
      "faculty": "RKI",
      "room": "CR6",
      "raw": "L-25B11CI414 24J11,24J12,24K11,24E11,24F11 (RKI) CR6"
    },
    {
      "id": "btech_4_TUE_2_c49x6h",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CE411",
      "batches": [
        "24D11"
      ],
      "faculty": "AKG",
      "room": "CR15",
      "raw": "L-18B11CE411 24D11 (AKG) CR15"
    },
    {
      "id": "btech_4_TUE_3_lcu95c",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A14"
      ],
      "faculty": "ARV",
      "room": "TR2",
      "raw": "T-25B11CI412 24A14 (ARV) TR2"
    },
    {
      "id": "btech_4_TUE_5_kgyqwl",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS433",
      "batches": [],
      "faculty": "NJL",
      "room": "CR2",
      "raw": "L-25B1WHS433  (NJL) CR2"
    },
    {
      "id": "btech_4_TUE_7_mqkn29",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "24BB1HS411",
      "batches": [
        "24W11"
      ],
      "faculty": "ANU",
      "room": "TR3",
      "raw": "L-24BB1HS411 24W11 (ANU) TR3"
    },
    {
      "id": "btech_4_TUE_0_jd107k",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A15"
      ],
      "faculty": "EMP",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A15 (EMP) ECL4"
    },
    {
      "id": "btech_4_TUE_1_gw5ump",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A15"
      ],
      "faculty": "EMP",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A15 (EMP) ECL4"
    },
    {
      "id": "btech_4_TUE_2_7gz8q7",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11BT412",
      "batches": [
        "24E11"
      ],
      "faculty": "AKN",
      "room": "TR1",
      "raw": "L-25B11BT412 24E11 (AKN) TR1"
    },
    {
      "id": "btech_4_TUE_5_747ztr",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS434",
      "batches": [],
      "faculty": "RTK",
      "room": "LT2",
      "raw": "L-25B1WHS434  (RTK) LT2"
    },
    {
      "id": "btech_4_TUE_6_zj8lan",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11EC414",
      "batches": [
        "24H11"
      ],
      "faculty": "RKU",
      "room": "TR2",
      "raw": "T-25B11EC414 24H11 (RKU) TR2"
    },
    {
      "id": "btech_4_TUE_7_auwu3y",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WEC431",
      "batches": [
        "24B11",
        "24H11"
      ],
      "faculty": "VKB",
      "room": "TR4",
      "raw": "L-25B1WEC431 24B11,24H11 (VKB) TR4"
    },
    {
      "id": "btech_4_TUE_0_8lpjmd",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CE412",
      "batches": [
        "24D11"
      ],
      "faculty": "ABJ",
      "room": "CR14",
      "raw": "L-24B11CE412 24D11 (ABJ) CR14"
    },
    {
      "id": "btech_4_TUE_1_1f3w01",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC414",
      "batches": [
        "24H11"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "L-25B11EC414 24H11 (RKU) TR4"
    },
    {
      "id": "btech_4_TUE_2_ievmhn",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI473",
      "batches": [
        "24K11"
      ],
      "faculty": "AYS",
      "room": "ECL7",
      "raw": "P-25B1WCI473 24K11 (AYS) ECL7"
    },
    {
      "id": "btech_4_TUE_3_05o2sl",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI473",
      "batches": [
        "24K11"
      ],
      "faculty": "AYS",
      "room": "ECL7",
      "raw": "P-25B1WCI473 24K11 (AYS) ECL7"
    },
    {
      "id": "btech_4_TUE_6_uj4u3u",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI418",
      "batches": [
        "24L11"
      ],
      "faculty": "GVN",
      "room": "CR17",
      "raw": "L-25B11CI418 24L11 (GVN)  CR17"
    },
    {
      "id": "btech_4_TUE_8_drvayz",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI379",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "RKI",
      "room": "CR8",
      "raw": "P-25B17CI379 24E11,24F11 (RKI) CR8"
    },
    {
      "id": "btech_4_TUE_0_vuahmy",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "VNS",
      "room": "CR8",
      "raw": "L-25B11CI413 24J11,24J12,24K11 (VNS) CR8"
    },
    {
      "id": "btech_4_TUE_1_jvtzyr",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CE413",
      "batches": [
        "24D11"
      ],
      "faculty": "ADP",
      "room": "CR15",
      "raw": "L-24B11CE413 24D11 (ADP) CR15"
    },
    {
      "id": "btech_4_TUE_2_qkn1pp",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A12"
      ],
      "faculty": "MGN",
      "room": "CL9_1",
      "raw": "P-25B17CI476 24A12 (MGN) CL9_1"
    },
    {
      "id": "btech_4_TUE_3_yres6e",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A12"
      ],
      "faculty": "MGN",
      "room": "CL9_1",
      "raw": "P-25B17CI476 24A12 (MGN) CL9_1"
    },
    {
      "id": "btech_4_TUE_6_db6g1o",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC475",
      "batches": [
        "24G11"
      ],
      "faculty": "HSL",
      "room": "ECL8",
      "raw": "P-25B17EC475 24G11 (HSL) ECL8"
    },
    {
      "id": "btech_4_TUE_7_p9rh1o",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC475",
      "batches": [
        "24G11"
      ],
      "faculty": "HSL",
      "room": "ECL8",
      "raw": "P-25B17EC475 24G11 (HSL) ECL8"
    },
    {
      "id": "btech_4_TUE_0_juf3d1",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24I11"
      ],
      "faculty": "PRG",
      "room": "ECL5",
      "raw": "P-25B17CI471 24I11 (PRG) ECL5"
    },
    {
      "id": "btech_4_TUE_1_ssl8lo",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24I11"
      ],
      "faculty": "PRG",
      "room": "ECL5",
      "raw": "P-25B17CI471 24I11 (PRG) ECL5"
    },
    {
      "id": "btech_4_TUE_3_cggt5m",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "SKS",
      "room": "LT2",
      "raw": "L-25B11CI412 24A110,24L11,24N11,24I14,24C11,24P11,24F11 (SKS) LT2"
    },
    {
      "id": "btech_4_TUE_6_hr75x2",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "24BB1HS413",
      "batches": [
        "24W11"
      ],
      "faculty": "TGM",
      "room": "CR19",
      "raw": "L-24BB1HS413 24W11 (TGM) CR19"
    },
    {
      "id": "btech_4_TUE_0_rfd9fz",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC413",
      "batches": [
        "24B11",
        "24G11"
      ],
      "faculty": "VKB",
      "room": "CR18",
      "raw": "L-25B11EC413 24B11,24G11 (VKB) CR18"
    },
    {
      "id": "btech_4_TUE_1_9tt4d7",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI435",
      "batches": [
        "24C11"
      ],
      "faculty": "PTK",
      "room": "DLC,CR18",
      "raw": "L-25B1WCI435 24C11 (PTK) DLC,CR18"
    },
    {
      "id": "btech_4_TUE_2_37uu2a",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "PKG",
      "room": "CR5",
      "raw": "L-25B11CI414 24A14,24A15,24A16 (PKG) CR5"
    },
    {
      "id": "btech_4_TUE_7_15ja6n",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT414",
      "batches": [
        "24E11"
      ],
      "faculty": "RJK",
      "room": "TR5",
      "raw": "L-25B11BT414 24E11 (RJK) TR5"
    },
    {
      "id": "btech_4_TUE_0_ndwm6k",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A14"
      ],
      "faculty": "ARV",
      "room": "CL8_1",
      "raw": "P-25B17CI472 24A14 (ARV) CL8_1"
    },
    {
      "id": "btech_4_TUE_1_1d701f",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A14"
      ],
      "faculty": "ARV",
      "room": "CL8_1",
      "raw": "P-25B17CI472 24A14 (ARV) CL8_1"
    },
    {
      "id": "btech_4_TUE_2_w0ap06",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "NTJ",
      "room": "CR6",
      "raw": "L-25B11CI411 24A17,24A18,24A19 (NTJ) CR6"
    },
    {
      "id": "btech_4_TUE_3_9kgjuc",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "24B11CI416",
      "batches": [
        "24H11"
      ],
      "faculty": "EMP",
      "room": "ECL8,TR1",
      "raw": "L-24B11CI416 24H11 (EMP) ECL8,TR1"
    },
    {
      "id": "btech_4_TUE_0_o87tcq",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24I13"
      ],
      "faculty": "AKJ",
      "room": "CL9_2",
      "raw": "P-25B17CI472 24I13 (AKJ) CL9_2"
    },
    {
      "id": "btech_4_TUE_1_jzbujk",
      "semesterId": "btech_4",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24I13"
      ],
      "faculty": "AKJ",
      "room": "CL9_2",
      "raw": "P-25B17CI472 24I13 (AKJ) CL9_2"
    },
    {
      "id": "btech_4_WED_2_pwaj2u",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24I11"
      ],
      "faculty": "PDN",
      "room": "CL4",
      "raw": "P-25B17CI476 24I11 (PDN) CL4"
    },
    {
      "id": "btech_4_WED_3_xvh63k",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24I11"
      ],
      "faculty": "PDN",
      "room": "CL4",
      "raw": "P-25B17CI476 24I11 (PDN) CL4"
    },
    {
      "id": "btech_4_WED_6_uts8pw",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CE471",
      "batches": [
        "24D11"
      ],
      "faculty": "CPG",
      "room": "CONCLAB",
      "raw": "P-24B17CE471 24D11 (CPG) CONCLAB"
    },
    {
      "id": "btech_4_WED_7_iakdks",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CE471",
      "batches": [
        "24D11"
      ],
      "faculty": "CPG",
      "room": "CONCLAB",
      "raw": "P-24B17CE471 24D11 (CPG) CONCLAB"
    },
    {
      "id": "btech_4_WED_0_kh6lio",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A14"
      ],
      "faculty": "EMP",
      "room": "ECL3",
      "raw": "P-25B17CI471 24A14 (EMP) ECL3"
    },
    {
      "id": "btech_4_WED_1_nqi474",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A14"
      ],
      "faculty": "EMP",
      "room": "ECL3",
      "raw": "P-25B17CI471 24A14 (EMP) ECL3"
    },
    {
      "id": "btech_4_WED_2_qxjz4q",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "PKG",
      "room": "CR1",
      "raw": "L-25B11CI414 24A14,24A15,24A16  (PKG) CR1"
    },
    {
      "id": "btech_4_WED_3_q60ewe",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11EC411",
      "batches": [
        "24B11",
        "24G11"
      ],
      "faculty": "ALK",
      "room": "CR12",
      "raw": "L-25B11EC411 24B11,24G11 (ALK) CR12"
    },
    {
      "id": "btech_4_WED_6_9vxtjf",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "ARV",
      "room": "DLC,CR7",
      "raw": "L-25B11CI412 24A14,24A15,24A16 (ARV) DLC,CR7"
    },
    {
      "id": "btech_4_WED_2_u71rej",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24BB1HS413",
      "batches": [
        "24W11"
      ],
      "faculty": "TGM",
      "room": "TR5",
      "raw": "L-24BB1HS413 24W11 (TGM) TR5"
    },
    {
      "id": "btech_4_WED_5_1e5jfi",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "MNK",
      "room": "CR5",
      "raw": "L-25B11CI413 24A14,24A15,24A16 (MNK) CR5"
    },
    {
      "id": "btech_4_WED_8_t4k4bk",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS432",
      "batches": [],
      "faculty": "DLR",
      "room": "LT3",
      "raw": "L-25B1WHS432  (DLR) LT3"
    },
    {
      "id": "btech_4_WED_0_u89k5s",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CE414",
      "batches": [
        "24D11"
      ],
      "faculty": "KKR",
      "room": "CR14",
      "raw": "L-24B11CE414 24D11 (KKR) CR14"
    },
    {
      "id": "btech_4_WED_1_yltoue",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC412",
      "batches": [
        "24B11",
        "24G11",
        "24H11"
      ],
      "faculty": "PRG",
      "room": "TR3",
      "raw": "L-25B11EC412 24B11,24G11,24H11 (PRG) TR3"
    },
    {
      "id": "btech_4_WED_2_s1rose",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WEC432",
      "batches": [
        "24B11",
        "24H11"
      ],
      "faculty": "NTJ",
      "room": "ECL6",
      "raw": "L-25B1WEC432 24B11,24H11 (NTJ) ECL6"
    },
    {
      "id": "btech_4_WED_3_vsryr8",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "24BBWHS431",
      "batches": [
        "24W11"
      ],
      "faculty": "ASA",
      "room": "TR4",
      "raw": "L-24BBWHS431 24W11 (ASA) TR4"
    },
    {
      "id": "btech_4_WED_5_evkfm5",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "RKI",
      "room": "CR6",
      "raw": "L-25B11CI414 24I11,24I12,24I13 (RKI) CR6"
    },
    {
      "id": "btech_4_WED_6_zg1rbw",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI473",
      "batches": [
        "B62[24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11",
        "24E11",
        "24F11",
        "24A12",
        "24A13",
        "24A18"
      ],
      "faculty": "SKP",
      "room": "ECL7",
      "raw": "P-25B1WCI473 B62[24A110,24L11,24N11,24I14,24C11,24E11,24F11,24A12,24A13,24A18] (SKP) ECL7"
    },
    {
      "id": "btech_4_WED_7_09tqof",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI473",
      "batches": [
        "B62[24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11",
        "24E11",
        "24F11",
        "24A12",
        "24A13",
        "24A18"
      ],
      "faculty": "SKP",
      "room": "ECL7",
      "raw": "P-25B1WCI473 B62[24A110,24L11,24N11,24I14,24C11,24E11,24F11,24A12,24A13,24A18] (SKP) ECL7"
    },
    {
      "id": "btech_4_WED_8_cipfqm",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS433",
      "batches": [],
      "faculty": "NJL",
      "room": "CR5",
      "raw": "L-25B1WHS433  (NJL) CR5"
    },
    {
      "id": "btech_4_WED_1_6xvt57",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "24B11GE411",
      "batches": [
        "24J11",
        "24J12",
        "24K11",
        "25W11"
      ],
      "faculty": "RRA",
      "room": "CR11",
      "raw": "L-24B11GE411 24J11,24J12,24K11,25W11 (RRA) CR11"
    },
    {
      "id": "btech_4_WED_2_whrkzq",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24J11"
      ],
      "faculty": "SMA",
      "room": "CL8_2",
      "raw": "P-25B17CI476 24J11 (SMA) CL8_2"
    },
    {
      "id": "btech_4_WED_3_8mqksr",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24J11"
      ],
      "faculty": "SMA",
      "room": "CL8_2",
      "raw": "P-25B17CI476 24J11 (SMA) CL8_2"
    },
    {
      "id": "btech_4_WED_5_0jvmmk",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11EC416",
      "batches": [
        "24B11"
      ],
      "faculty": "PDG",
      "room": "TR3",
      "raw": "L-25B11EC416 24B11 (PDG) TR3"
    },
    {
      "id": "btech_4_WED_6_14avr7",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "B62[24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11"
      ],
      "faculty": "AYS",
      "room": "CR8",
      "raw": "L-25B1WCI431 B62[24A110,24L11,24N11,24I14,24C11] (AYS) CR8"
    },
    {
      "id": "btech_4_WED_7_v8iei0",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "B62[24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11"
      ],
      "faculty": "AYS",
      "room": "CR8",
      "raw": "L-25B1WCI431 B62[24A110,24L11,24N11,24I14,24C11] (AYS) CR8"
    },
    {
      "id": "btech_4_WED_8_8uibjy",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS434",
      "batches": [],
      "faculty": "RTK",
      "room": "LT2",
      "raw": "L-25B1WHS434  (RTK) LT2"
    },
    {
      "id": "btech_4_WED_0_kwgd6b",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "NTJ",
      "room": "CR1",
      "raw": "L-25B11CI411 24A17,24A18,24A19 (NTJ) CR1"
    },
    {
      "id": "btech_4_WED_1_khem4t",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11BT412",
      "batches": [
        "24E11"
      ],
      "faculty": "AKN",
      "room": "TR2",
      "raw": "L-25B11BT412 24E11 (AKN) TR2"
    },
    {
      "id": "btech_4_WED_2_pummgr",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A110"
      ],
      "faculty": "VNS",
      "room": "CL3_1",
      "raw": "P-25B17CI473 24A110 (VNS) CL3_1"
    },
    {
      "id": "btech_4_WED_3_61m8ia",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A110"
      ],
      "faculty": "VNS",
      "room": "CL3_1",
      "raw": "P-25B17CI473 24A110 (VNS) CL3_1"
    },
    {
      "id": "btech_4_WED_6_g078u2",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11EC412",
      "batches": [
        "24B11",
        "24G11",
        "24H11"
      ],
      "faculty": "PRG",
      "room": "TR4",
      "raw": "T-25B11EC412 24B11,24G11,24H11 (PRG) TR4"
    },
    {
      "id": "btech_4_WED_7_p6hith",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "PNS",
      "room": "CR2",
      "raw": "L-25B11GE411 24A14,24A15,24A16 (PNS) CR2"
    },
    {
      "id": "btech_4_WED_1_w2inme",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CE411",
      "batches": [
        "24D11"
      ],
      "faculty": "CPG",
      "room": "CR14",
      "raw": "L-25B11CE411 24D11 (CPG) CR14"
    },
    {
      "id": "btech_4_WED_2_q7ka7v",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B33[24A19"
      ],
      "faculty": "HST",
      "room": "CL5_1",
      "raw": "P-25B1WCI471 B33[24A19] (HST) CL5_1"
    },
    {
      "id": "btech_4_WED_3_zkj0ie",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B33[24A19"
      ],
      "faculty": "HST",
      "room": "CL5_1",
      "raw": "P-25B1WCI471 B33[24A19] (HST) CL5_1"
    },
    {
      "id": "btech_4_WED_5_hyynj0",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "MSD",
      "room": "CR8",
      "raw": "L-25B11CI411 24J11,24J12,24K11 (MSD) CR8"
    },
    {
      "id": "btech_4_WED_7_zhz6cr",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "B5[24I11",
        "24I12",
        "24I13",
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "RVS",
      "room": "LT3",
      "raw": "L-25B1WCI431 B5[24I11,24I12,24I13,24J11,24J12,24K11]  (RVS) LT3"
    },
    {
      "id": "btech_4_WED_0_voczdh",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "SRJ",
      "room": "DLC,CR6",
      "raw": "L-25B11CI414 24A11,24A12,24A13 (SRJ) DLC,CR6"
    },
    {
      "id": "btech_4_WED_2_lls70e",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI475",
      "batches": [
        "24C11"
      ],
      "faculty": "PTK",
      "room": "CL11",
      "raw": "P-25B1WCI475 24C11 (PTK) CL11"
    },
    {
      "id": "btech_4_WED_3_3nnu4q",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI475",
      "batches": [
        "24C11"
      ],
      "faculty": "PTK",
      "room": "CL11",
      "raw": "P-25B1WCI475 24C11 (PTK) CL11"
    },
    {
      "id": "btech_4_WED_5_mg6vz7",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "24BB1HS414",
      "batches": [
        "24W11"
      ],
      "faculty": "DLR",
      "room": "CR19",
      "raw": "T-24BB1HS414 24W11 (DLR) CR19"
    },
    {
      "id": "btech_4_WED_6_jet0od",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A11"
      ],
      "faculty": "RBT",
      "room": "CL9_2",
      "raw": "P-25B17CI473 24A11 (RBT) CL9_2"
    },
    {
      "id": "btech_4_WED_7_j4hial",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A11"
      ],
      "faculty": "RBT",
      "room": "CL9_2",
      "raw": "P-25B17CI473 24A11 (RBT) CL9_2"
    },
    {
      "id": "btech_4_WED_0_ukeiuu",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11BT415",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "JTV",
      "room": "TR7",
      "raw": "L-25B11BT415 24E11,24F11 (JTV) TR7"
    },
    {
      "id": "btech_4_WED_1_d4x8os",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "SWT",
      "room": "LT2",
      "raw": "L-25B11CI411 24I11,24I12,24I13 (SWT) LT2"
    },
    {
      "id": "btech_4_WED_2_60qiqv",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "AVA",
      "room": "CL6",
      "raw": "P-25B17CI472 24J12,24K11 (AVA) CL6"
    },
    {
      "id": "btech_4_WED_3_9xodgq",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "AVA",
      "room": "CL6",
      "raw": "P-25B17CI472 24J12,24K11 (AVA) CL6"
    },
    {
      "id": "btech_4_WED_5_2gb66l",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "AMN",
      "room": "CR7",
      "raw": "L-25B11CI413 24A17,24A18,24A19 (AMN) CR7"
    },
    {
      "id": "btech_4_WED_7_81g4zc",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "24BB1HS412",
      "batches": [
        "24W11"
      ],
      "faculty": "TNS",
      "room": "TR5",
      "raw": "T-24BB1HS412 24W11 (TNS) TR5"
    },
    {
      "id": "btech_4_WED_2_9sgb9y",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "SKS",
      "room": "CL10",
      "raw": "P-25B17CI472 24L11,24N11,24I14 (SKS) CL10"
    },
    {
      "id": "btech_4_WED_3_6gps8b",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "SKS",
      "room": "CL10",
      "raw": "P-25B17CI472 24L11,24N11,24I14 (SKS) CL10"
    },
    {
      "id": "btech_4_WED_5_0y9f61",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT413",
      "batches": [
        "24E11"
      ],
      "faculty": "ABH",
      "room": "TR6",
      "raw": "L-25B11BT413 24E11 (ABH) TR6"
    },
    {
      "id": "btech_4_WED_6_pfep03",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "AVA",
      "room": "CR9",
      "raw": "L-25B11CI412 24J11,24J12,24K11 (AVA) CR9"
    },
    {
      "id": "btech_4_WED_0_8sqg38",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC415",
      "batches": [
        "24G11"
      ],
      "faculty": "HSL",
      "room": "CR17",
      "raw": "L-25B11EC415 24G11 (HSL) CR17"
    },
    {
      "id": "btech_4_WED_1_84fcsd",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "B3[24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "ATA",
      "room": "CR1",
      "raw": "L-25B1WCI431 B3[24A17,24A18,24A19] (ATA) CR1"
    },
    {
      "id": "btech_4_WED_2_bx0bk5",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B11CI476",
      "batches": [
        "24I12"
      ],
      "faculty": "RKI",
      "room": "CL9_2",
      "raw": "P-25B11CI476 24I12 (RKI) CL9_2"
    },
    {
      "id": "btech_4_WED_3_ftyt5r",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B11CI476",
      "batches": [
        "24I12"
      ],
      "faculty": "RKI",
      "room": "CL9_2",
      "raw": "P-25B11CI476 24I12 (RKI) CL9_2"
    },
    {
      "id": "btech_4_WED_6_hvjbjp",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A19"
      ],
      "faculty": "PDN",
      "room": "CL11",
      "raw": "P-25B17CI476 24A19 (PDN) CL11"
    },
    {
      "id": "btech_4_WED_7_43ixgg",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A19"
      ],
      "faculty": "PDN",
      "room": "CL11",
      "raw": "P-25B17CI476 24A19 (PDN) CL11"
    },
    {
      "id": "btech_4_WED_0_0qdf13",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "VNS",
      "room": "LT3",
      "raw": "L-25B11CI413 24I11,24I12,24I13 (VNS) LT3"
    },
    {
      "id": "btech_4_WED_2_wgmv0x",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A18"
      ],
      "faculty": "AMN",
      "room": "CL9_1",
      "raw": "P-25B17CI473 24A18 (AMN) CL9_1"
    },
    {
      "id": "btech_4_WED_3_dng69m",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A18"
      ],
      "faculty": "AMN",
      "room": "CL9_1",
      "raw": "P-25B17CI473 24A18 (AMN) CL9_1"
    },
    {
      "id": "btech_4_WED_6_sb74uo",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A17"
      ],
      "faculty": "NTJ",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A17 (NTJ) ECL4"
    },
    {
      "id": "btech_4_WED_7_g0n29f",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A17"
      ],
      "faculty": "NTJ",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A17 (NTJ) ECL4"
    },
    {
      "id": "btech_4_WED_0_tgfuk3",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A15"
      ],
      "faculty": "MNK",
      "room": "CL6",
      "raw": "P-25B17CI473 24A15 (MNK) CL6"
    },
    {
      "id": "btech_4_WED_1_b2wz3c",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A15"
      ],
      "faculty": "MNK",
      "room": "CL6",
      "raw": "P-25B17CI473 24A15 (MNK) CL6"
    },
    {
      "id": "btech_4_WED_2_xawtkn",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24I13"
      ],
      "faculty": "MSD",
      "room": "ECL4",
      "raw": "P-25B17CI471 24I13 (MSD) ECL4"
    },
    {
      "id": "btech_4_WED_3_7c4dsh",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24I13"
      ],
      "faculty": "MSD",
      "room": "ECL4",
      "raw": "P-25B17CI471 24I13 (MSD) ECL4"
    },
    {
      "id": "btech_4_WED_6_ri4vbw",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B12[24A12"
      ],
      "faculty": "ATA",
      "room": "CL5_2",
      "raw": "P-25B1WCI471 B12[24A12] (ATA) CL5_2"
    },
    {
      "id": "btech_4_WED_7_0mt9qi",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B12[24A12"
      ],
      "faculty": "ATA",
      "room": "CL5_2",
      "raw": "P-25B1WCI471 B12[24A12] (ATA) CL5_2"
    },
    {
      "id": "btech_4_WED_0_ea07nw",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI417",
      "batches": [
        "24N11"
      ],
      "faculty": "PLK",
      "room": "TR2",
      "raw": "L-25B11CI417 24N11 (PLK) TR2"
    },
    {
      "id": "btech_4_WED_1_ki4i4j",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "AMN",
      "room": "LT3",
      "raw": "L-25B11CI413  24A110,24L11,24N11, 24I14,24C11,24P11,24F11 (AMN) LT3"
    },
    {
      "id": "btech_4_WED_2_fzhgb1",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A17"
      ],
      "faculty": "RVS",
      "room": "TR2",
      "raw": "T-25B11CI412 24A17 (RVS) TR2"
    },
    {
      "id": "btech_4_WED_3_k8g5hb",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "RBT",
      "room": "LT2",
      "raw": "L-25B11CI413 24A11,24A12,24A13 (RBT) LT2"
    },
    {
      "id": "btech_4_WED_5_tdqod7",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "SKS",
      "room": "LT2",
      "raw": "L-25B11CI412 24A110,24L11,24N11,24I14,24C11,24P11,24F11 (SKS) LT2"
    },
    {
      "id": "btech_4_WED_6_4h0p7t",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "24B11CI411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "HST",
      "room": "LT2",
      "raw": "L-24B11CI411 24I11,24I12,24I13 (HST) LT2"
    },
    {
      "id": "btech_4_WED_7_4o1dt9",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11EC414",
      "batches": [
        "24H11"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "L-25B11EC414 24H11 (RKU) TR4"
    },
    {
      "id": "btech_4_WED_0_f1e98m",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CI411",
      "batches": [
        "24J11",
        "24J12",
        "24K11",
        "24I14"
      ],
      "faculty": "HST",
      "room": "CR2",
      "raw": "L-24B11CI411 24J11,24J12,24K11,24I14 (HST) CR2"
    },
    {
      "id": "btech_4_WED_2_zfpshj",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT471",
      "batches": [
        "24F11"
      ],
      "faculty": "SML",
      "room": "BIL",
      "raw": "P-25B17BT471 24F11  (SML) BIL"
    },
    {
      "id": "btech_4_WED_3_jo00ir",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT471",
      "batches": [
        "24F11"
      ],
      "faculty": "SML",
      "room": "BIL",
      "raw": "P-25B17BT471 24F11  (SML) BIL"
    },
    {
      "id": "btech_4_WED_1_dw3406",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "TYN",
      "room": "CR2",
      "raw": "L-25B11GE411 24A11,24A12,24A13 (TYN) CR2"
    },
    {
      "id": "btech_4_WED_2_4z1wvv",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "AKJ",
      "room": "CR8",
      "raw": "L-25B11CI412 24A11,24A12,24A13 (AKJ) CR8"
    },
    {
      "id": "btech_4_WED_3_w9qk9v",
      "semesterId": "btech_4",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "EMP",
      "room": "CR8",
      "raw": "L-25B11CI411 24A14,24A15,24A16 (EMP) CR8"
    },
    {
      "id": "btech_4_THU_0_8c1dz0",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A18"
      ],
      "faculty": "SRU",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A18 (SRU) ECL4"
    },
    {
      "id": "btech_4_THU_1_cwfmzb",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A18"
      ],
      "faculty": "SRU",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A18 (SRU) ECL4"
    },
    {
      "id": "btech_4_THU_2_lwek11",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT472",
      "batches": [
        "24E11"
      ],
      "faculty": "SDS",
      "room": "UG1",
      "raw": "P-25B17BT472 24E11 (SDS) UG1"
    },
    {
      "id": "btech_4_THU_3_g1741m",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT472",
      "batches": [
        "24E11"
      ],
      "faculty": "SDS",
      "room": "UG1",
      "raw": "P-25B17BT472 24E11 (SDS) UG1"
    },
    {
      "id": "btech_4_THU_6_d4p63k",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24I13"
      ],
      "faculty": "AVA",
      "room": "CR18",
      "raw": "T-25B11CI412 24I13 (AVA) CR18"
    },
    {
      "id": "btech_4_THU_0_dg3iwo",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A19"
      ],
      "faculty": "PRG",
      "room": "ECL5",
      "raw": "P-25B17CI471 24A19 (PRG) ECL5"
    },
    {
      "id": "btech_4_THU_1_qagclp",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A19"
      ],
      "faculty": "PRG",
      "room": "ECL5",
      "raw": "P-25B17CI471 24A19 (PRG) ECL5"
    },
    {
      "id": "btech_4_THU_2_erki4b",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI379",
      "batches": [
        "24G11"
      ],
      "faculty": "SSA",
      "room": "CL9_2",
      "raw": "P-25B17CI379 24G11 (SSA) CL9_2"
    },
    {
      "id": "btech_4_THU_3_gr85ok",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI379",
      "batches": [
        "24G11"
      ],
      "faculty": "SSA",
      "room": "CL9_2",
      "raw": "P-25B17CI379 24G11 (SSA) CL9_2"
    },
    {
      "id": "btech_4_THU_6_92npyk",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A16"
      ],
      "faculty": "ARV",
      "room": "CL9_1",
      "raw": "P-25B17CI472 24A16 (ARV) CL9_1"
    },
    {
      "id": "btech_4_THU_7_gv79ew",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A16"
      ],
      "faculty": "ARV",
      "room": "CL9_1",
      "raw": "P-25B17CI472 24A16 (ARV) CL9_1"
    },
    {
      "id": "btech_4_THU_2_kl44fq",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "AKR",
      "room": "DLC,CR4",
      "raw": "L-25B11CI414 24A17,24A18,24A19 (AKR) DLC,CR4"
    },
    {
      "id": "btech_4_THU_3_g1ow59",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "MSD",
      "room": "CR5",
      "raw": "L-25B11CI411 24J11,24J12,24K11 (MSD) CR5"
    },
    {
      "id": "btech_4_THU_6_b86ry8",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24I12"
      ],
      "faculty": "RKI",
      "room": "CL5_1",
      "raw": "P-24B17CI471 24I12 (RKI) CL5_1"
    },
    {
      "id": "btech_4_THU_7_29v9pe",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24I12"
      ],
      "faculty": "RKI",
      "room": "CL5_1",
      "raw": "P-24B17CI471 24I12 (RKI) CL5_1"
    },
    {
      "id": "btech_4_THU_0_rzywwb",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "SRJ",
      "room": "CR9",
      "raw": "L-25B11CI414 24A11,24A12,24A13 (SRJ) CR9"
    },
    {
      "id": "btech_4_THU_1_vyytfx",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "TYN",
      "room": "CR8",
      "raw": "L-25B11GE411 24A11,24A12,24A13 (TYN) CR8"
    },
    {
      "id": "btech_4_THU_2_um578f",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CE471",
      "batches": [
        "24D11"
      ],
      "faculty": "AKG",
      "room": "GEOLAB",
      "raw": "P-18B17CE471 24D11 (AKG) GEOLAB"
    },
    {
      "id": "btech_4_THU_3_4wopaa",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CE471",
      "batches": [
        "24D11"
      ],
      "faculty": "AKG",
      "room": "GEOLAB",
      "raw": "P-18B17CE471 24D11 (AKG) GEOLAB"
    },
    {
      "id": "btech_4_THU_5_u7gu7u",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS431",
      "batches": [],
      "faculty": "TGM",
      "room": "CR4",
      "raw": "L-25B1WHS431  (TGM) CR4"
    },
    {
      "id": "btech_4_THU_6_jrfbsz",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "RRA",
      "room": "CR2",
      "raw": "L-25B11GE411 24A17,24A18,24A19 (RRA) CR2"
    },
    {
      "id": "btech_4_THU_7_l9w2on",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WBT432",
      "batches": [
        "24E11"
      ],
      "faculty": "UDB",
      "room": "TR4",
      "raw": "L-25B1WBT432 24E11 (UDB) TR4"
    },
    {
      "id": "btech_4_THU_0_reqj3z",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24C11",
        "24I14"
      ],
      "faculty": "MNK",
      "room": "LT2",
      "raw": "L-25B11CI414 24A110,24L11,24N11,24C11,24I14 (MNK) LT2"
    },
    {
      "id": "btech_4_THU_3_rlvfvx",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "AVA",
      "room": "CR9",
      "raw": "L-25B11CI412 24I11,24I12,24I13 (AVA) CR9"
    },
    {
      "id": "btech_4_THU_5_cbjflj",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS432",
      "batches": [],
      "faculty": "DLR",
      "room": "LT3",
      "raw": "L-25B1WHS432  (DLR) LT3"
    },
    {
      "id": "btech_4_THU_6_leey5a",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI435",
      "batches": [
        "24C11"
      ],
      "faculty": "PTK",
      "room": "TR7",
      "raw": "L-25B1WCI435 24C11 (PTK) TR7"
    },
    {
      "id": "btech_4_THU_7_5ximom",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A110",
        "24F11",
        "24C11",
        "24D11",
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "PNS",
      "room": "DLC,CR2",
      "raw": "L-25B11GE411 24A110,24F11,24C11,24D11,24L11,24N11,24I14 (PNS) DLC,CR2"
    },
    {
      "id": "btech_4_THU_0_aglhvk",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "PKG",
      "room": "DLC,LT3",
      "raw": "L-25B11CI414 24A14,24A15,24A16 (PKG) DLC,LT3"
    },
    {
      "id": "btech_4_THU_2_xdv3ib",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A110",
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "SKS",
      "room": "CR19",
      "raw": "T-25B11CI412 24A110,24C11,24P11,24F11 (SKS) CR19"
    },
    {
      "id": "btech_4_THU_5_ur9ltk",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS433",
      "batches": [],
      "faculty": "NJL",
      "room": "CR2",
      "raw": "L-25B1WHS433  (NJL) CR2"
    },
    {
      "id": "btech_4_THU_6_y20tv8",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24J11"
      ],
      "faculty": "SKS",
      "room": "CL5_2",
      "raw": "P-25B17CI472 24J11 (SKS) CL5_2"
    },
    {
      "id": "btech_4_THU_7_wtxf0c",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24J11"
      ],
      "faculty": "SKS",
      "room": "CL5_2",
      "raw": "P-25B17CI472 24J11 (SKS) CL5_2"
    },
    {
      "id": "btech_4_THU_8_pd9zat",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI433/25B1WCI835",
      "batches": [
        "B6[From",
        "all",
        "batches",
        "24E11",
        "24F11",
        "CS-IT[MCSE]BI81"
      ],
      "faculty": "AYS",
      "room": "LT2",
      "raw": "L-25B1WCI433/25B1WCI835 B6[From all batches],24E11,24F11,CS-IT[MCSE]BI81 (AYS) LT2"
    },
    {
      "id": "btech_4_THU_0_g4r9qw",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC415",
      "batches": [
        "24G11"
      ],
      "faculty": "HSL",
      "room": "CR16",
      "raw": "L-25B11EC415 24G11 (HSL) CR16"
    },
    {
      "id": "btech_4_THU_1_6ai39n",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11BT411",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "SML",
      "room": "TR4",
      "raw": "L-25B11BT411 24E11, 24F11  (SML) TR4"
    },
    {
      "id": "btech_4_THU_3_fsc66w",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "RBT",
      "room": "DLC,CR7",
      "raw": "L-25B11CI413 24A11,24A12,24A13 (RBT) DLC,CR7"
    },
    {
      "id": "btech_4_THU_5_vhi5ks",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS434",
      "batches": [],
      "faculty": "RTK",
      "room": "LT2",
      "raw": "L-25B1WHS434  (RTK) LT2"
    },
    {
      "id": "btech_4_THU_6_vjbvem",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "SMA",
      "room": "CL4",
      "raw": "P-25B17CI476 24J12,24K11 (SMA) CL4"
    },
    {
      "id": "btech_4_THU_7_wnb5jv",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "SMA",
      "room": "CL4",
      "raw": "P-25B17CI476 24J12,24K11 (SMA) CL4"
    },
    {
      "id": "btech_4_THU_0_pblb1o",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CE411",
      "batches": [
        "24D11"
      ],
      "faculty": "CPG",
      "room": "CR13",
      "raw": "L-25B11CE411 24D11 (CPG) CR13"
    },
    {
      "id": "btech_4_THU_1_oy18v9",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "AVA",
      "room": "CR6",
      "raw": "L-25B11CI412 24J11,24J12,24K11 (AVA) CR6"
    },
    {
      "id": "btech_4_THU_2_tn8uzq",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CI411",
      "batches": [
        "24J11",
        "24J12",
        "24K11",
        "24I14"
      ],
      "faculty": "HST",
      "room": "CR10",
      "raw": "L-24B11CI411 24J11,24J12,24K11,24I14 (HST) CR10"
    },
    {
      "id": "btech_4_THU_3_ox20m7",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "AMN",
      "room": "LT2",
      "raw": "L-25B11CI413  24A110,24L11,24N11, 24I14,24C11,24P11,24F11 (AMN) LT2"
    },
    {
      "id": "btech_4_THU_6_eilh3i",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI417",
      "batches": [
        "24N11"
      ],
      "faculty": "PLK",
      "room": "TR3",
      "raw": "L-25B11CI417 24N11 (PLK) TR3"
    },
    {
      "id": "btech_4_THU_0_m1cm4d",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24J11",
        "24J12",
        "24K11",
        "24E11",
        "24F11"
      ],
      "faculty": "RKI",
      "room": "CR12",
      "raw": "L-25B11CI414 24J11,24J12,24K11,24E11,24F11 (RKI) CR12"
    },
    {
      "id": "btech_4_THU_1_0boe9j",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CE413",
      "batches": [
        "24D11"
      ],
      "faculty": "ADP",
      "room": "TR8",
      "raw": "L-24B11CE413 24D11 (ADP) TR8"
    },
    {
      "id": "btech_4_THU_6_q2hr94",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24I11"
      ],
      "faculty": "VNS",
      "room": "CL8_1",
      "raw": "P-25B17CI473 24I11 (VNS) CL8_1"
    },
    {
      "id": "btech_4_THU_7_csd73v",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24I11"
      ],
      "faculty": "VNS",
      "room": "CL8_1",
      "raw": "P-25B17CI473 24I11 (VNS) CL8_1"
    },
    {
      "id": "btech_4_THU_1_yyy1no",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "B2[24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "AYS",
      "room": "CR10",
      "raw": "L-25B1WCI431 B2[24A14,24A15,24A16]  (AYS) CR10"
    },
    {
      "id": "btech_4_THU_3_is09kj",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "24BB1HS412",
      "batches": [
        "24W11"
      ],
      "faculty": "TNS",
      "room": "TR5",
      "raw": "T-24BB1HS412 24W11 (TNS) TR5"
    },
    {
      "id": "btech_4_THU_5_evbo44",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "24BBWHS431",
      "batches": [
        "24W11"
      ],
      "faculty": "ASA",
      "room": "TR6",
      "raw": "L-24BBWHS431 24W11 (ASA) TR6"
    },
    {
      "id": "btech_4_THU_6_j14gcj",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11EC411",
      "batches": [
        "24B11",
        "24G11"
      ],
      "faculty": "ALK",
      "room": "CR11",
      "raw": "L-25B11EC411 24B11,24G11 (ALK) CR11"
    },
    {
      "id": "btech_4_THU_7_63ju2t",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A12"
      ],
      "faculty": "AKJ",
      "room": "TR6",
      "raw": "T-25B11CI412 24A12 (AKJ) TR6"
    },
    {
      "id": "btech_4_THU_0_nqmmmz",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "SWT",
      "room": "CR4",
      "raw": "L-25B11CI411 24I11,24I12,24I13 (SWT) CR4"
    },
    {
      "id": "btech_4_THU_1_mhr0gg",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "RKI",
      "room": "CR4",
      "raw": "L-25B11CI414 24I11,24I12,24I13 (RKI) CR4"
    },
    {
      "id": "btech_4_THU_2_m25erl",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "MNK",
      "room": "CR9",
      "raw": "L-25B11CI413 24A14,24A15,24A16 (MNK) CR9"
    },
    {
      "id": "btech_4_THU_3_rbboi5",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BT411",
      "batches": [
        "OTO"
      ],
      "faculty": "HSD",
      "room": "CABIN",
      "raw": "L-18B11BT411 OTO (HSD) CABIN"
    },
    {
      "id": "btech_4_THU_6_mkwu1z",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A14"
      ],
      "faculty": "MNK",
      "room": "CL6",
      "raw": "P-25B17CI473 24A14 (MNK) CL6"
    },
    {
      "id": "btech_4_THU_7_9v3z3q",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A14"
      ],
      "faculty": "MNK",
      "room": "CL6",
      "raw": "P-25B17CI473 24A14 (MNK) CL6"
    },
    {
      "id": "btech_4_THU_0_a26bu6",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WEC432",
      "batches": [
        "24B11",
        "24H11"
      ],
      "faculty": "NTJ",
      "room": "ECL6",
      "raw": "L-25B1WEC432 24B11,24H11 (NTJ) ECL6"
    },
    {
      "id": "btech_4_THU_1_nz36ht",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B1WCI435",
      "batches": [
        "24C11"
      ],
      "faculty": "PTK",
      "room": "TR6",
      "raw": "T-25B1WCI435 24C11 (PTK) TR6"
    },
    {
      "id": "btech_4_THU_2_a311ze",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "VNS",
      "room": "CR7",
      "raw": "L-25B11CI413 24I11,24I12,24I13 (VNS) CR7"
    },
    {
      "id": "btech_4_THU_6_hqozpo",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11BT414",
      "batches": [
        "24E11"
      ],
      "faculty": "RJK",
      "room": "TR2",
      "raw": "T-25B11BT414 24E11 (RJK) TR2"
    },
    {
      "id": "btech_4_THU_1_9c5tvh",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "PDG",
      "room": "CR5",
      "raw": "L-25B11CI411 24A110,24L11,24N11,24I14 (PDG) CR5"
    },
    {
      "id": "btech_4_THU_2_4ybdh2",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC473",
      "batches": [
        "24B11"
      ],
      "faculty": "PDG",
      "room": "CL1",
      "raw": "P-25B17EC473 24B11 (PDG) CL1"
    },
    {
      "id": "btech_4_THU_3_akeuoy",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC473",
      "batches": [
        "24B11"
      ],
      "faculty": "PDG",
      "room": "CL1",
      "raw": "P-25B17EC473 24B11 (PDG) CL1"
    },
    {
      "id": "btech_4_THU_6_rqp1cu",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "AKJ",
      "room": "CR7",
      "raw": "L-25B11CI412 24A11,24A12,24A13 (AKJ) CR7"
    },
    {
      "id": "btech_4_THU_7_0uc51x",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "RVS",
      "room": "CR10",
      "raw": "L-25B11CI412 24A17,24A18,24A19 (RVS) CR10"
    },
    {
      "id": "btech_4_THU_0_ip98dd",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24BB1HS411",
      "batches": [
        "24W11"
      ],
      "faculty": "ANU",
      "room": "CR19",
      "raw": "L-24BB1HS411 24W11 (ANU) CR19"
    },
    {
      "id": "btech_4_THU_1_kd1jiu",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC413",
      "batches": [
        "24B11",
        "24G11"
      ],
      "faculty": "VKB",
      "room": "CR17",
      "raw": "L-25B11EC413 24B11,24G11 (VKB) CR17"
    },
    {
      "id": "btech_4_THU_2_fialdb",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC474",
      "batches": [
        "24H11"
      ],
      "faculty": "RKU",
      "room": "ECL6",
      "raw": "P-25B17EC474 24H11 (RKU) ECL6"
    },
    {
      "id": "btech_4_THU_3_wxxv50",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC474",
      "batches": [
        "24H11"
      ],
      "faculty": "RKU",
      "room": "ECL6",
      "raw": "P-25B17EC474 24H11 (RKU) ECL6"
    },
    {
      "id": "btech_4_THU_6_7zx90h",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI418",
      "batches": [
        "24L11"
      ],
      "faculty": "GVN",
      "room": "CR19",
      "raw": "L-25B11CI418 24L11 (GVN) CR19"
    },
    {
      "id": "btech_4_THU_2_rmqlut",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "ALK",
      "room": "CR2",
      "raw": "L-25B11CI411 24A11,24A12,24A13 (ALK) CR2"
    },
    {
      "id": "btech_4_THU_3_ui62nh",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "RRA",
      "room": "CR10",
      "raw": "L-25B11GE411  24A17,24A18,24A19 (RRA) CR10"
    },
    {
      "id": "btech_4_THU_6_nb01xq",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI475/25BC7CI272",
      "batches": [
        "24H11",
        "25Q11"
      ],
      "faculty": "DBK",
      "room": "CL11",
      "raw": "P-25B17CI475/25BC7CI272 24H11,25Q11 (DBK) CL11"
    },
    {
      "id": "btech_4_THU_7_0asy3b",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI475/25BC7CI272",
      "batches": [
        "24H11",
        "25Q11"
      ],
      "faculty": "DBK",
      "room": "CL11",
      "raw": "P-25B17CI475/25BC7CI272 24H11,25Q11 (DBK) CL11"
    },
    {
      "id": "btech_4_THU_0_xzkdse",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A17"
      ],
      "faculty": "AMN",
      "room": "CL5_2",
      "raw": "P-25B17CI473 24A17 (AMN) CL5_2"
    },
    {
      "id": "btech_4_THU_1_tyeirg",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A17"
      ],
      "faculty": "AMN",
      "room": "CL5_2",
      "raw": "P-25B17CI473 24A17 (AMN) CL5_2"
    },
    {
      "id": "btech_4_THU_3_q5mgbk",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "PNS",
      "room": "CR8",
      "raw": "L-25B11GE411 24A14,24A15,24A16 (PNS) CR8"
    },
    {
      "id": "btech_4_THU_6_olsiqm",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24BB7HS471",
      "batches": [
        "24W11"
      ],
      "faculty": "NTJ",
      "room": "ECL8",
      "raw": "P-24BB7HS471 24W11 (NTJ) ECL8"
    },
    {
      "id": "btech_4_THU_7_qxtuyi",
      "semesterId": "btech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24BB7HS471",
      "batches": [
        "24W11"
      ],
      "faculty": "NTJ",
      "room": "ECL8",
      "raw": "P-24BB7HS471 24W11 (NTJ) ECL8"
    },
    {
      "id": "btech_4_FRI_2_djgl81",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A16"
      ],
      "faculty": "MNK",
      "room": "CL9_2",
      "raw": "P-25B17CI473 24A16 (MNK) CL9_2"
    },
    {
      "id": "btech_4_FRI_3_otyo0n",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A16"
      ],
      "faculty": "MNK",
      "room": "CL9_2",
      "raw": "P-25B17CI473 24A16 (MNK) CL9_2"
    },
    {
      "id": "btech_4_FRI_6_dp9okb",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A17"
      ],
      "faculty": "RVS",
      "room": "CL10",
      "raw": "P-25B17CI472 24A17 (RVS) CL10"
    },
    {
      "id": "btech_4_FRI_7_mggker",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A17"
      ],
      "faculty": "RVS",
      "room": "CL10",
      "raw": "P-25B17CI472 24A17 (RVS) CL10"
    },
    {
      "id": "btech_4_FRI_0_8vqu4r",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24I13"
      ],
      "faculty": "NSA",
      "room": "CL3_1",
      "raw": "P-25B17CI476 24I13 (NSA) CL3_1"
    },
    {
      "id": "btech_4_FRI_1_g2xzmg",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24I13"
      ],
      "faculty": "NSA",
      "room": "CL3_1",
      "raw": "P-25B17CI476 24I13 (NSA) CL3_1"
    },
    {
      "id": "btech_4_FRI_2_dhlhmi",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A13"
      ],
      "faculty": "SRU",
      "room": "ECL3",
      "raw": "P-25B17CI471 24A13 (SRU) ECL3"
    },
    {
      "id": "btech_4_FRI_3_nslpmh",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A13"
      ],
      "faculty": "SRU",
      "room": "ECL3",
      "raw": "P-25B17CI471 24A13 (SRU) ECL3"
    },
    {
      "id": "btech_4_FRI_0_he4tjq",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "RVS",
      "room": "CR6",
      "raw": "L-25B11CI412 24A17,24A18,24A19 (RVS) CR6"
    },
    {
      "id": "btech_4_FRI_1_kmcw6c",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "24BB1HS413",
      "batches": [
        "24W11"
      ],
      "faculty": "TGM",
      "room": "TR6",
      "raw": "T-24BB1HS413 24W11 (TGM) TR6"
    },
    {
      "id": "btech_4_FRI_2_u9f2ol",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A11",
        "24H11"
      ],
      "faculty": "PDN",
      "room": "CL5_1",
      "raw": "P-25B17CI476 24A11,24H11 (PDN) CL5_1"
    },
    {
      "id": "btech_4_FRI_3_ye0frx",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A11",
        "24H11"
      ],
      "faculty": "PDN",
      "room": "CL5_1",
      "raw": "P-25B17CI476 24A11,24H11 (PDN) CL5_1"
    },
    {
      "id": "btech_4_FRI_5_c5xe80",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT412",
      "batches": [
        "24E11"
      ],
      "faculty": "AKN",
      "room": "CR17",
      "raw": "L-25B11BT412 24E11 (AKN) CR17"
    },
    {
      "id": "btech_4_FRI_6_1dcdgl",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11EC411",
      "batches": [
        "24B11",
        "24G11"
      ],
      "faculty": "ALK",
      "room": "TR6",
      "raw": "T-25B11EC411 24B11,24G11 (ALK) TR6"
    },
    {
      "id": "btech_4_FRI_7_z1dtqa",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "TYN",
      "room": "LT3",
      "raw": "L-25B11GE411 24A11,24A12,24A13 (TYN) LT3"
    },
    {
      "id": "btech_4_FRI_0_xm8e99",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC412",
      "batches": [
        "24B11",
        "24G11",
        "24H11"
      ],
      "faculty": "PRG",
      "room": "TR2",
      "raw": "L-25B11EC412 24B11,24G11,24H11 (PRG) TR2"
    },
    {
      "id": "btech_4_FRI_1_jfsj88",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI418",
      "batches": [
        "24L11"
      ],
      "faculty": "GVN",
      "room": "CR19",
      "raw": "L-25B11CI418 24L11 (GVN) CR19"
    },
    {
      "id": "btech_4_FRI_2_hg7evw",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B22[24A15"
      ],
      "faculty": "SSA",
      "room": "CL9_1",
      "raw": "P-25B1WCI471 B22[24A15] (SSA) CL9_1"
    },
    {
      "id": "btech_4_FRI_3_1llwlt",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B22[24A15"
      ],
      "faculty": "SSA",
      "room": "CL9_1",
      "raw": "P-25B1WCI471 B22[24A15] (SSA) CL9_1"
    },
    {
      "id": "btech_4_FRI_5_f53bzz",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "AKR",
      "room": "CR1",
      "raw": "L-25B11CI414 24A17,24A18,24A19 (AKR) CR1"
    },
    {
      "id": "btech_4_FRI_7_k2vmfr",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "PNS",
      "room": "CR2",
      "raw": "L-25B11GE411 24A14,24A15,24A16 (PNS) CR2"
    },
    {
      "id": "btech_4_FRI_0_ykveh7",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CE414",
      "batches": [
        "24D11"
      ],
      "faculty": "KKR",
      "room": "TR8",
      "raw": "L-24B11CE414 24D11 (KKR) TR8"
    },
    {
      "id": "btech_4_FRI_1_aiwkht",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "EMP",
      "room": "CR7",
      "raw": "L-25B11CI411 24A14,24A15,24A16 (EMP) CR7"
    },
    {
      "id": "btech_4_FRI_2_opcelc",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A18"
      ],
      "faculty": "RVS",
      "room": "CL8_1",
      "raw": "P-25B17CI472 24A18 (RVS) CL8_1"
    },
    {
      "id": "btech_4_FRI_3_mwbr73",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A18"
      ],
      "faculty": "RVS",
      "room": "CL8_1",
      "raw": "P-25B17CI472 24A18 (RVS) CL8_1"
    },
    {
      "id": "btech_4_FRI_4_yxmuwu",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI473",
      "batches": [
        "B63[24I11",
        "24I12",
        "24I13",
        "24J11",
        "24J12"
      ],
      "faculty": "AYS",
      "room": "ECL7",
      "raw": "P-25B1WCI473 B63[24I11,24I12,24I13,24J11,24J12] (AYS) ECL7"
    },
    {
      "id": "btech_4_FRI_5_c07edn",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI473",
      "batches": [
        "B63[24I11",
        "24I12",
        "24I13",
        "24J11",
        "24J12"
      ],
      "faculty": "AYS",
      "room": "ECL7",
      "raw": "P-25B1WCI473 B63[24I11,24I12,24I13,24J11,24J12] (AYS) ECL7"
    },
    {
      "id": "btech_4_FRI_6_0j77lo",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "24B11CI416",
      "batches": [
        "24H11"
      ],
      "faculty": "EMP",
      "room": "ECL8,TR4",
      "raw": "L-24B11CI416 24H11 (EMP) ECL8,TR4"
    },
    {
      "id": "btech_4_FRI_7_yr8ew1",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WEC432",
      "batches": [
        "24B11",
        "24H11"
      ],
      "faculty": "NTJ",
      "room": "ECL6",
      "raw": "L-25B1WEC432 24B11,24H11 (NTJ) ECL6"
    },
    {
      "id": "btech_4_FRI_8_3v0y7e",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI379",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "RKI",
      "room": "CR8",
      "raw": "P-25B17CI379 24E11,24F11 (RKI) CR8"
    },
    {
      "id": "btech_4_FRI_0_8t6wta",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "MNK",
      "room": "DLC,CR10",
      "raw": "L-25B11CI413 24A14,24A15,24A16 (MNK) DLC,CR10"
    },
    {
      "id": "btech_4_FRI_1_6nf8do",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11EC413",
      "batches": [
        "24B11",
        "24G11"
      ],
      "faculty": "VKB",
      "room": "TR5",
      "raw": "T-25B11EC413 24B11,24G11 (VKB) TR5"
    },
    {
      "id": "btech_4_FRI_2_ti0dir",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B31[24A17"
      ],
      "faculty": "ATA",
      "room": "CL10",
      "raw": "P-25B1WCI471 B31[24A17] (ATA) CL10"
    },
    {
      "id": "btech_4_FRI_3_h7suhg",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B31[24A17"
      ],
      "faculty": "ATA",
      "room": "CL10",
      "raw": "P-25B1WCI471 B31[24A17] (ATA) CL10"
    },
    {
      "id": "btech_4_FRI_6_7joe8q",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT474",
      "batches": [
        "24E11"
      ],
      "faculty": "RJK",
      "room": "BIL",
      "raw": "P-25B17BT474 24E11 (RJK) BIL"
    },
    {
      "id": "btech_4_FRI_7_jtobjv",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT474",
      "batches": [
        "24E11"
      ],
      "faculty": "RJK",
      "room": "BIL",
      "raw": "P-25B17BT474 24E11 (RJK) BIL"
    },
    {
      "id": "btech_4_FRI_0_l7xz45",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "SRJ",
      "room": "LT3",
      "raw": "L-25B11CI414 24A11,24A12,24A13 (SRJ) LT3"
    },
    {
      "id": "btech_4_FRI_1_jmni8x",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CE411",
      "batches": [
        "24D11"
      ],
      "faculty": "AKG",
      "room": "CR15",
      "raw": "L-18B11CE411 24D11 (AKG) CR15"
    },
    {
      "id": "btech_4_FRI_2_menumf",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "KLK",
      "room": "CL3_2",
      "raw": "P-25B17CI476 24L11,24N11,24I14 (KLK) CL3_2"
    },
    {
      "id": "btech_4_FRI_3_6tpr74",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "KLK",
      "room": "CL3_2",
      "raw": "P-25B17CI476 24L11,24N11,24I14 (KLK) CL3_2"
    },
    {
      "id": "btech_4_FRI_5_ebmjgo",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "B5[24I11",
        "24I12",
        "24I13",
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "RVS",
      "room": "LT3",
      "raw": "L-25B1WCI431 B5[24I11,24I12,24I13,24J11,24J12,24K11]  (RVS) LT3"
    },
    {
      "id": "btech_4_FRI_6_oe152f",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A110"
      ],
      "faculty": "PDN",
      "room": "CL3_2",
      "raw": "P-25B17CI476 24A110 (PDN) CL3_2"
    },
    {
      "id": "btech_4_FRI_7_7ddp8y",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A110"
      ],
      "faculty": "PDN",
      "room": "CL3_2",
      "raw": "P-25B17CI476 24A110 (PDN) CL3_2"
    },
    {
      "id": "btech_4_FRI_0_siqnoi",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "AVA",
      "room": "CR8",
      "raw": "L-25B11CI412 24J11,24J12,24K11 (AVA) CR8"
    },
    {
      "id": "btech_4_FRI_1_4oeojh",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11EC414",
      "batches": [
        "24H11"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "L-25B11EC414 24H11 (RKU) TR4"
    },
    {
      "id": "btech_4_FRI_2_ji78i3",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "VNS",
      "room": "CR8",
      "raw": "L-25B11CI413 24J11,24J12,24K11 (VNS) CR8"
    },
    {
      "id": "btech_4_FRI_3_rrzf6v",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "24B11CE412",
      "batches": [
        "24D11"
      ],
      "faculty": "ABJ",
      "room": "TR9",
      "raw": "L-24B11CE412 24D11 (ABJ) TR9"
    },
    {
      "id": "btech_4_FRI_6_27gtt6",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A11"
      ],
      "faculty": "AKJ",
      "room": "TR1",
      "raw": "T-25B11CI412 24A11 (AKJ) TR1"
    },
    {
      "id": "btech_4_FRI_8_cinh1n",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS432",
      "batches": [],
      "faculty": "DLR",
      "room": "LT3",
      "raw": "L-25B1WHS432  (DLR) LT3"
    },
    {
      "id": "btech_4_FRI_0_qppijg",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "24BB1HS411",
      "batches": [
        "24W11"
      ],
      "faculty": "ANU",
      "room": "TR7",
      "raw": "T-24BB1HS411 24W11 (ANU) TR7"
    },
    {
      "id": "btech_4_FRI_2_mj9jaw",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24BB1HS414",
      "batches": [
        "24W11"
      ],
      "faculty": "DLR",
      "room": "TR7",
      "raw": "L-24BB1HS414 24W11 (DLR) TR7"
    },
    {
      "id": "btech_4_FRI_6_bebxni",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "AMN",
      "room": "CL5_2",
      "raw": "P-25B17CI473 24L11,24N11,24I14 (AMN) CL5_2"
    },
    {
      "id": "btech_4_FRI_7_6qs31w",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "AMN",
      "room": "CL5_2",
      "raw": "P-25B17CI473 24L11,24N11,24I14 (AMN) CL5_2"
    },
    {
      "id": "btech_4_FRI_8_73zl1m",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS433",
      "batches": [],
      "faculty": "NJL",
      "room": "CR5",
      "raw": "L-25B1WHS433  (NJL) CR5"
    },
    {
      "id": "btech_4_FRI_1_ki7udt",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CI411",
      "batches": [
        "24J11",
        "24J12",
        "24K11",
        "24I14"
      ],
      "faculty": "HST",
      "room": "CR4",
      "raw": "L-24B11CI411 24J11,24J12,24K11,24I14 (HST) CR4"
    },
    {
      "id": "btech_4_FRI_2_0xrwwe",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A14",
        "24B11"
      ],
      "faculty": "PKG",
      "room": "CL4",
      "raw": "P-25B17CI476 24A14,24B11 (PKG) CL4"
    },
    {
      "id": "btech_4_FRI_3_adw13k",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A14",
        "24B11"
      ],
      "faculty": "PKG",
      "room": "CL4",
      "raw": "P-25B17CI476 24A14,24B11 (PKG) CL4"
    },
    {
      "id": "btech_4_FRI_5_yxxsb2",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11EC416",
      "batches": [
        "24B11"
      ],
      "faculty": "PDG",
      "room": "TR3",
      "raw": "L-25B11EC416 24B11 (PDG) TR3"
    },
    {
      "id": "btech_4_FRI_6_uyabgx",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B52[24I12",
        "24K11"
      ],
      "faculty": "ATA",
      "room": "CL6",
      "raw": "P-25B1WCI471 B52[24I12,24K11] (ATA) CL6"
    },
    {
      "id": "btech_4_FRI_7_xzcbk7",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B52[24I12",
        "24K11"
      ],
      "faculty": "ATA",
      "room": "CL6",
      "raw": "P-25B1WCI471 B52[24I12,24K11] (ATA) CL6"
    },
    {
      "id": "btech_4_FRI_8_hmhwbq",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WHS434",
      "batches": [],
      "faculty": "RTK",
      "room": "LT2",
      "raw": "L-25B1WHS434  (RTK) LT2"
    },
    {
      "id": "btech_4_FRI_0_214ezj",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24C11",
        "24P11"
      ],
      "faculty": "SKP",
      "room": "CL3_2",
      "raw": "P-25B17CI476 24C11,24P11 (SKP) CL3_2"
    },
    {
      "id": "btech_4_FRI_1_yvaplv",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24C11",
        "24P11"
      ],
      "faculty": "SKP",
      "room": "CL3_2",
      "raw": "P-25B17CI476 24C11,24P11 (SKP) CL3_2"
    },
    {
      "id": "btech_4_FRI_2_frlv71",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B43[24C11",
        "24F11"
      ],
      "faculty": "GVN",
      "room": "CL6",
      "raw": "P-25B1WCI471 B43[24C11,24F11] (GVN) CL6"
    },
    {
      "id": "btech_4_FRI_3_01i0hy",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B43[24C11",
        "24F11"
      ],
      "faculty": "GVN",
      "room": "CL6",
      "raw": "P-25B1WCI471 B43[24C11,24F11] (GVN) CL6"
    },
    {
      "id": "btech_4_FRI_1_spbyeb",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A17",
        "24A18",
        "24A19"
      ],
      "faculty": "NTJ",
      "room": "LT3",
      "raw": "L-25B11CI411 24A17,24A18,24A19 (NTJ) LT3"
    },
    {
      "id": "btech_4_FRI_2_4vo9ko",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A110"
      ],
      "faculty": "PDG",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A110 (PDG) ECL4"
    },
    {
      "id": "btech_4_FRI_3_a4lnh8",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A110"
      ],
      "faculty": "PDG",
      "room": "ECL4",
      "raw": "P-25B17CI471 24A110 (PDG) ECL4"
    },
    {
      "id": "btech_4_FRI_6_5bygg8",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "ARV",
      "room": "CR2",
      "raw": "L-25B11CI412 24A14,24A15,24A16 (ARV) CR2"
    },
    {
      "id": "btech_4_FRI_0_9o5d4q",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "18BIWBT631",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "GPL",
      "room": "CR12",
      "raw": "T-18BIWBT631 24E11,24F11 (GPL) CR12"
    },
    {
      "id": "btech_4_FRI_1_qaigx0",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI431",
      "batches": [
        "24A11",
        "24A12",
        "24A13",
        "24E11",
        "24F11"
      ],
      "faculty": "ATA",
      "room": "CR10",
      "raw": "L-25B1WCI431 24A11,24A12,24A13,24E11,24F11 (ATA) CR10"
    },
    {
      "id": "btech_4_FRI_2_982qjy",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT473",
      "batches": [
        "24E11"
      ],
      "faculty": "TYN",
      "room": "BIOCHEM",
      "raw": "P-25B17BT473 24E11 (TYN) BIOCHEM"
    },
    {
      "id": "btech_4_FRI_3_or1b41",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17BT473",
      "batches": [
        "24E11"
      ],
      "faculty": "ABH",
      "room": "BIOCHEM",
      "raw": "P-25B17BT473 24E11 (ABH) BIOCHEM"
    },
    {
      "id": "btech_4_FRI_6_3wz9nn",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24I13"
      ],
      "faculty": "VNS",
      "room": "CL1",
      "raw": "P-25B17CI473 24I13 (VNS) CL1"
    },
    {
      "id": "btech_4_FRI_7_suxx4q",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24I13"
      ],
      "faculty": "VNS",
      "room": "CL1",
      "raw": "P-25B17CI473 24I13 (VNS) CL1"
    },
    {
      "id": "btech_4_FRI_0_xl8qfe",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24I12"
      ],
      "faculty": "VNS",
      "room": "CL8_1",
      "raw": "P-25B17CI473 24I12 (VNS) CL8_1"
    },
    {
      "id": "btech_4_FRI_1_we9eb7",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24I12"
      ],
      "faculty": "VNS",
      "room": "CL8_1",
      "raw": "P-25B17CI473 24I12 (VNS) CL8_1"
    },
    {
      "id": "btech_4_FRI_2_6tgdfk",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A12"
      ],
      "faculty": "AKJ",
      "room": "CL3_1",
      "raw": "P-25B17CI472 24A12 (AKJ) CL3_1"
    },
    {
      "id": "btech_4_FRI_3_wm4zws",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A12"
      ],
      "faculty": "AKJ",
      "room": "CL3_1",
      "raw": "P-25B17CI472 24A12 (AKJ) CL3_1"
    },
    {
      "id": "btech_4_FRI_5_7svzyi",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CI412",
      "batches": [
        "24A110",
        "24L11",
        "24N11",
        "24I14",
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "SKS",
      "room": "CR10",
      "raw": "L-25B11CI412 24A110,24L11,24N11,24I14,24C11,24P11,24F11 (SKS) CR10"
    },
    {
      "id": "btech_4_FRI_6_qlyect",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "SKS",
      "room": "CL9_1",
      "raw": "P-25B17CI472 24C11,24P11,24F11 (SKS) CL9_1"
    },
    {
      "id": "btech_4_FRI_7_cz7gao",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24C11",
        "24P11",
        "24F11"
      ],
      "faculty": "SKS",
      "room": "CL9_1",
      "raw": "P-25B17CI472 24C11,24P11,24F11 (SKS) CL9_1"
    },
    {
      "id": "btech_4_FRI_0_m9q709",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI477",
      "batches": [
        "24N11"
      ],
      "faculty": "PLK",
      "room": "CL5_2",
      "raw": "P-25B17CI477 24N11 (PLK) CL5_2"
    },
    {
      "id": "btech_4_FRI_1_mis1td",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI477",
      "batches": [
        "24N11"
      ],
      "faculty": "PLK",
      "room": "CL5_2",
      "raw": "P-25B17CI477 24N11 (PLK) CL5_2"
    },
    {
      "id": "btech_4_FRI_2_vllyg8",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11GE411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "PNS",
      "room": "CR2",
      "raw": "L-25B11GE411 24I11,24I12,24I13 (PNS) CR2"
    },
    {
      "id": "btech_4_FRI_6_axq1q6",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24I11"
      ],
      "faculty": "AVA",
      "room": "CL11",
      "raw": "P-25B17CI472 24I11 (AVA) CL11"
    },
    {
      "id": "btech_4_FRI_7_76p22e",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24I11"
      ],
      "faculty": "AVA",
      "room": "CL11",
      "raw": "P-25B17CI472 24I11 (AVA) CL11"
    },
    {
      "id": "btech_4_FRI_2_6ex8m1",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A19"
      ],
      "faculty": "AMN",
      "room": "CL8_2",
      "raw": "P-25B17CI473 24A19 (AMN) CL8_2"
    },
    {
      "id": "btech_4_FRI_3_m63swz",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A19"
      ],
      "faculty": "AMN",
      "room": "CL8_2",
      "raw": "P-25B17CI473 24A19 (AMN) CL8_2"
    },
    {
      "id": "btech_4_FRI_6_uo1ihq",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24J11"
      ],
      "faculty": "MNK",
      "room": "CL9_2",
      "raw": "P-24B17CI471 24J11 (MNK) CL9_2"
    },
    {
      "id": "btech_4_FRI_7_tggbt9",
      "semesterId": "btech_4",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24J11"
      ],
      "faculty": "MNK",
      "room": "CL9_2",
      "raw": "P-24B17CI471 24J11 (MNK) CL9_2"
    },
    {
      "id": "btech_4_SAT_0_wecm9t",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A18"
      ],
      "faculty": "MNK",
      "room": "CL5_1",
      "raw": "P-25B17CI476 24A18 (MNK) CL5_1"
    },
    {
      "id": "btech_4_SAT_1_vl5wlc",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI476",
      "batches": [
        "24A18"
      ],
      "faculty": "MNK",
      "room": "CL5_1",
      "raw": "P-25B17CI476 24A18 (MNK) CL5_1"
    },
    {
      "id": "btech_4_SAT_2_n5qqfj",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A19"
      ],
      "faculty": "RVS",
      "room": "CL9_2",
      "raw": "P-25B17CI472 24A19 (RVS) CL9_2"
    },
    {
      "id": "btech_4_SAT_3_2xpqsf",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A19"
      ],
      "faculty": "RVS",
      "room": "CL9_2",
      "raw": "P-25B17CI472 24A19 (RVS) CL9_2"
    },
    {
      "id": "btech_4_SAT_2_wre1tf",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B32[24A18"
      ],
      "faculty": "ATA",
      "room": "CL8_1",
      "raw": "P-25B1WCI471 B32[24A18] (ATA) CL8_1"
    },
    {
      "id": "btech_4_SAT_3_y6q701",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B32[24A18"
      ],
      "faculty": "ATA",
      "room": "CL8_1",
      "raw": "P-25B1WCI471 B32[24A18] (ATA) CL8_1"
    },
    {
      "id": "btech_4_SAT_2_pyuj7z",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI478",
      "batches": [
        "24L11"
      ],
      "faculty": "GVN",
      "room": "CL3_1",
      "raw": "P-25B17CI478 24L11 (GVN) CL3_1"
    },
    {
      "id": "btech_4_SAT_3_2m5aab",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI478",
      "batches": [
        "24L11"
      ],
      "faculty": "GVN",
      "room": "CL3_1",
      "raw": "P-25B17CI478 24L11 (GVN) CL3_1"
    },
    {
      "id": "btech_4_SAT_0_7x2ht3",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B42[24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "AYS",
      "room": "CL9_1",
      "raw": "P-25B1WCI471 B42[24L11,24N11,24I14] (AYS) CL9_1"
    },
    {
      "id": "btech_4_SAT_1_eewxdd",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B42[24L11",
        "24N11",
        "24I14"
      ],
      "faculty": "AYS",
      "room": "CL9_1",
      "raw": "P-25B1WCI471 B42[24L11,24N11,24I14] (AYS) CL9_1"
    },
    {
      "id": "btech_4_SAT_2_eyufhi",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WEC431",
      "batches": [
        "24B11",
        "24H11"
      ],
      "faculty": "VKB",
      "room": "TR6",
      "raw": "L-25B1WEC431 24B11,24H11 (VKB) TR6"
    },
    {
      "id": "btech_4_SAT_3_5qg600",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11BT411",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "SML",
      "room": "TR7",
      "raw": "L-25B11BT411 24E11, 24F11  (SML) TR7"
    },
    {
      "id": "btech_4_SAT_1_zvcp5l",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A16"
      ],
      "faculty": "ARV",
      "room": "TR2",
      "raw": "T-25B11CI412 24A16 (ARV) TR2"
    },
    {
      "id": "btech_4_SAT_2_l07qms",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI417",
      "batches": [
        "24N11"
      ],
      "faculty": "PLK",
      "room": "TR5",
      "raw": "L-25B11CI417 24N11 (PLK) TR5"
    },
    {
      "id": "btech_4_SAT_3_31wdo6",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A15"
      ],
      "faculty": "ARV",
      "room": "TR1",
      "raw": "T-25B11CI412 24A15 (ARV) TR1"
    },
    {
      "id": "btech_4_SAT_0_fj4tr8",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11CI411",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "HST",
      "room": "LT3",
      "raw": "L-24B11CI411 24I11,24I12,24I13 (HST) LT3"
    },
    {
      "id": "btech_4_SAT_1_37rgar",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24A13"
      ],
      "faculty": "AKJ",
      "room": "TR3",
      "raw": "T-25B11CI412 24A13 (AKJ) TR3"
    },
    {
      "id": "btech_4_SAT_2_3akell",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A13"
      ],
      "faculty": "RBT",
      "room": "CL5_1",
      "raw": "P-25B17CI473 24A13 (RBT) CL5_1"
    },
    {
      "id": "btech_4_SAT_3_c2oeg3",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI473",
      "batches": [
        "24A13"
      ],
      "faculty": "RBT",
      "room": "CL5_1",
      "raw": "P-25B17CI473 24A13 (RBT) CL5_1"
    },
    {
      "id": "btech_4_SAT_2_c2qf2x",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11BT411",
      "batches": [
        "OTO"
      ],
      "faculty": "UDB",
      "room": "CABIN",
      "raw": "L-18B11BT411 OTO (UDB) CABIN"
    },
    {
      "id": "btech_4_SAT_3_w82wi2",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BT411",
      "batches": [
        "OTO"
      ],
      "faculty": "UDB",
      "room": "CABIN",
      "raw": "L-18B11BT411 OTO (UDB) CABIN"
    },
    {
      "id": "btech_4_SAT_0_2d3opz",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11GE411",
      "batches": [
        "24J11",
        "24J12",
        "24K11"
      ],
      "faculty": "RRA",
      "room": "CR1",
      "raw": "L-24B11GE411 24J11,24J12,24K11 (RRA) CR1"
    },
    {
      "id": "btech_4_SAT_1_hvnpyo",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI413",
      "batches": [
        "24I11",
        "24I12",
        "24I13"
      ],
      "faculty": "VNS",
      "room": "DLC,CR2",
      "raw": "L-25B11CI413 24I11,24I12,24I13 (VNS) DLC,CR2"
    },
    {
      "id": "btech_4_SAT_2_730w90",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24I13",
        "24I14"
      ],
      "faculty": "MNK",
      "room": "CL6",
      "raw": "P-24B17CI471 24I13,24I14 (MNK) CL6"
    },
    {
      "id": "btech_4_SAT_3_tzzrz5",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24I13",
        "24I14"
      ],
      "faculty": "MNK",
      "room": "CL6",
      "raw": "P-24B17CI471 24I13,24I14 (MNK) CL6"
    },
    {
      "id": "btech_4_SAT_1_nevob8",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI435",
      "batches": [
        "24C11"
      ],
      "faculty": "PTK",
      "room": "CR18",
      "raw": "L-25B1WCI435 24C11 (PTK) CR18"
    },
    {
      "id": "btech_4_SAT_2_alu06i",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24I12"
      ],
      "faculty": "AVA",
      "room": "CR16",
      "raw": "T-25B11CI412 24I12 (AVA) CR16"
    },
    {
      "id": "btech_4_SAT_0_t4u6jk",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A110"
      ],
      "faculty": "SKS",
      "room": "CL9_2",
      "raw": "P-25B17CI472 24A110 (SKS) CL9_2"
    },
    {
      "id": "btech_4_SAT_1_nw6mla",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI472",
      "batches": [
        "24A110"
      ],
      "faculty": "SKS",
      "room": "CL9_2",
      "raw": "P-25B17CI472 24A110 (SKS) CL9_2"
    },
    {
      "id": "btech_4_SAT_2_agloxb",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A16"
      ],
      "faculty": "EMP",
      "room": "ECL5",
      "raw": "P-25B17CI471 24A16 (EMP) ECL5"
    },
    {
      "id": "btech_4_SAT_3_h0meeo",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24A16"
      ],
      "faculty": "EMP",
      "room": "ECL5",
      "raw": "P-25B17CI471 24A16 (EMP) ECL5"
    },
    {
      "id": "btech_4_SAT_0_rl39tl",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A14",
        "24A15",
        "24A16"
      ],
      "faculty": "EMP",
      "room": "CR2",
      "raw": "L-25B11CI411 24A14,24A15,24A16 (EMP) CR2"
    },
    {
      "id": "btech_4_SAT_1_yorm7t",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WBT432",
      "batches": [
        "24E11"
      ],
      "faculty": "UDB",
      "room": "TR6",
      "raw": "L-25B1WBT432 24E11 (UDB) TR6"
    },
    {
      "id": "btech_4_SAT_2_sw5wu5",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "MSD",
      "room": "ECL3",
      "raw": "P-25B17CI471 24J12,24K11 (MSD) ECL3"
    },
    {
      "id": "btech_4_SAT_3_yo47kg",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI471",
      "batches": [
        "24J12",
        "24K11"
      ],
      "faculty": "MSD",
      "room": "ECL3",
      "raw": "P-25B17CI471 24J12,24K11 (MSD) ECL3"
    },
    {
      "id": "btech_4_SAT_0_4sehtq",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBT631",
      "batches": [
        "24E11",
        "24F11"
      ],
      "faculty": "GPL",
      "room": "CR12",
      "raw": "L-18B1WBT631 24E11,24F11 (GPL) CR12"
    },
    {
      "id": "btech_4_SAT_3_oi95b8",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B11EC416",
      "batches": [
        "24B11"
      ],
      "faculty": "PDG",
      "room": "TR6",
      "raw": "L-25B11EC416 24B11 (PDG) TR6"
    },
    {
      "id": "btech_4_SAT_1_ejxv8q",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI414",
      "batches": [
        "24J11",
        "24J12",
        "24K11",
        "24E11",
        "24F11"
      ],
      "faculty": "RKI",
      "room": "CR5",
      "raw": "L-25B11CI414 24J11,24J12,24K11,24E11,24F11 (RKI) CR5"
    },
    {
      "id": "btech_4_SAT_2_oz3zy7",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "25B11BT415",
      "batches": [
        "24E11"
      ],
      "faculty": "JTV",
      "room": "TR2",
      "raw": "T-25B11BT415 24E11 (JTV) TR2"
    },
    {
      "id": "btech_4_SAT_3_ea5mhw",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CI412",
      "batches": [
        "24J11"
      ],
      "faculty": "AVA",
      "room": "TR4",
      "raw": "T-25B11CI412 24J11 (AVA) TR4"
    },
    {
      "id": "btech_4_SAT_0_dwqhok",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25B11CI411",
      "batches": [
        "24A11",
        "24A12",
        "24A13"
      ],
      "faculty": "ALK",
      "room": "CR5",
      "raw": "L-25B11CI411 24A11,24A12,24A13 (ALK) CR5"
    },
    {
      "id": "btech_4_SAT_1_ncle8v",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25BIICI412",
      "batches": [
        "24A19"
      ],
      "faculty": "RVS",
      "room": "CR16",
      "raw": "T-25BIICI412 24A19 (RVS) CR16"
    },
    {
      "id": "btech_4_SAT_2_hw2ask",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI376",
      "batches": [
        "24C11"
      ],
      "faculty": "AKR",
      "room": "CL7",
      "raw": "P-25B17CI376 24C11 (AKR) CL7"
    },
    {
      "id": "btech_4_SAT_3_aeok75",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B17CI376",
      "batches": [
        "24C11"
      ],
      "faculty": "AKR",
      "room": "CL7",
      "raw": "P-25B17CI376 24C11 (AKR) CL7"
    },
    {
      "id": "btech_4_SAT_2_j7o6l1",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24I11"
      ],
      "faculty": "RKI",
      "room": "CL8_2",
      "raw": "P-24B17CI471 24I11 (RKI) CL8_2"
    },
    {
      "id": "btech_4_SAT_3_qdovon",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI471",
      "batches": [
        "24I11"
      ],
      "faculty": "RKI",
      "room": "CL8_2",
      "raw": "P-24B17CI471 24I11 (RKI) CL8_2"
    },
    {
      "id": "btech_4_SAT_0_osjdcm",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC472",
      "batches": [
        "24B11",
        "24G11",
        "24H11"
      ],
      "faculty": "PRG",
      "room": "ECL3",
      "raw": "P-25B17EC472 24B11,24G11,24H11 (PRG) ECL3"
    },
    {
      "id": "btech_4_SAT_1_mql6vy",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B17EC472",
      "batches": [
        "24B11",
        "24G11",
        "24H11"
      ],
      "faculty": "PRG",
      "room": "ECL3",
      "raw": "P-25B17EC472 24B11,24G11,24H11 (PRG) ECL3"
    },
    {
      "id": "btech_4_SAT_2_88b15i",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B41[24A110"
      ],
      "faculty": "AYS",
      "room": "CL5_2",
      "raw": "P-25B1WCI471 B41[24A110] (AYS) CL5_2"
    },
    {
      "id": "btech_4_SAT_3_9u0uns",
      "semesterId": "btech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B1WCI471",
      "batches": [
        "B41[24A110"
      ],
      "faculty": "AYS",
      "room": "CL5_2",
      "raw": "P-25B1WCI471 B41[24A110] (AYS) CL5_2"
    },
    {
      "id": "btech_6_MON_2_r976e9",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "HRI",
      "room": "CR9",
      "raw": "L-18B11CI611 23A11,23A12,23A13 (HRI) CR9"
    },
    {
      "id": "btech_6_MON_3_1hp3eg",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25BBWHS632",
      "batches": [
        "23W11"
      ],
      "faculty": "ANU",
      "room": "TR3",
      "raw": "T-25BBWHS632 23W11 (ANU) TR3"
    },
    {
      "id": "btech_6_MON_6_5zkvhu",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBT632",
      "batches": [
        "23E11",
        "23F11"
      ],
      "faculty": "RST",
      "room": "TR6",
      "raw": "L-18B1WBT632 23E11,23F11  (RST) TR6"
    },
    {
      "id": "btech_6_MON_1_eh72aw",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI634",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "KLK",
      "room": "CR9",
      "raw": "L-18B1WCI634 23A14,23A15,23A16 (KLK) CR9"
    },
    {
      "id": "btech_6_MON_3_jrarvk",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "PKR",
      "room": "CR10",
      "raw": "L-18B11CI612 23A11,23A12,23A13 (PKR) CR10"
    },
    {
      "id": "btech_6_MON_6_y767gj",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A13"
      ],
      "faculty": "HRI",
      "room": "CL11",
      "raw": "P-18B17CI671  23A13 (HRI) CL11"
    },
    {
      "id": "btech_6_MON_7_7o5pix",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A13"
      ],
      "faculty": "HRI",
      "room": "CL11",
      "raw": "P-18B17CI671 23A13 (HRI) CL11"
    },
    {
      "id": "btech_6_MON_2_ugktx8",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11EC612",
      "batches": [
        "23B11"
      ],
      "faculty": "SHR",
      "room": "ECL3",
      "raw": "L-18B11EC612 23B11 (SHR) ECL3"
    },
    {
      "id": "btech_6_MON_5_74pl0h",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCI634",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "KLK",
      "room": "CR10",
      "raw": "L-18B1WCI634 23A11,23A12,23A13 (KLK) CR10"
    },
    {
      "id": "btech_6_MON_6_kpuxxs",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "23B11CE612",
      "batches": [
        "23D11"
      ],
      "faculty": "KKR",
      "room": "CR15",
      "raw": "L-23B11CE612 23D11 (KKR) CR15"
    },
    {
      "id": "btech_6_MON_1_gludur",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI635/",
      "batches": [
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "23BM11"
      ],
      "faculty": "MGN",
      "room": "LT2",
      "raw": "L-18B1WCI635/ 23I11,23I12,23J11,23J12,23K11, 23BM11 (MGN) LT2"
    },
    {
      "id": "btech_6_MON_2_e7yjug",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A16"
      ],
      "faculty": "KLK",
      "room": "CL9_2",
      "raw": "P-18B1WCI674 23A16 (KLK) CL9_2"
    },
    {
      "id": "btech_6_MON_3_vo4qr2",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A16"
      ],
      "faculty": "KLK",
      "room": "CL9_2",
      "raw": "P-18B1WCI674 23A16 (KLK) CL9_2"
    },
    {
      "id": "btech_6_MON_6_3ob1iq",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A14"
      ],
      "faculty": "KLK",
      "room": "CL7",
      "raw": "P-18B1WCI674 23A14 (KLK) CL7"
    },
    {
      "id": "btech_6_MON_7_t2kh8o",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A14"
      ],
      "faculty": "KLK",
      "room": "CL7",
      "raw": "P-18B1WCI674 23A14 (KLK) CL7"
    },
    {
      "id": "btech_6_MON_6_km09v9",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI642",
      "batches": [
        "23J11",
        "23J12"
      ],
      "faculty": "NSA",
      "room": "CR2",
      "raw": "L-25B1WCI642 23J11, 23J12 (NSA) CR2"
    },
    {
      "id": "btech_6_MON_7_zl1xa0",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23I11",
        "23J11",
        "23J12",
        "23K11",
        "23I12"
      ],
      "faculty": "AKS",
      "room": "LT3",
      "raw": "L-24B11HS612 23I11,23J11,23J12,23K11,23I12 (AKS) LT3"
    },
    {
      "id": "btech_6_MON_0_dsf6ue",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WHS641",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "NJL",
      "room": "CR4",
      "raw": "L-18B1WHS641 ALL BRANCHES (NJL) CR4"
    },
    {
      "id": "btech_6_MON_1_ff8osu",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBI631",
      "batches": [
        "23F11"
      ],
      "faculty": "TTS",
      "room": "TR5",
      "raw": "L-18B1WBI631 23F11 (TTS) TR5"
    },
    {
      "id": "btech_6_MON_2_6nisca",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A14"
      ],
      "faculty": "NKR",
      "room": "CL5_2",
      "raw": "P-18B17CI672 23A14 (NKR) CL5_2"
    },
    {
      "id": "btech_6_MON_3_d8uyv1",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A14"
      ],
      "faculty": "NKR",
      "room": "CL5_2",
      "raw": "P-18B17CI672 23A14 (NKR) CL5_2"
    },
    {
      "id": "btech_6_MON_5_kn5r9x",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "C11",
        "23BM11",
        "23F11"
      ],
      "faculty": "GVN",
      "room": "LT2/DLC",
      "raw": "L-18B11CI611 23I11,23I12,23J11,23J12,23K11, C11, 23BM11,23F11 (GVN) LT2/DLC"
    },
    {
      "id": "btech_6_MON_7_xn4xdp",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23E11",
        "23F11",
        "23BM11"
      ],
      "faculty": "ABC",
      "room": "GDROOM, LANGULAB",
      "raw": "T-24B11HS615 23E11, 23F11, 23BM11 (ABC) GDROOM, LANGULAB"
    },
    {
      "id": "btech_6_MON_0_oihnxd",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B1WHS631",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "DLR",
      "room": "CR5",
      "raw": "L-24B1WHS631 ALL BRANCHES (DLR) CR5"
    },
    {
      "id": "btech_6_MON_6_zyh3x4",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A16"
      ],
      "faculty": "VDN",
      "room": "GDROOM, LANGULAB",
      "raw": "T-24B11HS615 23A16 (VDN) GDROOM, LANGULAB"
    },
    {
      "id": "btech_6_MON_0_x4lzth",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "23B1WHS632",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "RTK",
      "room": "CR6",
      "raw": "L-23B1WHS632 ALL BRANCHES (RTK) CR6"
    },
    {
      "id": "btech_6_MON_1_iuevyx",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "23B11CE611",
      "batches": [],
      "faculty": "",
      "room": "23B11CE611",
      "raw": "L-23B11CE611"
    },
    {
      "id": "btech_6_MON_1_7hs10g",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "23D11",
      "batches": [],
      "faculty": "NJP",
      "room": "TR9",
      "raw": "23D11 (NJP) TR9"
    },
    {
      "id": "btech_6_MON_3_jtbfno",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "18B11EC612",
      "batches": [
        "23B11"
      ],
      "faculty": "SHR",
      "room": "ECL3",
      "raw": "T-18B11EC612 23B11 (SHR) ECL3"
    },
    {
      "id": "btech_6_MON_6_ecrjs4",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A11"
      ],
      "faculty": "PKR",
      "room": "CL3_1",
      "raw": "P-18B17CI672 23A11 (PKR) CL3_1"
    },
    {
      "id": "btech_6_MON_7_137rwp",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A11"
      ],
      "faculty": "PKR",
      "room": "CL3_1",
      "raw": "P-18B17CI672 23A11 (PKR) CL3_1"
    },
    {
      "id": "btech_6_MON_0_720kd7",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B1WHS632",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "AKS",
      "room": "CR7",
      "raw": "L-24B1WHS632 ALL BRANCHES (AKS) CR7"
    },
    {
      "id": "btech_6_MON_5_4qtuir",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A18"
      ],
      "faculty": "VDN",
      "room": "GDROOM,LANGULAB",
      "raw": "T-24B11HS615 23A18 (VDN) GDROOM,LANGULAB"
    },
    {
      "id": "btech_6_MON_6_ycxpug",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WEC632",
      "batches": [
        "23B11"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "L-18B1WEC632 23B11 (RKU) TR4"
    },
    {
      "id": "btech_6_MON_0_qdip0x",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "20B1WHS631",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "ANU",
      "room": "CR1",
      "raw": "L-20B1WHS631 ALL BRANCHES (ANU) CR1"
    },
    {
      "id": "btech_6_MON_1_msrp4l",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A11"
      ],
      "faculty": "DLR",
      "room": "GDROOM",
      "raw": "T-24B11HS615 23A11 (DLR) GDROOM"
    },
    {
      "id": "btech_6_MON_2_s6e3j1",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17BI672",
      "batches": [
        "23F11"
      ],
      "faculty": "RJK",
      "room": "BIL",
      "raw": "P-18B17BI672 23F11 (RJK) BIL"
    },
    {
      "id": "btech_6_MON_3_p50ov0",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17BI672",
      "batches": [
        "23F11"
      ],
      "faculty": "RJK",
      "room": "BIL",
      "raw": "P-18B17BI672 23F11 (RJK) BIL"
    },
    {
      "id": "btech_6_MON_6_9l77u6",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A17"
      ],
      "faculty": "SMA",
      "room": "CL8_1",
      "raw": "P-18B17CI672 23A17 (SMA) CL8_1"
    },
    {
      "id": "btech_6_MON_7_nxagg1",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A17"
      ],
      "faculty": "SMA",
      "room": "CL8_1",
      "raw": "P-18B17CI672 23A17 (SMA) CL8_1"
    },
    {
      "id": "btech_6_MON_2_683fx2",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI673",
      "batches": [
        "23C11",
        "MIT"
      ],
      "faculty": "EGA",
      "room": "CL5_1",
      "raw": "P-18B17CI673 23C11, MIT (EGA) CL5_1"
    },
    {
      "id": "btech_6_MON_3_mc7y66",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI673",
      "batches": [
        "23C11",
        "MIT"
      ],
      "faculty": "EGA",
      "room": "CL5_1",
      "raw": "P-18B17CI673 23C11, MIT (EGA) CL5_1"
    },
    {
      "id": "btech_6_MON_1_dqbiq5",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WEC632",
      "batches": [
        "23B11"
      ],
      "faculty": "RKU",
      "room": "TR1",
      "raw": "L-18B1WEC632 23B11 (RKU) TR1"
    },
    {
      "id": "btech_6_MON_2_rwj675",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCE639",
      "batches": [
        "23D11"
      ],
      "faculty": "ASR",
      "room": "CR15",
      "raw": "L-18B1WCE639 23D11 (ASR) CR15"
    },
    {
      "id": "btech_6_MON_6_q9yicv",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A19"
      ],
      "faculty": "SKP",
      "room": "CL10",
      "raw": "P-18B1WCI674 23A19 (SKP) CL10"
    },
    {
      "id": "btech_6_MON_7_o5sdyn",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A19"
      ],
      "faculty": "SKP",
      "room": "CL10",
      "raw": "P-18B1WCI674 23A19 (SKP) CL10"
    },
    {
      "id": "btech_6_MON_1_rsbcr7",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "SRJ",
      "room": "CR2",
      "raw": "L-18B11CI611 23A17,23A18,23A19 (SRJ) CR2"
    },
    {
      "id": "btech_6_MON_2_n4hn8d",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23J12",
        "23K11",
        "23BM11"
      ],
      "faculty": "SKP",
      "room": "CL3_1",
      "raw": "P-18B1WCI674 23J12,23K11,23BM11 (SKP) CL3_1"
    },
    {
      "id": "btech_6_MON_3_i5orw1",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23J12",
        "23K11",
        "23BM11"
      ],
      "faculty": "SKP",
      "room": "CL3_1",
      "raw": "P-18B1WCI674 23J12,23K11,23BM11 (SKP) CL3_1"
    },
    {
      "id": "btech_6_MON_5_zyc6cb",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WEC742",
      "batches": [
        "23B11"
      ],
      "faculty": "SRU",
      "room": "CR17",
      "raw": "L-18B1WEC742 23B11 (SRU) CR17"
    },
    {
      "id": "btech_6_MON_6_kf05d3",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A12"
      ],
      "faculty": "EGA",
      "room": "BIL",
      "raw": "P-18B1WCI675 23A12 (EGA) BIL"
    },
    {
      "id": "btech_6_MON_7_g53ufx",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A12"
      ],
      "faculty": "EGA",
      "room": "BIL",
      "raw": "P-18B1WCI675 23A12 (EGA) BIL"
    },
    {
      "id": "btech_6_MON_6_ozla0s",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23C11"
      ],
      "faculty": "GVN",
      "room": "CL6",
      "raw": "P-18B1WCI675 23C11 (GVN) CL6"
    },
    {
      "id": "btech_6_MON_7_v3m3e7",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23C11"
      ],
      "faculty": "GVN",
      "room": "CL6",
      "raw": "P-18B1WCI675 23C11 (GVN) CL6"
    },
    {
      "id": "btech_6_MON_2_u2h3mn",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11BT611",
      "batches": [
        "23E11."
      ],
      "faculty": "SBS",
      "room": "CR18",
      "raw": "L-18B11BT611 23E11. (SBS) CR18"
    },
    {
      "id": "btech_6_MON_4_smzakd",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A19"
      ],
      "faculty": "SRJ",
      "room": "CL3_1",
      "raw": "P-18B17CI671 23A19 (SRJ) CL3_1"
    },
    {
      "id": "btech_6_MON_5_s0po8f",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A19"
      ],
      "faculty": "SRJ",
      "room": "CL3_1",
      "raw": "P-18B17CI671 23A19 (SRJ) CL3_1"
    },
    {
      "id": "btech_6_MON_6_jn2onn",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI641",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "VSG",
      "room": "CR10",
      "raw": "L-25B1WCI641 23I11, 23I12 (VSG) CR10"
    },
    {
      "id": "btech_6_MON_7_opxk7s",
      "semesterId": "btech_6",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCE634",
      "batches": [
        "23D11"
      ],
      "faculty": "ADP",
      "room": "TR8",
      "raw": "L-18B1WCE634 23D11 (ADP) TR8"
    },
    {
      "id": "btech_6_TUE_1_1ls1hs",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCE631",
      "batches": [
        "23D11"
      ],
      "faculty": "CPG",
      "room": "CR13",
      "raw": "L-18B1WCE631 23D11 (CPG) CR13"
    },
    {
      "id": "btech_6_TUE_6_v2hzfp",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI571",
      "batches": [
        "23B11",
        "23D11"
      ],
      "faculty": "RKI",
      "room": "CL5_1",
      "raw": "P-24B17CI571 23B11,23D11 (RKI) CL5_1"
    },
    {
      "id": "btech_6_TUE_7_r0dccy",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI571",
      "batches": [
        "23B11",
        "23D11"
      ],
      "faculty": "RKI",
      "room": "CL5_1",
      "raw": "P-24B17CI571 23B11,23D11 (RKI) CL5_1"
    },
    {
      "id": "btech_6_TUE_0_b2z5uy",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCE631",
      "batches": [
        "23D11"
      ],
      "faculty": "CPG",
      "room": "CR15",
      "raw": "L-18B1WCE631 23D11 (CPG) CR15"
    },
    {
      "id": "btech_6_TUE_1_q0snl2",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "PKR",
      "room": "CR4",
      "raw": "L-18B11CI612 23A11,23A12,23A13 (PKR) CR4"
    },
    {
      "id": "btech_6_TUE_3_pvpbyk",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "25BBWHS631",
      "batches": [
        "23W11"
      ],
      "faculty": "ABC",
      "room": "CR11",
      "raw": "T-25BBWHS631 23W11 (ABC) CR11"
    },
    {
      "id": "btech_6_TUE_0_81f3an",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A15"
      ],
      "faculty": "KLK",
      "room": "CL1",
      "raw": "P-18B1WCI674 23A15 (KLK) CL1"
    },
    {
      "id": "btech_6_TUE_1_dk7i05",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A15"
      ],
      "faculty": "KLK",
      "room": "CL1",
      "raw": "P-18B1WCI674 23A15 (KLK) CL1"
    },
    {
      "id": "btech_6_TUE_2_pymuyi",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WHS641",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "NJL",
      "room": "CR7",
      "raw": "L-18B1WHS641 ALL BRANCHES (NJL) CR7"
    },
    {
      "id": "btech_6_TUE_3_rxg4bc",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BI612",
      "batches": [
        "23F11"
      ],
      "faculty": "RJK",
      "room": "TR6",
      "raw": "L-18B11BI612 23F11 (RJK) TR6"
    },
    {
      "id": "btech_6_TUE_4_xjo7eg",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI643",
      "batches": [
        "23J11",
        "23J12"
      ],
      "faculty": "PKR",
      "room": "CR9",
      "raw": "L-25B1WCI643 23J11,23J12 (PKR) CR9"
    },
    {
      "id": "btech_6_TUE_5_ihdjbz",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23B11CE612",
      "batches": [
        "23D11"
      ],
      "faculty": "KKR",
      "room": "CR13",
      "raw": "L-23B11CE612 23D11 (KKR) CR13"
    },
    {
      "id": "btech_6_TUE_6_ljwcy0",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A11"
      ],
      "faculty": "SRJ",
      "room": "CL1",
      "raw": "P-24B17CI671 23A11 (SRJ) CL1"
    },
    {
      "id": "btech_6_TUE_7_l5rfsr",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A11"
      ],
      "faculty": "SRJ",
      "room": "CL1",
      "raw": "P-24B17CI671 23A11 (SRJ) CL1"
    },
    {
      "id": "btech_6_TUE_1_1j46rp",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A19"
      ],
      "faculty": "VDN",
      "room": "GDROOM,LANGULAB",
      "raw": "T-24B11HS615 23A19 (VDN) GDROOM,LANGULAB"
    },
    {
      "id": "btech_6_TUE_7_p536mo",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "23BM11"
      ],
      "faculty": "RMS",
      "room": "LT2",
      "raw": "L-18B11CI612 23I11,23I12,23J11,23J12,23K11,23BM11 (RMS) LT2"
    },
    {
      "id": "btech_6_TUE_3_oga056",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WCI632",
      "batches": [
        "23C11"
      ],
      "faculty": "PDN",
      "room": "CR10",
      "raw": "L-19B1WCI632 23C11 (PDN) CR10"
    },
    {
      "id": "btech_6_TUE_5_nrj7wg",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23I11",
        "23J11",
        "23K11",
        "23I12",
        "23J12"
      ],
      "faculty": "AKS",
      "room": "LT3",
      "raw": "L-24B11HS612 23I11,23J11,23K11,23I12,23J12 (AKS) LT3"
    },
    {
      "id": "btech_6_TUE_6_egy8rm",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A13"
      ],
      "faculty": "EGA",
      "room": "BIL",
      "raw": "P-18B1WCI675  23A13 (EGA) BIL"
    },
    {
      "id": "btech_6_TUE_7_gyfkfg",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A13"
      ],
      "faculty": "EGA",
      "room": "BIL",
      "raw": "P-18B1WCI675 23A13 (EGA) BIL"
    },
    {
      "id": "btech_6_TUE_0_481nne",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A18"
      ],
      "faculty": "SRJ",
      "room": "CL3_2",
      "raw": "P-18B17CI671 23A18 (SRJ) CL3_2"
    },
    {
      "id": "btech_6_TUE_1_875oig",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A18"
      ],
      "faculty": "SRJ",
      "room": "CL3_2",
      "raw": "P-18B17CI671 23A18 (SRJ) CL3_2"
    },
    {
      "id": "btech_6_TUE_2_wgbhx1",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24B1WHS631",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "DLR",
      "room": "CR8",
      "raw": "L-24B1WHS631 ALL BRANCHES (DLR) CR8"
    },
    {
      "id": "btech_6_TUE_4_wti6hc",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BT612",
      "batches": [
        "23E11."
      ],
      "faculty": "GAI",
      "room": "CR11",
      "raw": "L-18B11BT612 23E11. (GAI) CR11"
    },
    {
      "id": "btech_6_TUE_5_g56e7z",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "SMA",
      "room": "CR1",
      "raw": "L-18B11CI612 23A17,23A18,23A19 (SMA) CR1"
    },
    {
      "id": "btech_6_TUE_7_fe5utt",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "24B11HS412",
      "batches": [
        "23W11"
      ],
      "faculty": "ASA",
      "room": "TR2",
      "raw": "L-24B11HS412 23W11 (ASA) TR2"
    },
    {
      "id": "btech_6_TUE_4_1780sq",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23I11"
      ],
      "faculty": "ABC",
      "room": "GDROOM, LANGULAB",
      "raw": "T-24B11HS615 23I11 (ABC) GDROOM, LANGULAB"
    },
    {
      "id": "btech_6_TUE_5_3ctd37",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25BB1HS612",
      "batches": [
        "23W11"
      ],
      "faculty": "VDN",
      "room": "CR11",
      "raw": "L-25BB1HS612 23W11 (VDN) CR11"
    },
    {
      "id": "btech_6_TUE_6_rvypai",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BI611/",
      "batches": [
        "18B1WCI634",
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "23C11",
        "23BM11",
        "23F11"
      ],
      "faculty": "SKP",
      "room": "LT3",
      "raw": "L-18B11BI611/  18B1WCI634 23I11,23I12,23J11,23J12,23K11, 23C11, 23BM11, 23F11 (SKP) LT3"
    },
    {
      "id": "btech_6_TUE_0_74pwmq",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A17"
      ],
      "faculty": "RBT",
      "room": "CL6",
      "raw": "P-24B17CI671 23A17 (RBT) CL6"
    },
    {
      "id": "btech_6_TUE_1_ow48xo",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A17"
      ],
      "faculty": "RBT",
      "room": "CL6",
      "raw": "P-24B17CI671 23A17 (RBT) CL6"
    },
    {
      "id": "btech_6_TUE_2_1yvox2",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "23B1WHS632",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "RTK",
      "room": "CR11",
      "raw": "L-23B1WHS632 ALL BRANCHES (RTK) CR11"
    },
    {
      "id": "btech_6_TUE_3_8tgvyd",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "RKB",
      "room": "CR4",
      "raw": "L-24B11HS612 23A11,23A12,23A13 (RKB) CR4"
    },
    {
      "id": "btech_6_TUE_7_rctwck",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCI635",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "MGN",
      "room": "CR4",
      "raw": "L-18B1WCI635 23A17,23A18,23A19 (MGN) CR4"
    },
    {
      "id": "btech_6_TUE_0_uvm9sr",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI635",
      "batches": [
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "2",
        "23BM11"
      ],
      "faculty": "MGN",
      "room": "LT3",
      "raw": "L-18B1WCI635 23I11,23I12,23J11,23J12,23K11,2 23BM11 (MGN) LT3"
    },
    {
      "id": "btech_6_TUE_2_uqdgyy",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24B1WHS632",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "AKS",
      "room": "CR4",
      "raw": "L-24B1WHS632 ALL BRANCHES (AKS) CR4"
    },
    {
      "id": "btech_6_TUE_4_oernus",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A15"
      ],
      "faculty": "NTS",
      "room": "CL3_2",
      "raw": "P-24B17CI671 23A15 (NTS) CL3_2"
    },
    {
      "id": "btech_6_TUE_5_9qnvew",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A15"
      ],
      "faculty": "NTS",
      "room": "CL3_2",
      "raw": "P-24B17CI671 23A15 (NTS) CL3_2"
    },
    {
      "id": "btech_6_TUE_6_5ms7kc",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A17"
      ],
      "faculty": "VDN",
      "room": "GDROOM,LANGULAB",
      "raw": "T-24B11HS615 23A17 (VDN) GDROOM,LANGULAB"
    },
    {
      "id": "btech_6_TUE_1_48r469",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WEC742",
      "batches": [
        "23B11"
      ],
      "faculty": "SRU",
      "room": "ECL6",
      "raw": "L-18B1WEC742 23B11 (SRU) ECL6"
    },
    {
      "id": "btech_6_TUE_2_1b9ej6",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "20B1WHS631",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "ANU",
      "room": "CR1",
      "raw": "L-20B1WHS631 ALL BRANCHES (ANU) CR1"
    },
    {
      "id": "btech_6_TUE_3_w5xqza",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "RAD",
      "room": "CR5",
      "raw": "L-24B11HS612 23A17,23A18,23A19 (RAD) CR5"
    },
    {
      "id": "btech_6_TUE_1_nwjv59",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23I11",
        "23i1223J11&23J12",
        "23K11",
        "23C11",
        "\\23F11",
        "23BM11"
      ],
      "faculty": "GVN",
      "room": "LT2",
      "raw": "L-18B11CI611 23I11, 23i1223J11&23J12,23K11,23C11,\\23F11,23BM11 (GVN) LT2"
    },
    {
      "id": "btech_6_TUE_6_51f8vm",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "NKR",
      "room": "CR4",
      "raw": "L-18B11CI612 23A14,23A15,23A16 (NKR) CR4"
    },
    {
      "id": "btech_6_TUE_7_1pwesa",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCI635",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "PTK",
      "room": "LT3",
      "raw": "L-18B1WCI635 23A14,23A15,23A16 (PTK) LT3"
    },
    {
      "id": "btech_6_TUE_1_passgo",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "24B11HS412",
      "batches": [
        "23W11"
      ],
      "faculty": "ASA",
      "room": "TR7",
      "raw": "T-24B11HS412 23W11 (ASA) TR7"
    },
    {
      "id": "btech_6_TUE_4_gnmm91",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A14"
      ],
      "faculty": "PTK",
      "room": "CL7",
      "raw": "P-18B1WCI675 23A14 (PTK) CL7"
    },
    {
      "id": "btech_6_TUE_5_1zg5sq",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A14"
      ],
      "faculty": "PTK",
      "room": "CL7",
      "raw": "P-18B1WCI675 23A14 (PTK) CL7"
    },
    {
      "id": "btech_6_TUE_1_sndhxh",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11BT612",
      "batches": [
        "23E11."
      ],
      "faculty": "GAI",
      "room": "CR11",
      "raw": "L-18B11BT612 23E11. (GAI) CR11"
    },
    {
      "id": "btech_6_TUE_3_vckloq",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI645",
      "batches": [
        "23K11"
      ],
      "faculty": "NTS",
      "room": "TR3",
      "raw": "L-25B1WCI645 23K11 (NTS) TR3"
    },
    {
      "id": "btech_6_TUE_5_ehsflr",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17BT671",
      "batches": [
        "23E11"
      ],
      "faculty": "SBS",
      "room": "MICROLAB",
      "raw": "P-18B17BT671 23E11, (SBS) MICROLAB"
    },
    {
      "id": "btech_6_TUE_6_kiop6t",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17BT671",
      "batches": [
        "23E11"
      ],
      "faculty": "SBS",
      "room": "MICROLAB",
      "raw": "P-18B17BT671 23E11, (SBS) MICROLAB"
    },
    {
      "id": "btech_6_TUE_0_v9whsn",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A16"
      ],
      "faculty": "NTS",
      "room": "CL7",
      "raw": "P-18B17CI671 23A16 (NTS) CL7"
    },
    {
      "id": "btech_6_TUE_1_z5d0cu",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A16"
      ],
      "faculty": "NTS",
      "room": "CL7",
      "raw": "P-18B17CI671 23A16 (NTS) CL7"
    },
    {
      "id": "btech_6_TUE_4_bi7pk7",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "25BBWHS633",
      "batches": [
        "23W11"
      ],
      "faculty": "VDN",
      "room": "TR7",
      "raw": "L-25BBWHS633 23W11 (VDN) TR7"
    },
    {
      "id": "btech_6_TUE_6_j5bsmu",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A12"
      ],
      "faculty": "PKR",
      "room": "CL4",
      "raw": "P-18B17CI672 23A12 (PKR) CL4"
    },
    {
      "id": "btech_6_TUE_7_vsh3rb",
      "semesterId": "btech_6",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A12"
      ],
      "faculty": "PKR",
      "room": "CL4",
      "raw": "P-18B17CI672 23A12 (PKR) CL4"
    },
    {
      "id": "btech_6_WED_1_5u2cie",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25BBWHS634",
      "batches": [
        "23W11"
      ],
      "faculty": "TNS",
      "room": "TR1",
      "raw": "L-25BBWHS634 23W11 (TNS) TR1"
    },
    {
      "id": "btech_6_WED_6_uhtpqk",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI641",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "VSG",
      "room": "CR6",
      "raw": "L-25B1WCI641 23I11, 23I12 (VSG) CR6"
    },
    {
      "id": "btech_6_WED_0_ovl5cu",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI634",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "SKP",
      "room": "CR9",
      "raw": "L-18B1WCI634 23A17,23A18,23A19 (SKP) CR9"
    },
    {
      "id": "btech_6_WED_2_orj7qy",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI613/",
      "batches": [
        "18B1WBI632",
        "23C11",
        "MIT",
        "23F11"
      ],
      "faculty": "EGA",
      "room": "TR4",
      "raw": "L-18B11CI613/ 18B1WBI632 23C11, MIT, 23F11 (EGA) TR4"
    },
    {
      "id": "btech_6_WED_3_kkwe3x",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23j12"
      ],
      "faculty": "ABC",
      "room": "GDROOM,LANGULAB",
      "raw": "T-24B11HS615 23j12 (ABC) GDROOM,LANGULAB"
    },
    {
      "id": "btech_6_WED_4_ohjhhe",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "19B1WCI672",
      "batches": [
        "23C11"
      ],
      "faculty": "PDN",
      "room": "CL6",
      "raw": "P-19B1WCI672 23C11 (PDN) CL6"
    },
    {
      "id": "btech_6_WED_5_4fxr7o",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "19B1WCI672",
      "batches": [
        "23C11"
      ],
      "faculty": "PDN",
      "room": "CL6",
      "raw": "P-19B1WCI672 23C11 (PDN) CL6"
    },
    {
      "id": "btech_6_WED_6_40xarx",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A13"
      ],
      "faculty": "KLK",
      "room": "CL3_1",
      "raw": "P-18B1WCI674 23A13 (KLK) CL3_1"
    },
    {
      "id": "btech_6_WED_7_w6d978",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A13"
      ],
      "faculty": "KLK",
      "room": "CL3_1",
      "raw": "P-18B1WCI674 23A13 (KLK) CL3_1"
    },
    {
      "id": "btech_6_WED_0_2qgypz",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "PTK",
      "room": "CL7",
      "raw": "P-18B1WCI675 23I11,23I12 (PTK) CL7"
    },
    {
      "id": "btech_6_WED_1_8euhft",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "PTK",
      "room": "CL7",
      "raw": "P-18B1WCI675 23I11,23I12 (PTK) CL7"
    },
    {
      "id": "btech_6_WED_5_ijoaoy",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "HRI",
      "room": "CR9/DLC",
      "raw": "L-18B11CI611 23A11,23A12,23A13 (HRI) CR9/DLC"
    },
    {
      "id": "btech_6_WED_6_4wqwoe",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A11"
      ],
      "faculty": "HRI",
      "room": "CL4",
      "raw": "P-18B17CI671 23A11 (HRI) CL4"
    },
    {
      "id": "btech_6_WED_7_ne76o7",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A11"
      ],
      "faculty": "HRI",
      "room": "CL4",
      "raw": "P-18B17CI671 23A11 (HRI) CL4"
    },
    {
      "id": "btech_6_WED_0_zd4tvj",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WEC742",
      "batches": [
        "23B11"
      ],
      "faculty": "SRU",
      "room": "TR6",
      "raw": "L-18B1WEC742 23B11 (SRU) TR6"
    },
    {
      "id": "btech_6_WED_2_uc9433",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11BT612",
      "batches": [
        "23E11."
      ],
      "faculty": "GAI",
      "room": "CR12",
      "raw": "L-18B11BT612 23E11. (GAI) CR12"
    },
    {
      "id": "btech_6_WED_3_vugikm",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25BBWHS633",
      "batches": [
        "23W11"
      ],
      "faculty": "VDN",
      "room": "TR2",
      "raw": "L-25BBWHS633 23W11 (VDN) TR2"
    },
    {
      "id": "btech_6_WED_5_w7rb7q",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "SMA",
      "room": "CR2",
      "raw": "L-18B11CI612 23A17,23A18,23A19 (SMA) CR2"
    },
    {
      "id": "btech_6_WED_6_gm8uk7",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI642",
      "batches": [
        "23J11",
        "23J12"
      ],
      "faculty": "NSA",
      "room": "CR10",
      "raw": "L-25B1WCI642 23J11, 23J12 (NSA) CR10"
    },
    {
      "id": "btech_6_WED_2_bxr1ja",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "MGN",
      "room": "CL7",
      "raw": "P-18B1WCI674 23I11, 23I12 (MGN) CL7"
    },
    {
      "id": "btech_6_WED_3_0akz3e",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "MGN",
      "room": "CL7",
      "raw": "P-18B1WCI674 23I11, 23I12 (MGN) CL7"
    },
    {
      "id": "btech_6_WED_5_cdx281",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBT632",
      "batches": [
        "23E11",
        "23F11"
      ],
      "faculty": "GPL",
      "room": "CR18",
      "raw": "L-18B1WBT632 23E11,23F11 (GPL) CR18"
    },
    {
      "id": "btech_6_WED_6_es7f6i",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A18"
      ],
      "faculty": "MGN",
      "room": "CL8_1",
      "raw": "P-18B1WCI675 23A18 (MGN) CL8_1"
    },
    {
      "id": "btech_6_WED_7_60fjzi",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A18"
      ],
      "faculty": "MGN",
      "room": "CL8_1",
      "raw": "P-18B1WCI675 23A18 (MGN) CL8_1"
    },
    {
      "id": "btech_6_WED_2_9n17vi",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A13"
      ],
      "faculty": "PKR",
      "room": "CL3_2",
      "raw": "P-18B17CI672 23A13 (PKR) CL3_2"
    },
    {
      "id": "btech_6_WED_3_yxh67g",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A13"
      ],
      "faculty": "PKR",
      "room": "CL3_2",
      "raw": "P-18B17CI672 23A13 (PKR) CL3_2"
    },
    {
      "id": "btech_6_WED_6_8olv8x",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A15"
      ],
      "faculty": "NKR",
      "room": "CL3_2",
      "raw": "P-18B17CI672 23A15 (NKR) CL3_2"
    },
    {
      "id": "btech_6_WED_7_0b11vl",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A15"
      ],
      "faculty": "NKR",
      "room": "CL3_2",
      "raw": "P-18B17CI672 23A15 (NKR) CL3_2"
    },
    {
      "id": "btech_6_WED_0_1svcv3",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A14"
      ],
      "faculty": "RMS",
      "room": "CL3_2",
      "raw": "P-24B17CI671 23A14 (RMS) CL3_2"
    },
    {
      "id": "btech_6_WED_1_n2eqyt",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A14"
      ],
      "faculty": "RMS",
      "room": "CL3_2",
      "raw": "P-24B17CI671 23A14 (RMS) CL3_2"
    },
    {
      "id": "btech_6_WED_2_lgttpb",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24B11HS412",
      "batches": [
        "23W11"
      ],
      "faculty": "ASA",
      "room": "TR3",
      "raw": "L-24B11HS412 23W11 (ASA) TR3"
    },
    {
      "id": "btech_6_WED_3_kf4bvq",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BI612",
      "batches": [
        "23F11"
      ],
      "faculty": "RJK",
      "room": "CR19",
      "raw": "L-18B11BI612 23F11 (RJK) CR19"
    },
    {
      "id": "btech_6_WED_1_kh2wqb",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "SRJ",
      "room": "CR7",
      "raw": "L-18B11CI611 23A17,23A18,23A19 (SRJ) CR7"
    },
    {
      "id": "btech_6_WED_2_c7d23h",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A18"
      ],
      "faculty": "SKP",
      "room": "CL8_1",
      "raw": "P-18B1WCI674 23A18 (SKP) CL8_1"
    },
    {
      "id": "btech_6_WED_3_omycrn",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A18"
      ],
      "faculty": "SKP",
      "room": "CL8_1",
      "raw": "P-18B1WCI674 23A18 (SKP) CL8_1"
    },
    {
      "id": "btech_6_WED_6_ftmoya",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A14"
      ],
      "faculty": "NTS",
      "room": "CL5_1",
      "raw": "P-18B17CI671 23A14 (NTS) CL5_1"
    },
    {
      "id": "btech_6_WED_7_x49deg",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A14"
      ],
      "faculty": "NTS",
      "room": "CL5_1",
      "raw": "P-18B17CI671 23A14 (NTS) CL5_1"
    },
    {
      "id": "btech_6_WED_0_svgd2f",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBT632",
      "batches": [
        "23E11",
        "23F11"
      ],
      "faculty": "GPL",
      "room": "TR1",
      "raw": "L-18B1WBT632 23E11,23F11 (GPL) TR1"
    },
    {
      "id": "btech_6_WED_1_i01me9",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11BT611",
      "batches": [
        "23E11."
      ],
      "faculty": "SBS",
      "room": "TR4",
      "raw": "T-18B11BT611 23E11. (SBS) TR4"
    },
    {
      "id": "btech_6_WED_2_w75ahn",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "23B11CE611",
      "batches": [
        "23D11"
      ],
      "faculty": "NJP",
      "room": "CR14",
      "raw": "L-23B11CE611 23D11 (NJP) CR14"
    },
    {
      "id": "btech_6_WED_3_4dk7ao",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCE634",
      "batches": [
        "23D11"
      ],
      "faculty": "ADP",
      "room": "CR13",
      "raw": "L-18B1WCE634 23D11 (ADP) CR13"
    },
    {
      "id": "btech_6_WED_6_t1eka2",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23C11",
        "23B11",
        "23H11",
        "23D11",
        "23E11",
        "23F11",
        "23BM11",
        "24W11"
      ],
      "faculty": "RAD",
      "room": "CR5",
      "raw": "L-24B11HS612  23C11, 23B11,  23H11, 23D11, 23E11, 23F11, 23BM11, 24W11 (RAD) CR5"
    },
    {
      "id": "btech_6_WED_7_ki4pzx",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI643",
      "batches": [
        "23J11",
        "23J12"
      ],
      "faculty": "PKR",
      "room": "CR9",
      "raw": "L-25B1WCI643 23J11,23J12 (PKR) CR9"
    },
    {
      "id": "btech_6_WED_1_wsqzvm",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WEC744",
      "batches": [
        "23B11",
        "23H11"
      ],
      "faculty": "HSL",
      "room": "CR18",
      "raw": "L-18B1WEC744 23B11,23H11 (HSL) CR18"
    },
    {
      "id": "btech_6_WED_7_5avohj",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBI631",
      "batches": [
        "23F11"
      ],
      "faculty": "TTS",
      "room": "TR1",
      "raw": "L-18B1WBI631 23F11 (TTS) TR1"
    },
    {
      "id": "btech_6_WED_1_daorfb",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI634",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "KLK",
      "room": "CR8",
      "raw": "L-18B1WCI634 23A11,23A12,23A13 (KLK) CR8"
    },
    {
      "id": "btech_6_WED_5_yfbn9l",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "23BM11"
      ],
      "faculty": "RMS",
      "room": "LT3",
      "raw": "L-18B11CI612 23I11,23I12,23J11,23J12,23K11,23BM11 (RMS) LT3"
    },
    {
      "id": "btech_6_WED_6_tijw9c",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A19"
      ],
      "faculty": "SMA",
      "room": "CL8_2",
      "raw": "P-18B17CI672  23A19 (SMA) CL8_2"
    },
    {
      "id": "btech_6_WED_7_gobg60",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A19"
      ],
      "faculty": "SMA",
      "room": "CL8_2",
      "raw": "P-18B17CI672 23A19 (SMA) CL8_2"
    },
    {
      "id": "btech_6_WED_0_mv7k43",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23J12",
        "23K11"
      ],
      "faculty": "NTS",
      "room": "CL3_1",
      "raw": "P-24B17CI671 23J12,23K11 (NTS) CL3_1"
    },
    {
      "id": "btech_6_WED_1_l9jd27",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23J12",
        "23K11"
      ],
      "faculty": "NTS",
      "room": "CL3_1",
      "raw": "P-24B17CI671 23J12,23K11 (NTS) CL3_1"
    },
    {
      "id": "btech_6_WED_2_1dan3q",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23J11"
      ],
      "faculty": "NTS",
      "room": "CL5_2",
      "raw": "P-24B17CI671 23J11 (NTS) CL5_2"
    },
    {
      "id": "btech_6_WED_3_2epdun",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23J11"
      ],
      "faculty": "NTS",
      "room": "CL5_2",
      "raw": "P-24B17CI671 23J11 (NTS) CL5_2"
    },
    {
      "id": "btech_6_WED_6_ig6lks",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A12"
      ],
      "faculty": "RMS",
      "room": "CL6",
      "raw": "P-24B17CI671 23A12 (RMS) CL6"
    },
    {
      "id": "btech_6_WED_7_r9b12h",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A12"
      ],
      "faculty": "RMS",
      "room": "CL6",
      "raw": "P-24B17CI671 23A12 (RMS) CL6"
    },
    {
      "id": "btech_6_WED_0_0tzvpa",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23J11"
      ],
      "faculty": "EGA",
      "room": "CL9_1",
      "raw": "P-18B1WCI675 23J11, (EGA) CL9_1"
    },
    {
      "id": "btech_6_WED_1_ghr0u9",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23J11"
      ],
      "faculty": "EGA",
      "room": "CL9_1",
      "raw": "P-18B1WCI675 23J11 (EGA) CL9_1"
    },
    {
      "id": "btech_6_WED_2_riqd4d",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11EC612",
      "batches": [
        "23B11"
      ],
      "faculty": "SHR",
      "room": "ECL3",
      "raw": "L-18B11EC612 23B11 (SHR) ECL3"
    },
    {
      "id": "btech_6_WED_5_yb1lcp",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "NTS",
      "room": "CR10",
      "raw": "L-18B11CI611 23A14,23A15,23A16 (NTS) CR10"
    },
    {
      "id": "btech_6_WED_4_pv3vqd",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B11EC611",
      "batches": [
        "23B11",
        "23A11",
        "23A14"
      ],
      "faculty": "SWT",
      "room": "TR1",
      "raw": "L-18B11EC611 23B11, 23A11, 23A14 (SWT) TR1"
    },
    {
      "id": "btech_6_WED_6_7ltn57",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A17"
      ],
      "faculty": "SRJ",
      "room": "BIL",
      "raw": "P-18B17CI671 23A17 (SRJ) BIL"
    },
    {
      "id": "btech_6_WED_7_euhg1w",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A17"
      ],
      "faculty": "SRJ",
      "room": "BIL",
      "raw": "P-18B17CI671 23A17 (SRJ) BIL"
    },
    {
      "id": "btech_6_WED_2_b9mepz",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI644",
      "batches": [
        "PCC-23K11"
      ],
      "faculty": "RMS",
      "room": "CR11/ DLC",
      "raw": "L-25B1WCI644 PCC-23K11 (RMS) CR11/ DLC"
    },
    {
      "id": "btech_6_WED_2_qk87ne",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A16"
      ],
      "faculty": "NKR",
      "room": "CL1",
      "raw": "P-18B17CI672 23A16 (NKR) CL1"
    },
    {
      "id": "btech_6_WED_3_i7y83v",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A16"
      ],
      "faculty": "NKR",
      "room": "CL1",
      "raw": "P-18B17CI672 23A16 (NKR) CL1"
    },
    {
      "id": "btech_6_WED_6_lsgt0a",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A16"
      ],
      "faculty": "PTK",
      "room": "CL7",
      "raw": "P-18B1WCI675 23A16 (PTK) CL7"
    },
    {
      "id": "btech_6_WED_7_myw6fr",
      "semesterId": "btech_6",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A16"
      ],
      "faculty": "PTK",
      "room": "CL7",
      "raw": "P-18B1WCI675 23A16 (PTK) CL7"
    },
    {
      "id": "btech_6_THU_0_nvpmkt",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "23BM11"
      ],
      "faculty": "RMS",
      "room": "CR5",
      "raw": "L-18B11CI612 23I11,23I12,23J11,23J12,23K11, 23BM11 (RMS) CR5"
    },
    {
      "id": "btech_6_THU_1_s7quw9",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "AIML[23I11",
        "23I12"
      ],
      "faculty": "GVN",
      "room": "CL4",
      "raw": "P-18B17CI671 AIML[23I11,23I12] (GVN) CL4"
    },
    {
      "id": "btech_6_THU_2_280bmy",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "AIML[23I11",
        "23I12"
      ],
      "faculty": "GVN",
      "room": "CL4",
      "raw": "P-18B17CI671 AIML[23I11,23I12] (GVN) CL4"
    },
    {
      "id": "btech_6_THU_5_h1wh3u",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A12"
      ],
      "faculty": "KLK",
      "room": "CL10",
      "raw": "P-18B1WCI674 23A12 (KLK) CL10"
    },
    {
      "id": "btech_6_THU_6_e2r75i",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A12"
      ],
      "faculty": "KLK",
      "room": "CL10",
      "raw": "P-18B1WCI674 23A12 (KLK) CL10"
    },
    {
      "id": "btech_6_THU_0_w0ea38",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI635",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "EGA",
      "room": "CR2",
      "raw": "L-18B1WCI635 23A11,23A12,23A13 (EGA) CR2"
    },
    {
      "id": "btech_6_THU_6_8z5kpi",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23I12",
        "23K11"
      ],
      "faculty": "ABC",
      "room": "GDROOM, LANGULAB",
      "raw": "T-24B11HS615 23I12, 23K11 (ABC) GDROOM, LANGULAB"
    },
    {
      "id": "btech_6_THU_7_7f12b1",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25BBWHS631",
      "batches": [
        "23W11"
      ],
      "faculty": "ABC",
      "room": "TR1",
      "raw": "L-25BBWHS631 23W11 (ABC) TR1"
    },
    {
      "id": "btech_6_THU_6_9a17bo",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23B11",
        "23D11"
      ],
      "faculty": "SRJ",
      "room": "BIL",
      "raw": "P-24B17CI671 23B11,23D11 (SRJ) BIL"
    },
    {
      "id": "btech_6_THU_7_skb320",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23B11",
        "23D11"
      ],
      "faculty": "SRJ",
      "room": "BIL",
      "raw": "P-24B17CI671 23B11,23D11 (SRJ) BIL"
    },
    {
      "id": "btech_6_THU_8_inxvlu",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WHS641",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "NJL",
      "room": "CR4",
      "raw": "L-18B1WHS641 ALL BRANCHES (NJL) CR4"
    },
    {
      "id": "btech_6_THU_0_054ocy",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "23B11CE612",
      "batches": [
        "23D11"
      ],
      "faculty": "KKR",
      "room": "CR14",
      "raw": "L-23B11CE612 23D11 (KKR) CR14"
    },
    {
      "id": "btech_6_THU_1_thpilf",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A19"
      ],
      "faculty": "NKR",
      "room": "CL3_1",
      "raw": "P-24B17CI671 23A19 (NKR) CL3_1"
    },
    {
      "id": "btech_6_THU_2_8ed9d3",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A19"
      ],
      "faculty": "NKR",
      "room": "CL3_1",
      "raw": "P-24B17CI671 23A19 (NKR) CL3_1"
    },
    {
      "id": "btech_6_THU_6_b3qtg3",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25BB1HS612",
      "batches": [
        "23W11"
      ],
      "faculty": "VDN",
      "room": "TR1",
      "raw": "L-25BB1HS612 23W11 (VDN) TR1"
    },
    {
      "id": "btech_6_THU_8_9ecm7x",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "24B1WHS631",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "DLR",
      "room": "LT3",
      "raw": "L-24B1WHS631 ALL BRANCHES (DLR) LT3"
    },
    {
      "id": "btech_6_THU_2_2xur5d",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23C11",
        "23B11",
        "23H11",
        "23D11",
        "23E11",
        "23F11",
        "23BM11",
        "24W11"
      ],
      "faculty": "RAD",
      "room": "CR5",
      "raw": "L-24B11HS612  23C11, 23B11,  23H11, 23D11, 23E11, 23F11, 23BM11, 24W11 (RAD) CR5"
    },
    {
      "id": "btech_6_THU_8_pzvwzy",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "23B1WHS632",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "RTK",
      "room": "CR6",
      "raw": "L-23B1WHS632 ALL BRANCHES (RTK) CR6"
    },
    {
      "id": "btech_6_THU_0_ij8fco",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "PKP",
      "room": "CR8",
      "raw": "L-24B11HS612 23A14,23A15,23A16 (PKP) CR8"
    },
    {
      "id": "btech_6_THU_1_x0lfd8",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "HRI",
      "room": "LT3",
      "raw": "L-18B11CI611 23A11,23A12,23A13 (HRI) LT3"
    },
    {
      "id": "btech_6_THU_3_fc0732",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A12"
      ],
      "faculty": "DLR",
      "room": "CR16",
      "raw": "T-24B11HS615 23A12 (DLR) CR16"
    },
    {
      "id": "btech_6_THU_6_w4uoa4",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WCI632",
      "batches": [
        "23C11"
      ],
      "faculty": "PDN",
      "room": "CR5",
      "raw": "L-19B1WCI632 23C11 (PDN) CR5"
    },
    {
      "id": "btech_6_THU_7_ej1dbq",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A15"
      ],
      "faculty": "VDN",
      "room": "GDROOM, LANGULAB",
      "raw": "T-24B11HS615 23A15 (VDN) GDROOM, LANGULAB"
    },
    {
      "id": "btech_6_THU_8_ufr4rk",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "24B1WHS632",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "AKS",
      "room": "CR7",
      "raw": "L-24B1WHS632 ALL BRANCHES (AKS) CR7"
    },
    {
      "id": "btech_6_THU_1_vs6fy9",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI644",
      "batches": [
        "PCC-23K11"
      ],
      "faculty": "RMS",
      "room": "TR5",
      "raw": "L-25B1WCI644 PCC-23K11 (RMS) TR5"
    },
    {
      "id": "btech_6_THU_2_j2b4jn",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A15"
      ],
      "faculty": "PTK",
      "room": "CL6",
      "raw": "P-18B1WCI675 23A15 (PTK) CL6"
    },
    {
      "id": "btech_6_THU_3_kf9pcs",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A15"
      ],
      "faculty": "PTK",
      "room": "CL6",
      "raw": "P-18B1WCI674 23A15 (PTK) CL6"
    },
    {
      "id": "btech_6_THU_5_8803pl",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23J11",
        "23BM11"
      ],
      "faculty": "RMS",
      "room": "CL7",
      "raw": "P-18B17CI672 23J11, 23BM11 (RMS) CL7"
    },
    {
      "id": "btech_6_THU_6_einfxm",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23J11",
        "23BM11"
      ],
      "faculty": "RMS",
      "room": "CL7",
      "raw": "P-18B17CI672 23J11, 23BM11 (RMS) CL7"
    },
    {
      "id": "btech_6_THU_7_972q5x",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "PKR",
      "room": "CR8",
      "raw": "L-18B11CI612 23A11,23A12,23A13 (PKR) CR8"
    },
    {
      "id": "btech_6_THU_8_hnlwcw",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "20B1WHS631",
      "batches": [
        "ALL",
        "BRANCHES"
      ],
      "faculty": "ANU",
      "room": "CR1",
      "raw": "L-20B1WHS631 ALL BRANCHES (ANU) CR1"
    },
    {
      "id": "btech_6_THU_0_f4704s",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25BB1HS611",
      "batches": [
        "23W11"
      ],
      "faculty": "TNS",
      "room": "TR6",
      "raw": "L-25BB1HS611 23W11 (TNS) TR6"
    },
    {
      "id": "btech_6_THU_1_i2h5xr",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI643",
      "batches": [
        "23J11",
        "23J12"
      ],
      "faculty": "PKR",
      "room": "CR7",
      "raw": "L-25B1WCI643 23J11,23J12 (PKR) CR7"
    },
    {
      "id": "btech_6_THU_2_hdakbl",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "RKB",
      "room": "LT2",
      "raw": "L-24B11HS612 23A11,23A12,23A13 (RKB) LT2"
    },
    {
      "id": "btech_6_THU_7_dx2qr8",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI613",
      "batches": [
        "23C11",
        "MIT",
        "23F11"
      ],
      "faculty": "EGA",
      "room": "TR5",
      "raw": "L-18B11CI613 23C11, MIT, 23F11 (EGA) TR5"
    },
    {
      "id": "btech_6_THU_1_ovuim9",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCE631",
      "batches": [
        "23D11"
      ],
      "faculty": "CPG",
      "room": "TR9",
      "raw": "L-18B1WCE631 23D11 (CPG) TR9"
    },
    {
      "id": "btech_6_THU_2_jlmwx2",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI642",
      "batches": [
        "23J11",
        "23J12"
      ],
      "faculty": "NSA",
      "room": "CR17",
      "raw": "L-25B1WCI642 23J11, 23J12 (NSA) CR17"
    },
    {
      "id": "btech_6_THU_3_v1qagu",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25BBWHS631",
      "batches": [
        "23W11"
      ],
      "faculty": "ABC",
      "room": "CR19",
      "raw": "L-25BBWHS631 23W11 (ABC) CR19"
    },
    {
      "id": "btech_6_THU_5_39305x",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A11"
      ],
      "faculty": "EGA",
      "room": "CL1",
      "raw": "P-18B1WCI674 23A11 (EGA) CL1"
    },
    {
      "id": "btech_6_THU_6_enl1po",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A11"
      ],
      "faculty": "EGA",
      "room": "CL1",
      "raw": "P-18B1WCI674 23A11 (EGA) CL1"
    },
    {
      "id": "btech_6_THU_1_cintrw",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25BBWHS633",
      "batches": [
        "23W11"
      ],
      "faculty": "VDN",
      "room": "CR18",
      "raw": "L-25BBWHS633 23W11 (VDN) CR18"
    },
    {
      "id": "btech_6_THU_5_84wrrf",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "NTS",
      "room": "CR1/ DLC",
      "raw": "L-18B11CI611 23A14,23A15,23A16 (NTS) CR1/ DLC"
    },
    {
      "id": "btech_6_THU_6_qimszj",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A19"
      ],
      "faculty": "MGN",
      "room": "CL9_2",
      "raw": "P-18B1WCI675 23A19 (MGN) CL9_2"
    },
    {
      "id": "btech_6_THU_7_k8pxss",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A19"
      ],
      "faculty": "MGN",
      "room": "CL9_2",
      "raw": "P-18B1WCI675 23A19 (MGN) CL9_2"
    },
    {
      "id": "btech_6_THU_3_c4gpvd",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "23C11",
        "23BM11",
        "23F11"
      ],
      "faculty": "GVN",
      "room": "LT3",
      "raw": "L-18B11CI611 23I11,23I12,23J11,23J12,23K11, 23C11, 23BM11, 23F11 (GVN) LT3"
    },
    {
      "id": "btech_6_THU_5_dkanwg",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23C11",
        "23B11",
        "23H11",
        "23D11"
      ],
      "faculty": "ABC",
      "room": "GDROOM, LANGULAB",
      "raw": "T-24B11HS615 23C11, 23B11, 23H11, 23D11 (ABC) GDROOM, LANGULAB"
    },
    {
      "id": "btech_6_THU_0_hpnq55",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23C11",
        "23F11"
      ],
      "faculty": "SKP",
      "room": "CL3_2",
      "raw": "P-18B1WCI674 23C11, 23F11 (SKP) CL3_2"
    },
    {
      "id": "btech_6_THU_1_2fnmc7",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23C11",
        "23F11"
      ],
      "faculty": "SKP",
      "room": "CL3_2",
      "raw": "P-18B1WCI674 23C11, 23F11 (SKP) CL3_2"
    },
    {
      "id": "btech_6_THU_5_y8pw0w",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25BB1HS611",
      "batches": [
        "23W11"
      ],
      "faculty": "TNS",
      "room": "TR3",
      "raw": "L-25BB1HS611 23W11 (TNS) TR3"
    },
    {
      "id": "btech_6_THU_6_is0ifh",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "NKR",
      "room": "CR10",
      "raw": "L-18B11CI612 23A14,23A15,23A16 (NKR) CR10"
    },
    {
      "id": "btech_6_THU_7_w6ltvr",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI641",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "VSG",
      "room": "CR6",
      "raw": "L-25B1WCI641 23I11, 23I12 (VSG) CR6"
    },
    {
      "id": "btech_6_THU_2_rc4bud",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A14"
      ],
      "faculty": "DLR",
      "room": "GDROOM, LANGULAB",
      "raw": "T-24B11HS615 23A14 (DLR) GDROOM, LANGULAB"
    },
    {
      "id": "btech_6_THU_3_y9vq5y",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCE639",
      "batches": [
        "23D11"
      ],
      "faculty": "ASR",
      "room": "CR15",
      "raw": "L-18B1WCE639 23D11 (ASR) CR15"
    },
    {
      "id": "btech_6_THU_4_1kfoqm",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A17"
      ],
      "faculty": "MGN",
      "room": "CL11",
      "raw": "P-18B1WCI675 23A17 (MGN) CL11"
    },
    {
      "id": "btech_6_THU_5_fsakli",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23A17"
      ],
      "faculty": "MGN",
      "room": "CL11",
      "raw": "P-18B1WCI675 23A17 (MGN) CL11"
    },
    {
      "id": "btech_6_THU_3_j7tkn8",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BT611",
      "batches": [
        "23E11."
      ],
      "faculty": "SBS",
      "room": "CR18",
      "raw": "L-18B11BT611 23E11. (SBS) CR18"
    },
    {
      "id": "btech_6_THU_5_sztvfs",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBT633",
      "batches": [
        "23E11."
      ],
      "faculty": "ABH",
      "room": "TR1",
      "raw": "L-18B1WBT633 23E11. (ABH) TR1"
    },
    {
      "id": "btech_6_THU_7_13g23z",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI645",
      "batches": [
        "23K11"
      ],
      "faculty": "NTS",
      "room": "TR7",
      "raw": "L-25B1WCI645 23K11 (NTS) TR7"
    },
    {
      "id": "btech_6_THU_2_mj98ip",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A18"
      ],
      "faculty": "SRJ",
      "room": "CL10",
      "raw": "P-24B17CI671 23A18 (SRJ) CL10"
    },
    {
      "id": "btech_6_THU_3_vtxnhz",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A18"
      ],
      "faculty": "SRJ",
      "room": "CL10",
      "raw": "P-24B17CI671 23A18 (SRJ) CL10"
    },
    {
      "id": "btech_6_THU_6_1vj56a",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A17"
      ],
      "faculty": "SKP",
      "room": "CL3_1",
      "raw": "P-18B1WCI674 23A17 (SKP) CL3_1"
    },
    {
      "id": "btech_6_THU_7_bg88wy",
      "semesterId": "btech_6",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A17"
      ],
      "faculty": "SKP",
      "room": "CL3_1",
      "raw": "P-18B1WCI674 23A17 (SKP) CL3_1"
    },
    {
      "id": "btech_6_FRI_6_n5uf1r",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "25BBWHS634",
      "batches": [
        "23W11"
      ],
      "faculty": "TNS",
      "room": "CR19",
      "raw": "L-25BBWHS634 23W11 (TNS) CR19"
    },
    {
      "id": "btech_6_FRI_1_5ofs08",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "NTS",
      "room": "CR8",
      "raw": "L-18B11CI611 23A14,23A15,23A16 (NTS) CR8"
    },
    {
      "id": "btech_6_FRI_2_4lc87s",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17BT672",
      "batches": [
        "23E11"
      ],
      "faculty": "GPL",
      "room": "UG1",
      "raw": "P-18B17BT672 23E11, (GPL) UG1"
    },
    {
      "id": "btech_6_FRI_3_r18iyq",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17BT672",
      "batches": [
        "23E11"
      ],
      "faculty": "GPL",
      "room": "UG1",
      "raw": "P-18B17BT672 23E11, (GPL) UG1"
    },
    {
      "id": "btech_6_FRI_6_gbz3di",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBT633",
      "batches": [
        "23E11."
      ],
      "faculty": "ABH",
      "room": "TR5",
      "raw": "L-18B1WBT633 23E11. (ABH) TR5"
    },
    {
      "id": "btech_6_FRI_0_rzp2o2",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI634",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "KLK",
      "room": "CR7",
      "raw": "L-18B1WCI634 23A14,23A15,23A16 (KLK) CR7"
    },
    {
      "id": "btech_6_FRI_1_ogsopj",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B11CI611",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "SRJ",
      "room": "CR9/ DLC",
      "raw": "L-18B11CI611 23A17,23A18,23A19 (SRJ) CR9/ DLC"
    },
    {
      "id": "btech_6_FRI_2_fbbtp3",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23J11",
        "23BM11"
      ],
      "faculty": "RIV",
      "room": "BIL",
      "raw": "P-18B17CI671 23J11, 23BM11 (RIV) BIL"
    },
    {
      "id": "btech_6_FRI_3_y5xhnx",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23J11",
        "23BM11"
      ],
      "faculty": "RIV",
      "room": "BIL",
      "raw": "P-18B17CI671 23J11, 23BM11 (RIV) BIL"
    },
    {
      "id": "btech_6_FRI_5_t8gta9",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11EC611",
      "batches": [
        "23B11",
        "23A11",
        "23A14"
      ],
      "faculty": "SWT",
      "room": "TR1",
      "raw": "L-18B11EC611 23B11, 23A11, 23A14 (SWT) TR1"
    },
    {
      "id": "btech_6_FRI_6_thx8tu",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A13"
      ],
      "faculty": "PKR",
      "room": "CL8_2",
      "raw": "P-24B17CI671 23A13 (PKR) CL8_2"
    },
    {
      "id": "btech_6_FRI_7_e3i4q7",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A13"
      ],
      "faculty": "PKR",
      "room": "CL8_2",
      "raw": "P-24B17CI671 23A13 (PKR) CL8_2"
    },
    {
      "id": "btech_6_FRI_0_sk0ql3",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B11BI612",
      "batches": [
        "23F11"
      ],
      "faculty": "RJK",
      "room": "CR16",
      "raw": "L-18B11BI612 23F11 (RJK) CR16"
    },
    {
      "id": "btech_6_FRI_2_9af97z",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI635",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "PTK",
      "room": "LT3",
      "raw": "L-18B1WCI635 23A14,23A15,23A16 (PTK) LT3"
    },
    {
      "id": "btech_6_FRI_4_bsf1yd",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBI631",
      "batches": [
        "23F11"
      ],
      "faculty": "TTS",
      "room": "CR16",
      "raw": "L-18B1WBI631 23F11 (TTS) CR16"
    },
    {
      "id": "btech_6_FRI_5_cb47dd",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Tutorial",
      "courseCode": "25BB1HS612",
      "batches": [
        "23W11"
      ],
      "faculty": "VDN",
      "room": "CR19",
      "raw": "T-25BB1HS612 23W11 (VDN) CR19"
    },
    {
      "id": "btech_6_FRI_7_yi6yc5",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BT611",
      "batches": [
        "23E11"
      ],
      "faculty": "SBS",
      "room": "TR5",
      "raw": "L-18B11BT611 23E11 (SBS) TR5"
    },
    {
      "id": "btech_6_FRI_5_mi75w5",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "SMA",
      "room": "CR2",
      "raw": "L-18B11CI612 23A17,23A18,23A19 (SMA) CR2"
    },
    {
      "id": "btech_6_FRI_7_6bs8nj",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25BBWHS633",
      "batches": [
        "23W11"
      ],
      "faculty": "VDN",
      "room": "CR19",
      "raw": "T-25BBWHS633 23W11 (VDN) CR19"
    },
    {
      "id": "btech_6_FRI_0_n0sewg",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI635",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "MGN",
      "room": "CR2",
      "raw": "L-18B1WCI635 23A17,23A18,23A19 (MGN) CR2"
    },
    {
      "id": "btech_6_FRI_1_pi4v3x",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCE639",
      "batches": [
        "23D11"
      ],
      "faculty": "ASR",
      "room": "CR14",
      "raw": "L-18B1WCE639 23D11 (ASR) CR14"
    },
    {
      "id": "btech_6_FRI_2_khie59",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25B1WCI645",
      "batches": [
        "23K11"
      ],
      "faculty": "NTS",
      "room": "CR6",
      "raw": "L-25B1WCI645 23K11 (NTS) CR6"
    },
    {
      "id": "btech_6_FRI_6_t79znz",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A18"
      ],
      "faculty": "SMA",
      "room": "CL8_1",
      "raw": "P-18B17CI672  23A18 (SMA) CL8_1"
    },
    {
      "id": "btech_6_FRI_7_mrurlr",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23A18"
      ],
      "faculty": "SMA",
      "room": "CL8_1",
      "raw": "P-18B17CI672  23A18 (SMA) CL8_1"
    },
    {
      "id": "btech_6_FRI_0_7yj43j",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17EC672",
      "batches": [
        "23B11"
      ],
      "faculty": "HSL",
      "room": "CL1",
      "raw": "P-18B17EC672 23B11 (HSL) CL1"
    },
    {
      "id": "btech_6_FRI_1_tcq5wl",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17EC672",
      "batches": [
        "23B11"
      ],
      "faculty": "HSL",
      "room": "CL1",
      "raw": "P-18B17EC672 23B11 (HSL) CL1"
    },
    {
      "id": "btech_6_FRI_3_rkb8q4",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WEC744",
      "batches": [
        "23B11",
        "23H11"
      ],
      "faculty": "HSL",
      "room": "CR17",
      "raw": "L-18B1WEC744 23B11,23H11 (HSL) CR17"
    },
    {
      "id": "btech_6_FRI_5_38p8zl",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B11BI611/",
      "batches": [
        "18B1WCI634",
        "23I11",
        "23I12",
        "23J11",
        "23J12",
        "23K11",
        "23C11",
        "23BM11",
        "23F11"
      ],
      "faculty": "SKP",
      "room": "LT2",
      "raw": "L-18B11BI611/  18B1WCI634 23I11,23I12,23J11,23J12,23K11,23C11, 23BM11, 23F11 (SKP) LT2"
    },
    {
      "id": "btech_6_FRI_7_fvke03",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI612",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "NKR",
      "room": "CR7",
      "raw": "L-18B11CI612 23A14,23A15,23A16 (NKR) CR7"
    },
    {
      "id": "btech_6_FRI_2_kma304",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Tutorial",
      "courseCode": "18B11EC612",
      "batches": [
        "23B11"
      ],
      "faculty": "SHR",
      "room": "ECL5",
      "raw": "T-18B11EC612 23B11 (SHR) ECL5"
    },
    {
      "id": "btech_6_FRI_6_s6nks6",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23J11"
      ],
      "faculty": "VSG",
      "room": "CL5_1",
      "raw": "P-18B1WCI674 23J11, (VSG) CL5_1"
    },
    {
      "id": "btech_6_FRI_7_cr8ia1",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23J11"
      ],
      "faculty": "VSG",
      "room": "CL5_1",
      "raw": "P-18B1WCI674 23J11, (VSG) CL5_1"
    },
    {
      "id": "btech_6_FRI_0_jr14k3",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23J11"
      ],
      "faculty": "ABC",
      "room": "TR5",
      "raw": "T-24B11HS615 23J11 (ABC) TR5"
    },
    {
      "id": "btech_6_FRI_2_us4l6v",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI635",
      "batches": [
        "23A11",
        "23A12",
        "23A13"
      ],
      "faculty": "EGA",
      "room": "CR10",
      "raw": "L-18B1WCI635 23A11,23A12,23A13 (EGA) CR10"
    },
    {
      "id": "btech_6_FRI_5_cgy38z",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBT633",
      "batches": [
        "23E11."
      ],
      "faculty": "ABH",
      "room": "TR4",
      "raw": "L-18B1WBT633 23E11. (ABH) TR4"
    },
    {
      "id": "btech_6_FRI_6_fxy154",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23A14",
        "23A15",
        "23A16"
      ],
      "faculty": "PKP",
      "room": "DLC,CR8",
      "raw": "L-24B11HS612 23A14,23A15,23A16 (PKP) DLC,CR8"
    },
    {
      "id": "btech_6_FRI_7_w9fzvj",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WEC632",
      "batches": [
        "23B11"
      ],
      "faculty": "RKU",
      "room": "TR4",
      "raw": "L-18B1WEC632 23B11 (RKU) TR4"
    },
    {
      "id": "btech_6_FRI_1_slrmbb",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "24B11HS615",
      "batches": [
        "23A13"
      ],
      "faculty": "DLR",
      "room": "GDROOM, LANGULAB",
      "raw": "T-24B11HS615 23A13 (DLR) GDROOM, LANGULAB"
    },
    {
      "id": "btech_6_FRI_2_805f0k",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "24B11HS612",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "RAD",
      "room": "CR5",
      "raw": "L-24B11HS612 23A17,23A18,23A19 (RAD) CR5"
    },
    {
      "id": "btech_6_FRI_4_c31f78",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI644",
      "batches": [
        "PCC-23K11"
      ],
      "faculty": "RMS",
      "room": "CR10",
      "raw": "L-25B1WCI644 PCC-23K11 (RMS) CR10"
    },
    {
      "id": "btech_6_FRI_5_rsc7g2",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23B11CE611",
      "batches": [],
      "faculty": "",
      "room": "23B11CE611",
      "raw": "L-23B11CE611"
    },
    {
      "id": "btech_6_FRI_5_a6mnoj",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "23D11",
      "batches": [],
      "faculty": "NJP",
      "room": "CR15",
      "raw": "23D11 (NJP) CR15"
    },
    {
      "id": "btech_6_FRI_0_kncrt2",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24B11HS412",
      "batches": [
        "23W11"
      ],
      "faculty": "ASA",
      "room": "TR1",
      "raw": "L-24B11HS412 23W11 (ASA) TR1"
    },
    {
      "id": "btech_6_FRI_2_9cr0yg",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "RMS",
      "room": "CL7",
      "raw": "P-24B17CI671 23I11,23I12 (RMS) CL7"
    },
    {
      "id": "btech_6_FRI_3_p7zcp7",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23I11",
        "23I12"
      ],
      "faculty": "RMS",
      "room": "CL7",
      "raw": "P-24B17CI671 23I11,23I12 (RMS) CL7"
    },
    {
      "id": "btech_6_FRI_7_62cmxv",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B11CI613",
      "batches": [
        "23C11",
        "MIT",
        "23F11"
      ],
      "faculty": "EGA",
      "room": "CR16",
      "raw": "L-18B11CI613 23C11,MIT, 23F11 (EGA) CR16"
    },
    {
      "id": "btech_6_FRI_1_sicsx1",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17BI673",
      "batches": [
        "23F11"
      ],
      "faculty": "TTS",
      "room": "BPL",
      "raw": "P-18B17BI673 23F11 (TTS) BPL"
    },
    {
      "id": "btech_6_FRI_2_9ftg1q",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17BI673",
      "batches": [
        "23F11"
      ],
      "faculty": "TTS",
      "room": "BPL",
      "raw": "P-18B17BI673 23F11 (TTS) BPL"
    },
    {
      "id": "btech_6_FRI_3_kcjhlg",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25BBWHS631",
      "batches": [
        "23W11"
      ],
      "faculty": "ABC",
      "room": "CR18",
      "raw": "L-25BBWHS631 23W11 (ABC) CR18"
    },
    {
      "id": "btech_6_FRI_4_nki8kr",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A15"
      ],
      "faculty": "NTS",
      "room": "CL1",
      "raw": "P-18B17CI671 23A15 (NTS) CL1"
    },
    {
      "id": "btech_6_FRI_5_w22kwl",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A15"
      ],
      "faculty": "NTS",
      "room": "CL1",
      "raw": "P-18B17CI671 23A15 (NTS) CL1"
    },
    {
      "id": "btech_6_FRI_6_yad6ng",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A11"
      ],
      "faculty": "KLK",
      "room": "CL3_1",
      "raw": "P-18B1WCI674 23A11 (KLK) CL3_1"
    },
    {
      "id": "btech_6_FRI_7_yz8y27",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI674",
      "batches": [
        "23A11"
      ],
      "faculty": "KLK",
      "room": "CL3_1",
      "raw": "P-18B1WCI674 23A11 (KLK) CL3_1"
    },
    {
      "id": "btech_6_FRI_0_4pgvjt",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23J12",
        "23K11",
        "[29"
      ],
      "faculty": "RMS",
      "room": "CL4",
      "raw": "P-18B17CI672 23J12,23K11 [29] (RMS) CL4"
    },
    {
      "id": "btech_6_FRI_1_ahtzlr",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23J12",
        "23K11",
        "[29"
      ],
      "faculty": "RMS",
      "room": "CL4",
      "raw": "P-18B17CI672 23J12,23K11 [29] (RMS) CL4"
    },
    {
      "id": "btech_6_FRI_2_ljy5m6",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25BB1HS612",
      "batches": [
        "23W11"
      ],
      "faculty": "VDN",
      "room": "TR1",
      "raw": "L-25BB1HS612 23W11 (VDN) TR1"
    },
    {
      "id": "btech_6_FRI_3_nfknrm",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCI634",
      "batches": [
        "23A17",
        "23A18",
        "23A19"
      ],
      "faculty": "SKP",
      "room": "CR1",
      "raw": "L-18B1WCI634 23A17,23A18,23A19 (SKP) CR1"
    },
    {
      "id": "btech_6_FRI_6_jzp7cf",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23J12",
        "23K11",
        "23BM11"
      ],
      "faculty": "FSL",
      "room": "CL7",
      "raw": "P-18B1WCI675 23J12,23K11,23BM11 (FSL) CL7"
    },
    {
      "id": "btech_6_FRI_7_q15b62",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B1WCI675",
      "batches": [
        "23J12",
        "23K11",
        "23BM11"
      ],
      "faculty": "FSL",
      "room": "CL7",
      "raw": "P-18B1WCI675 23J12,23K11,23BM11 (FSL) CL7"
    },
    {
      "id": "btech_6_FRI_0_qzqqqb",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "20B1WCI572",
      "batches": [
        "23C11"
      ],
      "faculty": "NKR",
      "room": "CL5_1",
      "raw": "P-20B1WCI572 23C11 (NKR) CL5_1"
    },
    {
      "id": "btech_6_FRI_1_1kxbtj",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "20B1WCI572",
      "batches": [
        "23C11"
      ],
      "faculty": "NKR",
      "room": "CL5_1",
      "raw": "P-20B1WCI572 23C11 (NKR) CL5_1"
    },
    {
      "id": "btech_6_FRI_7_ytaate",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCE634",
      "batches": [
        "23D11"
      ],
      "faculty": "ADP",
      "room": "CR15",
      "raw": "L-18B1WCE634 23D11 (ADP) CR15"
    },
    {
      "id": "btech_6_FRI_1_y4t4zv",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Tutorial",
      "courseCode": "25BB1HS611",
      "batches": [
        "23W11"
      ],
      "faculty": "TNS",
      "room": "TR7",
      "raw": "T-25BB1HS611 23W11 (TNS) TR7"
    },
    {
      "id": "btech_6_FRI_4_zsfqxx",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A12"
      ],
      "faculty": "HRI",
      "room": "CL4",
      "raw": "P-18B17CI671 23A12 (HRI) CL4"
    },
    {
      "id": "btech_6_FRI_5_ekwhcj",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23A12"
      ],
      "faculty": "HRI",
      "room": "CL4",
      "raw": "P-18B17CI671 23A12 (HRI) CL4"
    },
    {
      "id": "btech_6_FRI_4_p1b5pc",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A16"
      ],
      "faculty": "NKR",
      "room": "BIL",
      "raw": "P-24B17CI671 23A16 (NKR) BIL"
    },
    {
      "id": "btech_6_FRI_5_vizjvv",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI671",
      "batches": [
        "23A16"
      ],
      "faculty": "NKR",
      "room": "BIL",
      "raw": "P-24B17CI671 23A16 (NKR) BIL"
    },
    {
      "id": "btech_6_FRI_6_1jpa3a",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23I11",
        "23I12",
        "[37"
      ],
      "faculty": "RMS",
      "room": "CL4",
      "raw": "P-18B17CI672 23I11, 23I12 [37] (RMS) CL4"
    },
    {
      "id": "btech_6_FRI_7_4b0hkv",
      "semesterId": "btech_6",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI672",
      "batches": [
        "23I11",
        "23I12",
        "[37"
      ],
      "faculty": "RMS",
      "room": "CL4",
      "raw": "P-18B17CI672 23I11, 23I12 [37] (RMS) CL4"
    },
    {
      "id": "btech_6_SAT_1_78e4ni",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25BBWHS634",
      "batches": [
        "23W11"
      ],
      "faculty": "TNS",
      "room": "TR5",
      "raw": "L-25BBWHS634 23W11 (TNS) TR5"
    },
    {
      "id": "btech_6_SAT_2_e4w8q3",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CE671",
      "batches": [
        "23D11"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-18B17CE671 23D11 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_6_SAT_3_5xnv7r",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18B17CE671",
      "batches": [
        "23D11"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-18B17CE671 23D11 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_6_SAT_3_hafs2r",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25BB1HS611",
      "batches": [
        "23W11"
      ],
      "faculty": "TNS",
      "room": "TR3",
      "raw": "L-25BB1HS611 23W11 (TNS) TR3"
    },
    {
      "id": "btech_6_SAT_0_t5nwnc",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17BI674",
      "batches": [
        "23F11"
      ],
      "faculty": "SML",
      "room": "BIL",
      "raw": "P-18B17BI674 23F11 (SML) BIL"
    },
    {
      "id": "btech_6_SAT_1_2yfip5",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17BI674",
      "batches": [
        "23F11"
      ],
      "faculty": "SML",
      "room": "BIL",
      "raw": "P-18B17BI674 23F11 (SML) BIL"
    },
    {
      "id": "btech_6_SAT_0_d7tdti",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23J12",
        "23K11"
      ],
      "faculty": "GVN",
      "room": "CL6",
      "raw": "P-18B17CI671 23J12,23K11 (GVN) CL6"
    },
    {
      "id": "btech_6_SAT_1_v8zzym",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CI671",
      "batches": [
        "23J12",
        "23K11"
      ],
      "faculty": "GVN",
      "room": "CL6",
      "raw": "P-18B17CI671 23J12,23K11 (GVN) CL6"
    },
    {
      "id": "btech_6_SAT_2_2b990i",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B11EC611",
      "batches": [
        "23B11",
        "23A11",
        "23A14"
      ],
      "faculty": "SWT",
      "room": "TR4",
      "raw": "L-18B11EC611 23B11, 23A11, 23A14 (SWT) TR4"
    },
    {
      "id": "btech_6_SAT_3_tiu1ll",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WEC744",
      "batches": [
        "23B11"
      ],
      "faculty": "HSL",
      "room": "CR17",
      "raw": "L-18B1WEC744 23B11 (HSL) CR17"
    },
    {
      "id": "btech_6_SAT_2_f259ej",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI571",
      "batches": [
        "23F11",
        "23E11."
      ],
      "faculty": "PDN",
      "room": "CL4",
      "raw": "P-24B17CI571 23F11,  23E11. (PDN) CL4"
    },
    {
      "id": "btech_6_SAT_3_19b1d5",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "24B17CI571",
      "batches": [
        "23F11",
        "23E11."
      ],
      "faculty": "PDN",
      "room": "CL4",
      "raw": "P-24B17CI571 23F11,  23E11. (PDN) CL4"
    },
    {
      "id": "btech_6_SAT_0_qoa88x",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Tutorial",
      "courseCode": "25BBWHS634",
      "batches": [
        "23W11"
      ],
      "faculty": "TNS",
      "room": "TR1",
      "raw": "T-25BBWHS634 23W11 (TNS) TR1"
    },
    {
      "id": "btech_6_SAT_0_yw2v3v",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17EC673",
      "batches": [
        "23B11",
        "23A11",
        "23A14"
      ],
      "faculty": "SWT",
      "room": "CL1",
      "raw": "P-18B17EC673 23B11, 23A11, 23A14 (SWT) CL1"
    },
    {
      "id": "btech_6_SAT_1_8xuvri",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17EC673",
      "batches": [
        "23B11",
        "23A11",
        "23A14"
      ],
      "faculty": "SWT",
      "room": "CL1",
      "raw": "P-18B17EC673 23B11, 23A11, 23A14 (SWT) CL1"
    },
    {
      "id": "btech_6_SAT_0_x84o91",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CE671",
      "batches": [
        "23D11"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-18B17CE671 23D11 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_6_SAT_1_323phu",
      "semesterId": "btech_6",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18B17CE671",
      "batches": [
        "23D11"
      ],
      "faculty": "TNM",
      "room": "DRAWR,CAD",
      "raw": "P-18B17CE671 23D11 (TNM) DRAWR,CAD"
    },
    {
      "id": "btech_8_MON_1_bsml0t",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI832",
      "batches": [
        "CS-IT[PML]_E4"
      ],
      "faculty": "VSG",
      "room": "DLC,CR12",
      "raw": "L-19B1WCI832    CS-IT[PML]_E4 (VSG) DLC,CR12"
    },
    {
      "id": "btech_8_MON_5_pk7l36",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCE831",
      "batches": [
        "CE81"
      ],
      "faculty": "KKR",
      "room": "TR9",
      "raw": "L-18B1WCE831  CE81  (KKR) TR9"
    },
    {
      "id": "btech_8_MON_2_grk9k3",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI837/25B1WCI640",
      "batches": [
        "CS-IT[PAI]_E4",
        "SEM6_PCC_23I11_23I12"
      ],
      "faculty": "SKS",
      "room": "CR10",
      "raw": "L-19B1WCI837/25B1WCI640   CS-IT[PAI]_E4,SEM6_PCC_23I11_23I12 (SKS) CR10"
    },
    {
      "id": "btech_8_MON_4_3bttiu",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WCE831",
      "batches": [
        "CEALL_1_BAS_1"
      ],
      "faculty": "SUV",
      "room": "CR7",
      "raw": "L-21B1WCE831   CEALL_1_BAS_1 (SUV) CR7"
    },
    {
      "id": "btech_8_MON_3_qgp25l",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WEC837",
      "batches": [
        "EC_E6",
        "EM81"
      ],
      "faculty": "PRG",
      "room": "CR16",
      "raw": "L-19B1WEC837   EC_E6,EM81 (PRG) CR16"
    },
    {
      "id": "btech_8_MON_6_9hn565",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B7WEC872",
      "batches": [
        "ECEALL_3_BAS_2_B1_LAB"
      ],
      "faculty": "VKB",
      "room": "ECL7",
      "raw": "P-25B7WEC872   ECEALL_3_BAS_2_B1_LAB (VKB) ECL7"
    },
    {
      "id": "btech_8_MON_7_2eelac",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B7WEC872",
      "batches": [
        "ECEALL_3_BAS_2_B1_LAB"
      ],
      "faculty": "VKB",
      "room": "ECL7",
      "raw": "P-25B7WEC872   ECEALL_3_BAS_2_B1_LAB (VKB) ECL7"
    },
    {
      "id": "btech_8_MON_8_g1g83n",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "24B1WCE631",
      "batches": [
        "ESE_Y3_Y4"
      ],
      "faculty": "NJP,RRA,ASA,ANU",
      "room": "CR7",
      "raw": "L-24B1WCE631 ESE_Y3_Y4 (NJP,RRA,ASA,ANU) CR7"
    },
    {
      "id": "btech_8_MON_1_bchexk",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBT831",
      "batches": [
        "BT81",
        "BI81"
      ],
      "faculty": "SDS",
      "room": "CR18",
      "raw": "L-18B1WBT831  BT81,BI81  (SDS) CR18"
    },
    {
      "id": "btech_8_MON_4_smnwqe",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WPH732",
      "batches": [
        "PMSALL_2_BAS_1"
      ],
      "faculty": "SKK",
      "room": "CR5",
      "raw": "L-18B1WPH732 PMSALL_2_BAS_1 (SKK) CR5"
    },
    {
      "id": "btech_8_MON_7_7cw3xq",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WBT833",
      "batches": [
        "BIOALL_BAS_2"
      ],
      "faculty": "RJK",
      "room": "CR16",
      "raw": "L-21B1WBT833 BIOALL_BAS_2 (RJK) CR16"
    },
    {
      "id": "btech_8_MON_2_o645c5",
      "semesterId": "btech_8",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBT833",
      "batches": [
        "BT81",
        "BI81"
      ],
      "faculty": "RST",
      "room": "CR19",
      "raw": "L-18B1WBT833 BT81,BI81 (RST) CR19"
    },
    {
      "id": "btech_8_TUE_7_yrszoi",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WMA831",
      "batches": [
        "MAALL_BAS_2"
      ],
      "faculty": "BKP",
      "room": "CR6",
      "raw": "L-21B1WMA831  MAALL_BAS_2  (BKP) CR6"
    },
    {
      "id": "btech_8_TUE_0_c1vn7x",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WEC843",
      "batches": [
        "ECALL_5_BAS_2"
      ],
      "faculty": "MSD",
      "room": "CR5",
      "raw": "L-18B1WEC843 ECALL_5_BAS_2 (MSD) CR5"
    },
    {
      "id": "btech_8_TUE_1_ha2uog",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI832",
      "batches": [
        "CS-IT[PDS]_E4"
      ],
      "faculty": "SMA",
      "room": "CR1",
      "raw": "L-18B1WCI832    CS-IT[PDS]_E4 (SMA) CR1"
    },
    {
      "id": "btech_8_TUE_5_739w5y",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBI831",
      "batches": [
        "BI81"
      ],
      "faculty": "TTS",
      "room": "CR19",
      "raw": "L-18B1WBI831  BI81  (TTS) CR19"
    },
    {
      "id": "btech_8_TUE_7_thy702",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCE834",
      "batches": [
        "CEALL_2_BAS_2"
      ],
      "faculty": "ABJ",
      "room": "CR5",
      "raw": "L-18B1WCE834   CEALL_2_BAS_2 (ABJ) CR5"
    },
    {
      "id": "btech_8_TUE_5_gzmf9c",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WCI835",
      "batches": [
        "CS-IT[PCC]_E4_B1"
      ],
      "faculty": "NKR",
      "room": "CR4",
      "raw": "L-19B1WCI835    CS-IT[PCC]_E4_B1 (NKR) CR4"
    },
    {
      "id": "btech_8_TUE_6_0vpu6o",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WCI831",
      "batches": [
        "CS-IT[PIS]_E4"
      ],
      "faculty": "RIV",
      "room": "CR10",
      "raw": "L-19B1WCI831    CS-IT[PIS]_E4 (RIV) CR10"
    },
    {
      "id": "btech_8_TUE_1_6vd51h",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "21B1WBT831",
      "batches": [
        "BT81"
      ],
      "faculty": "AKT",
      "room": "CR19",
      "raw": "L-21B1WBT831  BT81 (AKT) CR19"
    },
    {
      "id": "btech_8_TUE_4_ypoj1m",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WEC831",
      "batches": [
        "ECALL_4_BAS_1"
      ],
      "faculty": "SRU",
      "room": "CR5",
      "raw": "L-25B1WEC831  ECALL_4_BAS_1 (SRU) CR5"
    },
    {
      "id": "btech_8_TUE_5_ec8h4g",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WCI835",
      "batches": [
        "CS-IT[PCC]_E4_B2"
      ],
      "faculty": "PDN",
      "room": "CR5",
      "raw": "L-19B1WCI835    CS-IT[PCC]_E4_B2 (PDN) CR5"
    },
    {
      "id": "btech_8_TUE_2_gukfm6",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBI834",
      "batches": [
        "BI81",
        "[BT81"
      ],
      "faculty": "SML",
      "room": "CR19",
      "raw": "L-18B1WBI834 BI81,[BT81] (SML) CR19"
    },
    {
      "id": "btech_8_TUE_6_9fb2n0",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBI834",
      "batches": [
        "BI81",
        "[BT81"
      ],
      "faculty": "SML",
      "room": "CR18",
      "raw": "L-18B1WBI834 BI81,[BT81] (SML) CR18"
    },
    {
      "id": "btech_8_TUE_4_9qpmxn",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WPH831",
      "batches": [
        "PMSALL_3_BAS_1"
      ],
      "faculty": "RRS",
      "room": "CR6",
      "raw": "L-21B1WPH831  PMSALL_3_BAS_1 (RRS) CR6"
    },
    {
      "id": "btech_8_TUE_4_pacxu8",
      "semesterId": "btech_8",
      "day": "TUE",
      "slotIndex": 4,
      "time": "01:00 PM - 01:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WCE831",
      "batches": [
        "CEALL_1_BAS_1"
      ],
      "faculty": "SUV",
      "room": "CR7",
      "raw": "L-21B1WCE831   CEALL_1_BAS_1  (SUV) CR7"
    },
    {
      "id": "btech_8_WED_7_umpzx0",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WPH831",
      "batches": [
        "PMSALL_3_BAS_1"
      ],
      "faculty": "RRS",
      "room": "CR6",
      "raw": "L-21B1WPH831  PMSALL_3_BAS_1 (RRS) CR6"
    },
    {
      "id": "btech_8_WED_1_sc5lx2",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI835",
      "batches": [
        "CS-IT[PCC]_E4_B1"
      ],
      "faculty": "NKR",
      "room": "CR4",
      "raw": "L-19B1WCI835    CS-IT[PCC]_E4_B1 (NKR) CR4"
    },
    {
      "id": "btech_8_WED_6_7jq1m5",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCE834",
      "batches": [
        "CEALL_2_BAS_2"
      ],
      "faculty": "ABJ",
      "room": "CR1",
      "raw": "L-18B1WCE834   CEALL_2_BAS_2 (ABJ) CR1"
    },
    {
      "id": "btech_8_WED_1_ghyrx9",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI835",
      "batches": [
        "CS-IT[PCC]_E4_B2"
      ],
      "faculty": "PDN",
      "room": "CR6",
      "raw": "L-19B1WCI835    CS-IT[PCC]_E4_B2 (PDN) CR6"
    },
    {
      "id": "btech_8_WED_7_v1m7z3",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WPH732",
      "batches": [
        "PMSALL_2_BAS_1"
      ],
      "faculty": "SKK",
      "room": "CR1",
      "raw": "L-18B1WPH732 PMSALL_2_BAS_1 (SKK) CR1"
    },
    {
      "id": "btech_8_WED_8_i5ae5u",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "24B1WCE631",
      "batches": [
        "ESE_Y3_Y4"
      ],
      "faculty": "NJP,RRA,ASA,ANU",
      "room": "CR7",
      "raw": "L-24B1WCE631 ESE_Y3_Y4 (NJP,RRA,ASA,ANU) CR7"
    },
    {
      "id": "btech_8_WED_5_doe8zv",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WCI835",
      "batches": [
        "CS-IT[MCSE]BI81"
      ],
      "faculty": "AYS",
      "room": "TR2",
      "raw": "L-25B1WCI835    CS-IT[MCSE]BI81 (AYS) TR2"
    },
    {
      "id": "btech_8_WED_6_1vwkud",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WMA831",
      "batches": [
        "MAALL_BAS_2"
      ],
      "faculty": "BKP",
      "room": "CR4",
      "raw": "L-21B1WMA831  MAALL_BAS_2  (BKP) CR4"
    },
    {
      "id": "btech_8_WED_1_xjisyz",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCE831",
      "batches": [
        "CE81"
      ],
      "faculty": "KKR",
      "room": "TR9",
      "raw": "L-18B1WCE831  CE81  (KKR) TR9"
    },
    {
      "id": "btech_8_WED_0_gdkmii",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WEC843",
      "batches": [
        "ECALL_5_BAS_2"
      ],
      "faculty": "MSD",
      "room": "CR7",
      "raw": "L-18B1WEC843 ECALL_5_BAS_2 (MSD) CR7"
    },
    {
      "id": "btech_8_WED_1_wso4pj",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBI831",
      "batches": [
        "BI81"
      ],
      "faculty": "TTS",
      "room": "CR19",
      "raw": "L-18B1WBI831  BI81  (TTS) CR19"
    },
    {
      "id": "btech_8_WED_5_8pmicz",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WEC832",
      "batches": [
        "ECEALL_3_BAS_2"
      ],
      "faculty": "VKB",
      "room": "CR11",
      "raw": "L-25B1WEC832   ECEALL_3_BAS_2  (VKB) CR11"
    },
    {
      "id": "btech_8_WED_6_ljijgb",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBI834",
      "batches": [
        "BI81",
        "[BT81"
      ],
      "faculty": "SML",
      "room": "CR18",
      "raw": "L-18B1WBI834 BI81,[BT81] (SML) CR18"
    },
    {
      "id": "btech_8_WED_7_s4o1j3",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WEC831",
      "batches": [
        "ECALL_4_BAS_1"
      ],
      "faculty": "SRU",
      "room": "CR7",
      "raw": "L-25B1WEC831  ECALL_4_BAS_1 (SRU) CR7"
    },
    {
      "id": "btech_8_WED_0_epwu16",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "21B1WBT833",
      "batches": [
        "BIOALL_BAS_2"
      ],
      "faculty": "RJK",
      "room": "CR16",
      "raw": "L-21B1WBT833 BIOALL_BAS_2 (RJK) CR16"
    },
    {
      "id": "btech_8_WED_1_rjaqop",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBT831",
      "batches": [
        "BT81",
        "BI81"
      ],
      "faculty": "SDS",
      "room": "CR16",
      "raw": "L-18B1WBT831  BT81,BI81  (SDS) CR16"
    },
    {
      "id": "btech_8_WED_2_y43a07",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "23B1WHS831",
      "batches": [
        "HSS_ALL_2_BAS_1"
      ],
      "faculty": "AKS",
      "room": "CR10",
      "raw": "L-23B1WHS831  HSS_ALL_2_BAS_1 (AKS) CR10"
    },
    {
      "id": "btech_8_WED_6_sf7iul",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBT833",
      "batches": [
        "BT81",
        "BI81"
      ],
      "faculty": "RST",
      "room": "CR19",
      "raw": "L-18B1WBT833 BT81,BI81 (RST) CR19"
    },
    {
      "id": "btech_8_WED_1_xj4wvg",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI831",
      "batches": [
        "CS-IT[PIS]_E4"
      ],
      "faculty": "RIV",
      "room": "CR10",
      "raw": "L-19B1WCI831    CS-IT[PIS]_E4 (RIV) CR10"
    },
    {
      "id": "btech_8_WED_2_kp51xp",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B7WEC872",
      "batches": [
        "ECEALL_3_BAS_2_B2_LAB"
      ],
      "faculty": "VKB",
      "room": "ECL7",
      "raw": "P-25B7WEC872   ECEALL_3_BAS_2_B2_LAB (VKB) ECL7"
    },
    {
      "id": "btech_8_WED_3_onwy96",
      "semesterId": "btech_8",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B7WEC872",
      "batches": [
        "ECEALL_3_BAS_2_B2_LAB"
      ],
      "faculty": "VKB",
      "room": "ECL7",
      "raw": "P-25B7WEC872   ECEALL_3_BAS_2_B2_LAB (VKB) ECL7"
    },
    {
      "id": "btech_8_THU_1_enwu4o",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI831",
      "batches": [
        "CS-IT[PIS]_E4"
      ],
      "faculty": "RIV",
      "room": "CR11",
      "raw": "L-19B1WCI831    CS-IT[PIS]_E4 (RIV) CR11"
    },
    {
      "id": "btech_8_THU_3_6xqh1d",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WCI835",
      "batches": [
        "CS-IT[PCC]_E4_B1"
      ],
      "faculty": "NKR",
      "room": "CR4",
      "raw": "L-19B1WCI835    CS-IT[PCC]_E4_B1 (NKR) CR4"
    },
    {
      "id": "btech_8_THU_5_ffv5rk",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WPH831",
      "batches": [
        "PMSALL_3_BAS_1"
      ],
      "faculty": "RRS",
      "room": "CR6",
      "raw": "L-21B1WPH831  PMSALL_3_BAS_1 (RRS) CR6"
    },
    {
      "id": "btech_8_THU_1_tlidec",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI832",
      "batches": [
        "CS-IT[PML]_E4"
      ],
      "faculty": "VSG",
      "room": "CR12",
      "raw": "L-19B1WCI832    CS-IT[PML]_E4 (VSG) CR12"
    },
    {
      "id": "btech_8_THU_3_xqfbmf",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WCI835",
      "batches": [
        "CS-IT[PCC]_E4_B2"
      ],
      "faculty": "PDN",
      "room": "CR2",
      "raw": "L-19B1WCI835    CS-IT[PCC]_E4_B2 (PDN) CR2"
    },
    {
      "id": "btech_8_THU_1_v49p3s",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCI832",
      "batches": [
        "CS-IT[PDS]_E4"
      ],
      "faculty": "SMA",
      "room": "CR1",
      "raw": "L-18B1WCI832    CS-IT[PDS]_E4 (SMA) CR1"
    },
    {
      "id": "btech_8_THU_2_nmow00",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WEC837",
      "batches": [
        "EC_E6",
        "EM81"
      ],
      "faculty": "PRG",
      "room": "TR4",
      "raw": "L-19B1WEC837   EC_E6,EM81 (PRG) TR4"
    },
    {
      "id": "btech_8_THU_1_lidxxg",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBT833",
      "batches": [
        "BT81",
        "BI81"
      ],
      "faculty": "RST",
      "room": "CR16",
      "raw": "L-18B1WBT833 BT81,BI81 (RST) CR16"
    },
    {
      "id": "btech_8_THU_5_yfnp73",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B7WEC871",
      "batches": [
        "ECALL_4_BAS_1_B2_LAB"
      ],
      "faculty": "SRU",
      "room": "ECL6",
      "raw": "P-25B7WEC871  ECALL_4_BAS_1_B2_LAB (SRU) ECL6"
    },
    {
      "id": "btech_8_THU_6_yx37u7",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25B7WEC871",
      "batches": [
        "ECALL_4_BAS_1_B2_LAB"
      ],
      "faculty": "SRU",
      "room": "ECL6",
      "raw": "P-25B7WEC871  ECALL_4_BAS_1_B2_LAB (SRU) ECL6"
    },
    {
      "id": "btech_8_THU_6_lvwo0w",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "23B1WHS831",
      "batches": [
        "HSS_ALL_2_BAS_1"
      ],
      "faculty": "AKS",
      "room": "CR8",
      "raw": "L-23B1WHS831  HSS_ALL_2_BAS_1 (AKS) CR8"
    },
    {
      "id": "btech_8_THU_7_stpx01",
      "semesterId": "btech_8",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WBI831",
      "batches": [
        "BI81"
      ],
      "faculty": "TTS",
      "room": "CR19",
      "raw": "L-18B1WBI831  BI81  (TTS) CR19"
    },
    {
      "id": "btech_8_FRI_0_z13mbm",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WEC843",
      "batches": [
        "ECALL_5_BAS_2"
      ],
      "faculty": "MSD",
      "room": "CR5",
      "raw": "L-18B1WEC843 ECALL_5_BAS_2 (MSD) CR5"
    },
    {
      "id": "btech_8_FRI_1_i8awh6",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI832",
      "batches": [
        "CS-IT[PML]_E4"
      ],
      "faculty": "VSG",
      "room": "CR11",
      "raw": "L-19B1WCI832    CS-IT[PML]_E4 (VSG) CR11"
    },
    {
      "id": "btech_8_FRI_7_drk1e0",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WMA831",
      "batches": [
        "MAALL_BAS_2"
      ],
      "faculty": "BKP",
      "room": "CR4",
      "raw": "L-21B1WMA831  MAALL_BAS_2  (BKP) CR4"
    },
    {
      "id": "btech_8_FRI_8_uqom47",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 8,
      "time": "05:00 PM - 05:55 PM",
      "type": "Lecture",
      "courseCode": "24B1WCE631",
      "batches": [
        "ESE_Y3_Y4"
      ],
      "faculty": "NJP,RRA,ASA,ANU",
      "room": "CR7",
      "raw": "L-24B1WCE631 ESE_Y3_Y4 (NJP,RRA,ASA,ANU) CR7"
    },
    {
      "id": "btech_8_FRI_1_iibeth",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WCE831",
      "batches": [
        "CE81"
      ],
      "faculty": "KKR",
      "room": "TR9",
      "raw": "L-18B1WCE831  CE81  (KKR) TR9"
    },
    {
      "id": "btech_8_FRI_7_j1mayo",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCE834",
      "batches": [
        "CEALL_2_BAS_2"
      ],
      "faculty": "ABJ",
      "room": "CR5",
      "raw": "L-18B1WCE834   CEALL_2_BAS_2 (ABJ) CR5"
    },
    {
      "id": "btech_8_FRI_2_hwz5vl",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WPH732",
      "batches": [
        "PMSALL_2_BAS_1"
      ],
      "faculty": "SKK",
      "room": "CR1",
      "raw": "L-18B1WPH732 PMSALL_2_BAS_1 (SKK) CR1"
    },
    {
      "id": "btech_8_FRI_1_kx9lr8",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "19B1WCI837/25B1WCI640",
      "batches": [
        "CS-IT[PAI]_E4",
        "SEM6_PCC_23I11_23I12"
      ],
      "faculty": "SKS",
      "room": "CR6",
      "raw": "L-19B1WCI837/25B1WCI640   CS-IT[PAI]_E4,SEM6_PCC_23I11_23I12 (SKS) CR6"
    },
    {
      "id": "btech_8_FRI_6_5vgbn0",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "23B1WHS831",
      "batches": [
        "HSS_ALL_2_BAS_1"
      ],
      "faculty": "AKS",
      "room": "CR9",
      "raw": "L-23B1WHS831  HSS_ALL_2_BAS_1 (AKS) CR9"
    },
    {
      "id": "btech_8_FRI_7_q3bp8p",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WBT831",
      "batches": [
        "BT81"
      ],
      "faculty": "AKT",
      "room": "CR18",
      "raw": "L-21B1WBT831  BT81 (AKT) CR18"
    },
    {
      "id": "btech_8_FRI_1_7msce6",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "18B1WBT831",
      "batches": [
        "BT81",
        "BI81"
      ],
      "faculty": "SDS",
      "room": "CR18",
      "raw": "L-18B1WBT831  BT81,BI81  (SDS) CR18"
    },
    {
      "id": "btech_8_FRI_5_8h8dph",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WBT833",
      "batches": [
        "BIOALL_BAS_2"
      ],
      "faculty": "RJK",
      "room": "CR16",
      "raw": "L-21B1WBT833 BIOALL_BAS_2 (RJK) CR16"
    },
    {
      "id": "btech_8_FRI_6_yieov2",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WCE831",
      "batches": [
        "CEALL_1_BAS_1"
      ],
      "faculty": "SUV",
      "room": "CR4",
      "raw": "L-21B1WCE831   CEALL_1_BAS_1 (SUV) CR4"
    },
    {
      "id": "btech_8_FRI_3_ik12jb",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "21B1WBT831",
      "batches": [
        "BT81"
      ],
      "faculty": "AKN",
      "room": "CR19",
      "raw": "L-21B1WBT831  BT81 (AKN) CR19"
    },
    {
      "id": "btech_8_FRI_5_4otv92",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25B1WEC832",
      "batches": [
        "ECEALL_3_BAS_2"
      ],
      "faculty": "VKB",
      "room": "CR11",
      "raw": "L-25B1WEC832   ECEALL_3_BAS_2  (VKB) CR11"
    },
    {
      "id": "btech_8_FRI_3_apsmpp",
      "semesterId": "btech_8",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18B1WCI832",
      "batches": [
        "CS-IT[PDS]_E4"
      ],
      "faculty": "SMA",
      "room": "CR2",
      "raw": "L-18B1WCI832    CS-IT[PDS]_E4 (SMA) CR2"
    },
    {
      "id": "btech_8_SAT_3_vfdqpm",
      "semesterId": "btech_8",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WEC837",
      "batches": [
        "EC_E6",
        "EM81"
      ],
      "faculty": "PRG",
      "room": "CR16",
      "raw": "L-19B1WEC837   EC_E6,EM81 (PRG) CR16"
    },
    {
      "id": "btech_8_SAT_1_qi8e2e",
      "semesterId": "btech_8",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B7WEC871",
      "batches": [
        "ECALL_4_BAS_1_B1_LAB"
      ],
      "faculty": "SRU",
      "room": "ECL6",
      "raw": "P-25B7WEC871  ECALL_4_BAS_1_B1_LAB (SRU) ECL6"
    },
    {
      "id": "btech_8_SAT_2_0y4nyu",
      "semesterId": "btech_8",
      "day": "SAT",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25B7WEC871",
      "batches": [
        "ECALL_4_BAS_1_B1_LAB"
      ],
      "faculty": "SRU",
      "room": "ECL6",
      "raw": "P-25B7WEC871  ECALL_4_BAS_1_B1_LAB (SRU) ECL6"
    },
    {
      "id": "btech_8_SAT_3_k6qf4n",
      "semesterId": "btech_8",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "19B1WCI837/25B1WCI640",
      "batches": [
        "CS-IT[PAI]_E4",
        "SEM6_PCC_23I11_23I12"
      ],
      "faculty": "SKS",
      "room": "CR4",
      "raw": "L-19B1WCI837/25B1WCI640   CS-IT[PAI]_E4,SEM6_PCC_23I11_23I12 (SKS) CR4"
    },
    {
      "id": "mtech_2_MON_1_ogdjhz",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE212",
      "batches": [
        "25SE11"
      ],
      "faculty": "CPG",
      "room": "TR8",
      "raw": "L-25M11CE212   25SE11  (CPG) TR8"
    },
    {
      "id": "mtech_2_MON_3_jsza4b",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25M1WCE332",
      "batches": [
        "25SE11"
      ],
      "faculty": "KKR",
      "room": "TR9",
      "raw": "L-25M1WCE332 25SE11 (KKR) TR9"
    },
    {
      "id": "mtech_2_MON_5_27y1ea",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "20MS1BT211",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKT",
      "room": "TR7",
      "raw": "L-20MS1BT211 25MB11 (AKT) TR7"
    },
    {
      "id": "mtech_2_MON_0_6o8zvh",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT271",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKT",
      "room": "GENOMELAB",
      "raw": "P-20MS7BT271 25MB11 (AKT) GENOMELAB"
    },
    {
      "id": "mtech_2_MON_1_4u55ya",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT271",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKT",
      "room": "GENOMELAB",
      "raw": "P-20MS7BT271 25MB11 (AKT) GENOMELAB"
    },
    {
      "id": "mtech_2_MON_2_1s2s2c",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT271",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKT",
      "room": "GENOMELAB",
      "raw": "P-20MS7BT271 25MB11 (AKT) GENOMELAB"
    },
    {
      "id": "mtech_2_MON_3_3y5d81",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT271",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKT",
      "room": "GENOMELAB",
      "raw": "P-20MS7BT271 25MB11 (AKT) GENOMELAB"
    },
    {
      "id": "mtech_2_MON_6_on1ys6",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "22M11CI212",
      "batches": [
        "25CD11"
      ],
      "faculty": "RBT",
      "room": "CR18",
      "raw": "L-22M11CI212 25CD11 (RBT) CR18"
    },
    {
      "id": "mtech_2_MON_5_z78s0u",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT214",
      "batches": [
        "25BY11"
      ],
      "faculty": "HSD",
      "room": "CR16",
      "raw": "L-14M11BT214 25BY11 (HSD) CR16"
    },
    {
      "id": "mtech_2_MON_0_dp295w",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE213",
      "batches": [
        "25SE11"
      ],
      "faculty": "SUV",
      "room": "TR8",
      "raw": "L-25M11CE213 25SE11 (SUV) TR8"
    },
    {
      "id": "mtech_2_MON_1_vn1igs",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "22M11CI211",
      "batches": [
        "25CD11"
      ],
      "faculty": "ARV",
      "room": "TR7",
      "raw": "L-22M11CI211 25CD11 (ARV) TR7"
    },
    {
      "id": "mtech_2_MON_3_txenxy",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "22M1WCI236",
      "batches": [
        "25CD11"
      ],
      "faculty": "HRI",
      "room": "TR2",
      "raw": "L-22M1WCI236 25CD11 (HRI) TR2"
    },
    {
      "id": "mtech_2_MON_6_svy2ba",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "21MS1MB211",
      "batches": [
        "25MM11"
      ],
      "faculty": "SBS",
      "room": "CR16",
      "raw": "L-21MS1MB211 25MM11 (SBS) CR16"
    },
    {
      "id": "mtech_2_MON_7_t1y9v6",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "22M1WCI234",
      "batches": [
        "25CD11"
      ],
      "faculty": "AKJ",
      "room": "TR2",
      "raw": "L-22M1WCI234 25CD11 (AKJ) TR2"
    },
    {
      "id": "mtech_2_MON_1_g3iikx",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "10M11CE211",
      "batches": [
        "25CM11"
      ],
      "faculty": "SUV",
      "room": "CR15",
      "raw": "L-10M11CE211 25CM11 (SUV) CR15"
    },
    {
      "id": "mtech_2_MON_2_qfzgjl",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "22M11CI213",
      "batches": [
        "25CD11"
      ],
      "faculty": "DGA",
      "room": "TR3",
      "raw": "L-22M11CI213 25CD11 (DGA) TR3"
    },
    {
      "id": "mtech_2_MON_2_p8tnjv",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE214",
      "batches": [
        "25SE11"
      ],
      "faculty": "SUV",
      "room": "CR13",
      "raw": "L-25M11CE214 25SE11 (SUV) CR13"
    },
    {
      "id": "mtech_2_MON_6_b3a0hj",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "14M17BT273",
      "batches": [
        "25BY11"
      ],
      "faculty": "JAS",
      "room": "GENOMELAB",
      "raw": "P-14M17BT273 25BY11 (JAS) GENOMELAB"
    },
    {
      "id": "mtech_2_MON_7_qr7nt3",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "14M17BT273",
      "batches": [
        "25BY11"
      ],
      "faculty": "JAS",
      "room": "GENOMELAB",
      "raw": "P-14M17BT273 25BY11 (JAS) GENOMELAB"
    },
    {
      "id": "mtech_2_MON_1_ycj7a2",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "20M1WBT234",
      "batches": [
        "25BY11"
      ],
      "faculty": "JTV",
      "room": "CR7",
      "raw": "L-20M1WBT234 25BY11 (JTV) CR7"
    },
    {
      "id": "mtech_2_MON_6_i3n5om",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "20MSWBT232",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKN",
      "room": "CR19",
      "raw": "L-20MSWBT232 25MB11 (AKN) CR19"
    },
    {
      "id": "mtech_2_MON_7_3rjjm2",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "20MS1BT213",
      "batches": [
        "25MB11",
        "25MM11"
      ],
      "faculty": "SML",
      "room": "TR4",
      "raw": "L-20MS1BT213   25MB11,25MM11   (SML) TR4"
    },
    {
      "id": "mtech_2_MON_2_rhlal0",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "10M11CE214",
      "batches": [
        "25CM11"
      ],
      "faculty": "AKG",
      "room": "TR8",
      "raw": "L-10M11CE214 25CM11 (AKG) TR8"
    },
    {
      "id": "mtech_2_MON_3_c6lofg",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT215",
      "batches": [
        "25BY11"
      ],
      "faculty": "SBS",
      "room": "CR19",
      "raw": "L-14M11BT215 25BY11 (SBS) CR19"
    },
    {
      "id": "mtech_2_MON_2_4735ye",
      "semesterId": "mtech_2",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "20M1WBT231/21MS2MB414",
      "batches": [
        "25BY11",
        "24MM11"
      ],
      "faculty": "GPL",
      "room": "TR1",
      "raw": "L-20M1WBT231/21MS2MB414 25BY11,24MM11 (GPL) TR1"
    },
    {
      "id": "mtech_2_TUE_1_u80gpa",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "20MS1BT216",
      "batches": [
        "25MB11"
      ],
      "faculty": "GPL",
      "room": "TR2",
      "raw": "L-20MS1BT216 25MB11 (GPL) TR2"
    },
    {
      "id": "mtech_2_TUE_2_vjydah",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25M1WCE332",
      "batches": [
        "25SE11"
      ],
      "faculty": "KKR",
      "room": "TR9",
      "raw": "L-25M1WCE332 25SE11 (KKR) TR9"
    },
    {
      "id": "mtech_2_TUE_5_4yuoum",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT272",
      "batches": [
        "25MB11"
      ],
      "faculty": "UDB",
      "room": "UG1",
      "raw": "P-20MS7BT272  25MB11  (UDB) UG1"
    },
    {
      "id": "mtech_2_TUE_6_7336np",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT272",
      "batches": [
        "25MB11"
      ],
      "faculty": "UDB",
      "room": "UG1",
      "raw": "P-20MS7BT272  25MB11  (UDB) UG1"
    },
    {
      "id": "mtech_2_TUE_7_zmjci7",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT272",
      "batches": [
        "25MB11"
      ],
      "faculty": "UDB",
      "room": "UG1",
      "raw": "P-20MS7BT272  25MB11  (UDB) UG1"
    },
    {
      "id": "mtech_2_TUE_2_8ugr3k",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "20MSWBT231",
      "batches": [
        "25MB11"
      ],
      "faculty": "ABH",
      "room": "CR17",
      "raw": "L-20MSWBT231   25MB11 (ABH) CR17"
    },
    {
      "id": "mtech_2_TUE_0_ujaxpc",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "22M17CI273",
      "batches": [
        "25CD11"
      ],
      "faculty": "VSG",
      "room": "CL4",
      "raw": "P-22M17CI273 25CD11 (VSG) CL4"
    },
    {
      "id": "mtech_2_TUE_1_8x80ic",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "22M17CI273",
      "batches": [
        "25CD11"
      ],
      "faculty": "VSG",
      "room": "CL4",
      "raw": "P-22M17CI273 25CD11 (VSG) CL4"
    },
    {
      "id": "mtech_2_TUE_6_9fbdbe",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "22M17CI272",
      "batches": [
        "25CD11"
      ],
      "faculty": "SKS",
      "room": "ECL5",
      "raw": "P-22M17CI272 25CD11 (SKS) ECL5"
    },
    {
      "id": "mtech_2_TUE_7_thz9v0",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "22M17CI272",
      "batches": [
        "25CD11"
      ],
      "faculty": "SKS",
      "room": "ECL5",
      "raw": "P-22M17CI272 25CD11 (SKS) ECL5"
    },
    {
      "id": "mtech_2_TUE_0_r5mfa8",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "10M11CE212",
      "batches": [
        "25CM11"
      ],
      "faculty": "ADP",
      "room": "TR8",
      "raw": "L-10M11CE212 25CM11 (ADP) TR8"
    },
    {
      "id": "mtech_2_TUE_1_nuzscz",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE213",
      "batches": [
        "25SE11"
      ],
      "faculty": "SUV",
      "room": "TR8",
      "raw": "L-25M11CE213 25SE11 (SUV) TR8"
    },
    {
      "id": "mtech_2_TUE_2_obxjj1",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "22M1WCI236",
      "batches": [
        "25CD11"
      ],
      "faculty": "HRI",
      "room": "TR7",
      "raw": "L-22M1WCI236 25CD11 (HRI) TR7"
    },
    {
      "id": "mtech_2_TUE_3_mkcxrz",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "24MS1BT211",
      "batches": [
        "25MB11",
        "25MM11"
      ],
      "faculty": "JTV",
      "room": "TR4",
      "raw": "L-24MS1BT211 25MB11,25MM11 (JTV) TR4"
    },
    {
      "id": "mtech_2_TUE_0_f83hn7",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "14M17BT272/18MS7BT211",
      "batches": [
        "25BY11",
        "25MM11"
      ],
      "faculty": "TYN",
      "room": "UG1",
      "raw": "P-14M17BT272/18MS7BT211  25BY11,25MM11  (TYN) UG1"
    },
    {
      "id": "mtech_2_TUE_1_94xtxi",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "14M17BT272/18MS7BT211",
      "batches": [
        "25BY11",
        "25MM11"
      ],
      "faculty": "TYN",
      "room": "UG1",
      "raw": "P-14M17BT272/18MS7BT211  25BY11,25MM11  (TYN) UG1"
    },
    {
      "id": "mtech_2_TUE_7_yaw593",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "21MS1MB211",
      "batches": [
        "25MM11"
      ],
      "faculty": "SBS",
      "room": "CR18",
      "raw": "L-21MS1MB211 25MM11 (SBS) CR18"
    },
    {
      "id": "mtech_2_TUE_3_9bllqt",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "10M11CE215",
      "batches": [
        "25CM11"
      ],
      "faculty": "ABJ",
      "room": "CR14",
      "raw": "L-10M11CE215 25CM11 (ABJ) CR14"
    },
    {
      "id": "mtech_2_TUE_1_20yal4",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "10M11CE213",
      "batches": [
        "25CM11"
      ],
      "faculty": "KKR",
      "room": "TR9",
      "raw": "L-10M11CE213 25CM11 (KKR) TR9"
    },
    {
      "id": "mtech_2_TUE_3_lj64gd",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25M11CE211",
      "batches": [
        "25SE11"
      ],
      "faculty": "TNM",
      "room": "TR8",
      "raw": "L-25M11CE211 25SE11 (TNM) TR8"
    },
    {
      "id": "mtech_2_TUE_2_r4bez8",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "14M11BT212/18MS1BT211",
      "batches": [
        "25BY11",
        "25MM11"
      ],
      "faculty": "TYN",
      "room": "CR16",
      "raw": "L-14M11BT212/18MS1BT211  25BY11,25MM11  (TYN) CR16"
    },
    {
      "id": "mtech_2_TUE_5_u78djt",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "20M1WBT231/21MS2MB414",
      "batches": [
        "25BY11",
        "24MM11"
      ],
      "faculty": "GPL",
      "room": "CR16",
      "raw": "L-20M1WBT231/21MS2MB414 25BY11,24MM11 (GPL) CR16"
    },
    {
      "id": "mtech_2_TUE_3_zkz2mb",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT211",
      "batches": [
        "25BY11"
      ],
      "faculty": "GAI",
      "room": "TR7",
      "raw": "L-14M11BT211   25BY11 (GAI) TR7"
    },
    {
      "id": "mtech_2_TUE_6_x1s7ag",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "14M17BT271",
      "batches": [
        "25BY11"
      ],
      "faculty": "GAI",
      "room": "UG2",
      "raw": "P-14M17BT271 25BY11 (GAI) UG2"
    },
    {
      "id": "mtech_2_TUE_7_qmrizj",
      "semesterId": "mtech_2",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "14M17BT271",
      "batches": [
        "25BY11"
      ],
      "faculty": "GAI",
      "room": "UG2",
      "raw": "P-14M17BT271 25BY11 (GAI) UG2"
    },
    {
      "id": "mtech_2_WED_2_yq2nld",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE212",
      "batches": [
        "25SE11"
      ],
      "faculty": "CPG",
      "room": "TR8",
      "raw": "L-25M11CE212   25SE11  (CPG) TR8"
    },
    {
      "id": "mtech_2_WED_5_x6z2np",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "20MS1BT211",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKT",
      "room": "TR4",
      "raw": "L-20MS1BT211 25MB11 (AKT) TR4"
    },
    {
      "id": "mtech_2_WED_0_383zj5",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE214",
      "batches": [
        "25SE11"
      ],
      "faculty": "SUV",
      "room": "CR15",
      "raw": "L-25M11CE214 25SE11 (SUV) CR15"
    },
    {
      "id": "mtech_2_WED_1_n4bmi5",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "20MS1BT213",
      "batches": [
        "25MB11",
        "25MM11"
      ],
      "faculty": "SML",
      "room": "TR5",
      "raw": "L-20MS1BT213   25MB11,25MM11   (SML) TR5"
    },
    {
      "id": "mtech_2_WED_2_dtkx3a",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "20M1WBT234",
      "batches": [
        "25BY11"
      ],
      "faculty": "JTV",
      "room": "TR7",
      "raw": "L-20M1WBT234 25BY11 (JTV) TR7"
    },
    {
      "id": "mtech_2_WED_3_8i8b7z",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "20MS1BT214",
      "batches": [
        "25MB11"
      ],
      "faculty": "JAS",
      "room": "CR18",
      "raw": "L-20MS1BT214 25MB11 (JAS) CR18"
    },
    {
      "id": "mtech_2_WED_2_22thff",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "21MS1MB211",
      "batches": [
        "25MM11"
      ],
      "faculty": "SBS",
      "room": "CR17",
      "raw": "L-21MS1MB211 25MM11 (SBS) CR17"
    },
    {
      "id": "mtech_2_WED_0_99yina",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "22M17CI271",
      "batches": [
        "25CD11"
      ],
      "faculty": "ARV",
      "room": "ECL5",
      "raw": "P-22M17CI271 25CD11 (ARV) ECL5"
    },
    {
      "id": "mtech_2_WED_1_aq3xzn",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "22M17CI271",
      "batches": [
        "25CD11"
      ],
      "faculty": "ARV",
      "room": "ECL5",
      "raw": "P-22M17CI271 25CD11 (ARV) ECL5"
    },
    {
      "id": "mtech_2_WED_3_tq8frk",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT211",
      "batches": [
        "25BY11"
      ],
      "faculty": "GAI",
      "room": "TR7",
      "raw": "L-14M11BT211   25BY11 (GAI) TR7"
    },
    {
      "id": "mtech_2_WED_7_ejjood",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "20MS1BT216",
      "batches": [
        "25MB11"
      ],
      "faculty": "GPL",
      "room": "TR2",
      "raw": "L-20MS1BT216 25MB11 (GPL) TR2"
    },
    {
      "id": "mtech_2_WED_3_gl43ki",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "22M11CI213",
      "batches": [
        "25CD11"
      ],
      "faculty": "DGA",
      "room": "TR3",
      "raw": "L-22M11CI213 25CD11 (DGA) TR3"
    },
    {
      "id": "mtech_2_WED_6_dklwav",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "10M11CE211",
      "batches": [
        "25CM11"
      ],
      "faculty": "SUV",
      "room": "CR15",
      "raw": "L-10M11CE211 25CM11 (SUV) CR15"
    },
    {
      "id": "mtech_2_WED_7_cyanut",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "22M11CI211",
      "batches": [
        "25CD11"
      ],
      "faculty": "ARV",
      "room": "CR11",
      "raw": "L-22M11CI211 25CD11 (ARV) CR11"
    },
    {
      "id": "mtech_2_WED_0_6snqfo",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "20MS1BT212",
      "batches": [
        "25MB11"
      ],
      "faculty": "ABH",
      "room": "CR18",
      "raw": "L-20MS1BT212 25MB11 (ABH) CR18"
    },
    {
      "id": "mtech_2_WED_1_dti2mg",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE211",
      "batches": [
        "25SE11"
      ],
      "faculty": "TNM",
      "room": "TR8",
      "raw": "L-25M11CE211 25SE11 (TNM) TR8"
    },
    {
      "id": "mtech_2_WED_6_znycym",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "22M1WCI231/25BS1MA411",
      "batches": [
        "25CD11",
        "24P11"
      ],
      "faculty": "SST",
      "room": "TR7",
      "raw": "L-22M1WCI231/25BS1MA411 25CD11,24P11 (SST) TR7"
    },
    {
      "id": "mtech_2_WED_5_jqe5k3",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "22M1WCI234",
      "batches": [
        "25CD11"
      ],
      "faculty": "AKJ",
      "room": "TR5",
      "raw": "L-22M1WCI234 25CD11 (AKJ) TR5"
    },
    {
      "id": "mtech_2_WED_7_u28oo5",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "10M11CE214",
      "batches": [
        "25CM11"
      ],
      "faculty": "AKG",
      "room": "TR8",
      "raw": "L-10M11CE214 25CM11 (AKG) TR8"
    },
    {
      "id": "mtech_2_WED_2_xx5bin",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "20MSWBT232",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKN",
      "room": "CR18",
      "raw": "L-20MSWBT232 25MB11 (AKN) CR18"
    },
    {
      "id": "mtech_2_WED_3_tuaxj0",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "18MS1BT313",
      "batches": [
        "25MM11"
      ],
      "faculty": "RST",
      "room": "TR5",
      "raw": "L-18MS1BT313 25MM11 (RST) TR5"
    },
    {
      "id": "mtech_2_WED_1_qvb8o1",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "14M11BT213",
      "batches": [
        "25BY11"
      ],
      "faculty": "JAS",
      "room": "TR6",
      "raw": "L-14M11BT213 25BY11 (JAS) TR6"
    },
    {
      "id": "mtech_2_WED_5_mey3bt",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "10M11CE213",
      "batches": [
        "25CM11"
      ],
      "faculty": "KKR",
      "room": "TR9",
      "raw": "L-10M11CE213 25CM11 (KKR) TR9"
    },
    {
      "id": "mtech_2_WED_6_d7woch",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "20MSWBT233",
      "batches": [
        "25MB11"
      ],
      "faculty": "SBS",
      "room": "CR16",
      "raw": "L-20MSWBT233 25MB11 (SBS) CR16"
    },
    {
      "id": "mtech_2_WED_3_2aj0li",
      "semesterId": "mtech_2",
      "day": "WED",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "10M11CE215",
      "batches": [
        "25CM11"
      ],
      "faculty": "ABJ",
      "room": "CR14",
      "raw": "L-10M11CE215 25CM11 (ABJ) CR14"
    },
    {
      "id": "mtech_2_THU_2_il6sbv",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "14M11BT215",
      "batches": [
        "25BY11"
      ],
      "faculty": "GAI",
      "room": "CR11",
      "raw": "L-14M11BT215 25BY11 (GAI) CR11"
    },
    {
      "id": "mtech_2_THU_6_yuws0k",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "20MS1BT212",
      "batches": [
        "25MB11"
      ],
      "faculty": "ABH",
      "room": "CR17",
      "raw": "L-20MS1BT212 25MB11 (ABH) CR17"
    },
    {
      "id": "mtech_2_THU_7_om8pf0",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "20MS1BT214",
      "batches": [
        "25MB11"
      ],
      "faculty": "JAS",
      "room": "CR18",
      "raw": "L-20MS1BT214 25MB11 (JAS) CR18"
    },
    {
      "id": "mtech_2_THU_2_eb88rt",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "25M1WCE332",
      "batches": [
        "25SE11"
      ],
      "faculty": "KKR",
      "room": "TR8",
      "raw": "L-25M1WCE332 25SE11 (KKR) TR8"
    },
    {
      "id": "mtech_2_THU_0_mwragb",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "21MS7MB271",
      "batches": [
        "25MM11"
      ],
      "faculty": "JTV",
      "room": "UG2",
      "raw": "P-21MS7MB271 25MM11 (JTV) UG2"
    },
    {
      "id": "mtech_2_THU_1_sshg2g",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "21MS7MB271",
      "batches": [
        "25MM11"
      ],
      "faculty": "JTV",
      "room": "UG2",
      "raw": "P-21MS7MB271 25MM11 (JTV) UG2"
    },
    {
      "id": "mtech_2_THU_2_ggc421",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18MS7BI214",
      "batches": [
        "25MM11"
      ],
      "faculty": "SML",
      "room": "BIL",
      "raw": "P-18MS7BI214 25MM11 (SML) BIL"
    },
    {
      "id": "mtech_2_THU_3_ly70oh",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18MS7BI214",
      "batches": [
        "25MM11"
      ],
      "faculty": "SML",
      "room": "BIL",
      "raw": "P-18MS7BI214 25MM11 (SML) BIL"
    },
    {
      "id": "mtech_2_THU_7_0yxyv5",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT212/18MS1BT211",
      "batches": [
        "25BY11",
        "25MM11"
      ],
      "faculty": "TYN",
      "room": "CR16",
      "raw": "L-14M11BT212/18MS1BT211  25BY11,25MM11  (TYN) CR16"
    },
    {
      "id": "mtech_2_THU_1_vf58a4",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "14M11BT213",
      "batches": [
        "25BY11"
      ],
      "faculty": "JAS",
      "room": "TR1",
      "raw": "L-14M11BT213 25BY11 (JAS) TR1"
    },
    {
      "id": "mtech_2_THU_3_3qjumo",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT211",
      "batches": [
        "25BY11"
      ],
      "faculty": "GAI",
      "room": "TR7",
      "raw": "L-14M11BT211   25BY11 (GAI) TR7"
    },
    {
      "id": "mtech_2_THU_5_2m00dd",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25M17CE271",
      "batches": [
        "25SE11"
      ],
      "faculty": "TNM",
      "room": "ENVLAB",
      "raw": "P-25M17CE271 25SE11 (TNM) ENVLAB"
    },
    {
      "id": "mtech_2_THU_6_ume25q",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25M17CE271",
      "batches": [
        "25SE11"
      ],
      "faculty": "TNM",
      "room": "ENVLAB",
      "raw": "P-25M17CE271 25SE11 (TNM) ENVLAB"
    },
    {
      "id": "mtech_2_THU_1_qspjfo",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "10M11CE215",
      "batches": [
        "25CM11"
      ],
      "faculty": "ABJ",
      "room": "CR14",
      "raw": "L-10M11CE215 25CM11 (ABJ) CR14"
    },
    {
      "id": "mtech_2_THU_2_6kae8x",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "10M11CE211",
      "batches": [
        "25CM11"
      ],
      "faculty": "SUV",
      "room": "CR15",
      "raw": "L-10M11CE211 25CM11 (SUV) CR15"
    },
    {
      "id": "mtech_2_THU_3_hgdvpo",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "10M11CE212",
      "batches": [
        "25CM11"
      ],
      "faculty": "ADP",
      "room": "TR9",
      "raw": "L-10M11CE212 25CM11 (ADP) TR9"
    },
    {
      "id": "mtech_2_THU_6_r57oja",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18MS1BT313",
      "batches": [
        "25MM11"
      ],
      "faculty": "RST",
      "room": "TR4",
      "raw": "L-18MS1BT313 25MM11 (RST) TR4"
    },
    {
      "id": "mtech_2_THU_1_beh56t",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "22M1WCI231/25BS1MA411",
      "batches": [
        "25CD11",
        "24P11"
      ],
      "faculty": "SST",
      "room": "TR2",
      "raw": "L-22M1WCI231/25BS1MA411 25CD11,24P11 (SST) TR2"
    },
    {
      "id": "mtech_2_THU_3_bnkr9c",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "25M11CE212",
      "batches": [
        "25SE11"
      ],
      "faculty": "CPG",
      "room": "TR8",
      "raw": "L-25M11CE212   25SE11  (CPG) TR8"
    },
    {
      "id": "mtech_2_THU_0_f5xoho",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT271",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKN",
      "room": "GENOMELAB",
      "raw": "P-20MS7BT271 25MB11 (AKN) GENOMELAB"
    },
    {
      "id": "mtech_2_THU_1_am9aui",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT271",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKN",
      "room": "GENOMELAB",
      "raw": "P-20MS7BT271 25MB11 (AKN) GENOMELAB"
    },
    {
      "id": "mtech_2_THU_2_pcu3mt",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT271",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKN",
      "room": "GENOMELAB",
      "raw": "P-20MS7BT271 25MB11 (AKN) GENOMELAB"
    },
    {
      "id": "mtech_2_THU_3_jcyag4",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT271",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKN",
      "room": "GENOMELAB",
      "raw": "P-20MS7BT271 25MB11 (AKN) GENOMELAB"
    },
    {
      "id": "mtech_2_THU_5_z0aa5d",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "24MS1BT211",
      "batches": [
        "25MB11",
        "25MM11"
      ],
      "faculty": "JTV",
      "room": "TR4",
      "raw": "L-24MS1BT211 25MB11,25MM11 (JTV) TR4"
    },
    {
      "id": "mtech_2_THU_0_yyuae3",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE213",
      "batches": [
        "25SE11"
      ],
      "faculty": "SUV",
      "room": "TR8",
      "raw": "L-25M11CE213 25SE11 (SUV) TR8"
    },
    {
      "id": "mtech_2_THU_2_e59foj",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "22M11CI212",
      "batches": [
        "25CD11"
      ],
      "faculty": "RBT",
      "room": "CR16",
      "raw": "L-22M11CI212 25CD11 (RBT) CR16"
    },
    {
      "id": "mtech_2_THU_5_aeg53x",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "20M1WBT231/21MS2MB414",
      "batches": [
        "25BY11",
        "24MM11"
      ],
      "faculty": "GPL",
      "room": "CR19",
      "raw": "L-20M1WBT231/21MS2MB414 25BY11,24MM11 (GPL) CR19"
    },
    {
      "id": "mtech_2_THU_6_7ne1d6",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT214",
      "batches": [
        "25BY11"
      ],
      "faculty": "HSD",
      "room": "CR16",
      "raw": "L-14M11BT214 25BY11 (HSD) CR16"
    },
    {
      "id": "mtech_2_THU_1_zgfbou",
      "semesterId": "mtech_2",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "25M11CE214",
      "batches": [
        "25SE11"
      ],
      "faculty": "SUV",
      "room": "CR15",
      "raw": "L-25M11CE214 25SE11 (SUV) CR15"
    },
    {
      "id": "mtech_2_FRI_5_jzn267",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "25M11CE211",
      "batches": [
        "25SE11"
      ],
      "faculty": "TNM",
      "room": "TR8",
      "raw": "L-25M11CE211 25SE11 (TNM) TR8"
    },
    {
      "id": "mtech_2_FRI_3_huzmop",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "20MS1BT211",
      "batches": [
        "25MB11"
      ],
      "faculty": "AKT",
      "room": "TR5",
      "raw": "L-20MS1BT211 25MB11 (AKT) TR5"
    },
    {
      "id": "mtech_2_FRI_2_bdj4r0",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "20M1WBT234",
      "batches": [
        "25BY11"
      ],
      "faculty": "JTV",
      "room": "TR2",
      "raw": "L-20M1WBT234 25BY11 (JTV) TR2"
    },
    {
      "id": "mtech_2_FRI_1_4ddn30",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "14M11BT213",
      "batches": [
        "25BY11"
      ],
      "faculty": "JAS",
      "room": "TR1",
      "raw": "L-14M11BT213 25BY11 (JAS) TR1"
    },
    {
      "id": "mtech_2_FRI_5_a3z8n7",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT272",
      "batches": [
        "25MB11"
      ],
      "faculty": "UDB",
      "room": "UG1",
      "raw": "P-20MS7BT272  25MB11  (UDB) UG1"
    },
    {
      "id": "mtech_2_FRI_6_12o7sx",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT272",
      "batches": [
        "25MB11"
      ],
      "faculty": "UDB",
      "room": "UG1",
      "raw": "P-20MS7BT272  25MB11  (UDB) UG1"
    },
    {
      "id": "mtech_2_FRI_7_7ihd29",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Practical/Lab",
      "courseCode": "20MS7BT272",
      "batches": [
        "25MB11"
      ],
      "faculty": "UDB",
      "room": "UG1",
      "raw": "P-20MS7BT272  25MB11  (UDB) UG1"
    },
    {
      "id": "mtech_2_FRI_0_l1be4d",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18MS7BT373",
      "batches": [
        "25MM11"
      ],
      "faculty": "RST",
      "room": "MICROLAB",
      "raw": "P-18MS7BT373 25MM11 (RST) MICROLAB"
    },
    {
      "id": "mtech_2_FRI_1_oyzehe",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18MS7BT373",
      "batches": [
        "25MM11"
      ],
      "faculty": "RST",
      "room": "MICROLAB",
      "raw": "P-18MS7BT373 25MM11 (RST) MICROLAB"
    },
    {
      "id": "mtech_2_FRI_2_bvso0c",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "18MS7BT373",
      "batches": [
        "25MM11"
      ],
      "faculty": "RST",
      "room": "MICROLAB",
      "raw": "P-18MS7BT373 25MM11 (RST) MICROLAB"
    },
    {
      "id": "mtech_2_FRI_3_7gljdo",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "18MS7BT373",
      "batches": [
        "25MM11"
      ],
      "faculty": "RST",
      "room": "MICROLAB",
      "raw": "P-18MS7BT373 25MM11 (RST) MICROLAB"
    },
    {
      "id": "mtech_2_FRI_6_u4f4gy",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT215",
      "batches": [
        "25BY11"
      ],
      "faculty": "SBS",
      "room": "CR18",
      "raw": "L-14M11BT215 25BY11 (SBS) CR18"
    },
    {
      "id": "mtech_2_FRI_0_qr767i",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "20MSWBT231",
      "batches": [
        "25MB11"
      ],
      "faculty": "ABH",
      "room": "CR18",
      "raw": "L-20MSWBT231   25MB11 (ABH) CR18"
    },
    {
      "id": "mtech_2_FRI_1_d2gm4l",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "22M11CI212",
      "batches": [
        "25CD11"
      ],
      "faculty": "RBT",
      "room": "CR16",
      "raw": "L-22M11CI212 25CD11 (RBT) CR16"
    },
    {
      "id": "mtech_2_FRI_5_9onnrs",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "22M1WCI234",
      "batches": [
        "25CD11"
      ],
      "faculty": "AKJ",
      "room": "TR2",
      "raw": "L-22M1WCI234 25CD11 (AKJ) TR2"
    },
    {
      "id": "mtech_2_FRI_2_gg3rzc",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "20MS1BT212",
      "batches": [
        "25MB11"
      ],
      "faculty": "ABH",
      "room": "CR16",
      "raw": "L-20MS1BT212 25MB11 (ABH) CR16"
    },
    {
      "id": "mtech_2_FRI_0_uhnxgw",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "22M1WCI236",
      "batches": [
        "25CD11"
      ],
      "faculty": "HRI",
      "room": "TR3",
      "raw": "L-22M1WCI236 25CD11 (HRI) TR3"
    },
    {
      "id": "mtech_2_FRI_1_rukc5s",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "10M11CE212",
      "batches": [
        "25CM11"
      ],
      "faculty": "ADP",
      "room": "TR8",
      "raw": "L-10M11CE212 25CM11 (ADP) TR8"
    },
    {
      "id": "mtech_2_FRI_6_fvbgsq",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "18MS1BT313",
      "batches": [
        "25MM11"
      ],
      "faculty": "RST",
      "room": "CR17",
      "raw": "L-18MS1BT313 25MM11 (RST) CR17"
    },
    {
      "id": "mtech_2_FRI_2_1tdspu",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "22M11CI211",
      "batches": [
        "25CD11"
      ],
      "faculty": "ARV",
      "room": "CR11",
      "raw": "L-22M11CI211 25CD11 (ARV) CR11"
    },
    {
      "id": "mtech_2_FRI_1_8jtzf2",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "20MSWBT233",
      "batches": [
        "25MB11"
      ],
      "faculty": "SBS",
      "room": "CR17",
      "raw": "L-20MSWBT233 25MB11 (SBS) CR17"
    },
    {
      "id": "mtech_2_FRI_5_52q5if",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 5,
      "time": "02:00 PM - 02:55 PM",
      "type": "Lecture",
      "courseCode": "14M11BT212/18MS1BT211",
      "batches": [
        "25BY11",
        "25MM11"
      ],
      "faculty": "TYN",
      "room": "CR18",
      "raw": "L-14M11BT212/18MS1BT211  25BY11,25MM11  (TYN) CR18"
    },
    {
      "id": "mtech_2_FRI_2_xuwzwm",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "10M11CE213",
      "batches": [
        "25CM11"
      ],
      "faculty": "KKR",
      "room": "TR9",
      "raw": "L-10M11CE213 25CM11 (KKR) TR9"
    },
    {
      "id": "mtech_2_FRI_3_usx4r3",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "22M11CI213",
      "batches": [
        "25CD11"
      ],
      "faculty": "DGA",
      "room": "TR3",
      "raw": "L-22M11CI213 25CD11 (DGA) TR3"
    },
    {
      "id": "mtech_2_FRI_3_wfer72",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "10M11CE214",
      "batches": [
        "25CM11"
      ],
      "faculty": "AKG",
      "room": "TR8",
      "raw": "L-10M11CE214 25CM11 (AKG) TR8"
    },
    {
      "id": "mtech_2_FRI_2_cerrxr",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Practical/Lab",
      "courseCode": "25M17CE271",
      "batches": [
        "25SE11"
      ],
      "faculty": "TNM",
      "room": "ENVLAB",
      "raw": "P-25M17CE271 25SE11 (TNM) ENVLAB"
    },
    {
      "id": "mtech_2_FRI_3_u30lky",
      "semesterId": "mtech_2",
      "day": "FRI",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Practical/Lab",
      "courseCode": "25M17CE271",
      "batches": [
        "25SE11"
      ],
      "faculty": "TNM",
      "room": "ENVLAB",
      "raw": "P-25M17CE271 25SE11 (TNM) ENVLAB"
    },
    {
      "id": "mtech_2_SAT_0_wufw3i",
      "semesterId": "mtech_2",
      "day": "SAT",
      "slotIndex": 0,
      "time": "09:00 AM - 09:55 AM",
      "type": "Lecture",
      "courseCode": "24MS1BT211",
      "batches": [
        "25MB11",
        "25MM11"
      ],
      "faculty": "JTV",
      "room": "TR3",
      "raw": "L-24MS1BT211 25MB11,25MM11 (JTV) TR3"
    },
    {
      "id": "mtech_2_SAT_1_e6cfnl",
      "semesterId": "mtech_2",
      "day": "SAT",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "22M1WCI231/25BS1MA411",
      "batches": [
        "25CD11",
        "24P11"
      ],
      "faculty": "SST",
      "room": "TR1",
      "raw": "L-22M1WCI231/25BS1MA411 25CD11,24P11 (SST) TR1"
    },
    {
      "id": "mtech_4_MON_3_th2cv1",
      "semesterId": "mtech_4",
      "day": "MON",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "21MS1MB412",
      "batches": [
        "24MM11"
      ],
      "faculty": "HSD",
      "room": "TR1",
      "raw": "L-21MS1MB412 24MM11 (HSD) TR1"
    },
    {
      "id": "mtech_4_MON_1_t64p3m",
      "semesterId": "mtech_4",
      "day": "MON",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "20MSWBT432",
      "batches": [
        "24MB11"
      ],
      "faculty": "UDB",
      "room": "CR17",
      "raw": "L-20MSWBT432 24MB11 (UDB) CR17"
    },
    {
      "id": "mtech_4_MON_2_ldq0fi",
      "semesterId": "mtech_4",
      "day": "MON",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "20MSWBT433",
      "batches": [
        "24MB11"
      ],
      "faculty": "TTS",
      "room": "TR6",
      "raw": "L-20MSWBT433 24MB11 (TTS) TR6"
    },
    {
      "id": "mtech_4_MON_7_xdiyun",
      "semesterId": "mtech_4",
      "day": "MON",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "13P1WMA232",
      "batches": [
        "PHD_MAT"
      ],
      "faculty": "PKP",
      "room": "TR7",
      "raw": "L-13P1WMA232  PHD_MAT (PKP) TR7"
    },
    {
      "id": "mtech_4_TUE_3_3kuetj",
      "semesterId": "mtech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "20MSWBT433",
      "batches": [
        "24MB11"
      ],
      "faculty": "TTS",
      "room": "CR17",
      "raw": "L-20MSWBT433 24MB11 (TTS) CR17"
    },
    {
      "id": "mtech_4_TUE_6_5ag9co",
      "semesterId": "mtech_4",
      "day": "TUE",
      "slotIndex": 6,
      "time": "03:00 PM - 03:55 PM",
      "type": "Lecture",
      "courseCode": "21MS1MB412",
      "batches": [
        "24MM11"
      ],
      "faculty": "HSD",
      "room": "TR6",
      "raw": "L-21MS1MB412 24MM11 (HSD) TR6"
    },
    {
      "id": "mtech_4_TUE_7_wengp5",
      "semesterId": "mtech_4",
      "day": "TUE",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "25B11CC111",
      "batches": [
        "ONL_CERT_BIO"
      ],
      "faculty": "HSD",
      "room": "PTC",
      "raw": "L-25B11CC111 ONL_CERT_BIO (HSD) PTC"
    },
    {
      "id": "mtech_4_TUE_3_9ldnk1",
      "semesterId": "mtech_4",
      "day": "TUE",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "21MS1MB411",
      "batches": [
        "24MM11"
      ],
      "faculty": "AKT",
      "room": "CR18",
      "raw": "L-21MS1MB411 24MM11 (AKT) CR18"
    },
    {
      "id": "mtech_4_WED_7_79biox",
      "semesterId": "mtech_4",
      "day": "WED",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Tutorial",
      "courseCode": "25B11CC111",
      "batches": [
        "ONL_CERT_BIO"
      ],
      "faculty": "HSD",
      "room": "PTC",
      "raw": "T-25B11CC111 ONL_CERT_BIO (HSD) PTC"
    },
    {
      "id": "mtech_4_WED_2_nt16x9",
      "semesterId": "mtech_4",
      "day": "WED",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "21MS1MB411",
      "batches": [
        "24MM11"
      ],
      "faculty": "AKT",
      "room": "TR6",
      "raw": "L-21MS1MB411 24MM11 (AKT) TR6"
    },
    {
      "id": "mtech_4_THU_1_40yy0g",
      "semesterId": "mtech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "21MS1MB411",
      "batches": [
        "24MM11"
      ],
      "faculty": "AKT",
      "room": "TR7",
      "raw": "L-21MS1MB411 24MM11 (AKT) TR7"
    },
    {
      "id": "mtech_4_THU_2_9mkkdq",
      "semesterId": "mtech_4",
      "day": "THU",
      "slotIndex": 2,
      "time": "11:00 AM - 11:55 AM",
      "type": "Lecture",
      "courseCode": "21MS1MB412",
      "batches": [
        "24MM11"
      ],
      "faculty": "HSD",
      "room": "CR12",
      "raw": "L-21MS1MB412 24MM11 (HSD) CR12"
    },
    {
      "id": "mtech_4_THU_1_32o2ml",
      "semesterId": "mtech_4",
      "day": "THU",
      "slotIndex": 1,
      "time": "10:00 AM - 10:55 AM",
      "type": "Lecture",
      "courseCode": "20MSWBT432",
      "batches": [
        "24MB11"
      ],
      "faculty": "UDB",
      "room": "TR3",
      "raw": "L-20MSWBT432 24MB11 (UDB) TR3"
    },
    {
      "id": "mtech_4_THU_7_r0uska",
      "semesterId": "mtech_4",
      "day": "THU",
      "slotIndex": 7,
      "time": "04:00 PM - 04:55 PM",
      "type": "Lecture",
      "courseCode": "13P1WMA232",
      "batches": [
        "PHD_MAT"
      ],
      "faculty": "PKP",
      "room": "TR3",
      "raw": "L-13P1WMA232  PHD_MAT (PKP) TR3"
    },
    {
      "id": "mtech_4_SAT_3_ewkrh5",
      "semesterId": "mtech_4",
      "day": "SAT",
      "slotIndex": 3,
      "time": "12:00 PM - 12:55 PM",
      "type": "Lecture",
      "courseCode": "13P1WMA232",
      "batches": [
        "PHD_MAT"
      ],
      "faculty": "PKP",
      "room": "CR7",
      "raw": "L-13P1WMA232  PHD_MAT (PKP) CR7"
    }
  ],
  "meta": {
    "sourceUrl": "https://www.juit.ac.in/TTC/EVENSEM2026.xls",
    "sessionName": "Even Semester 2026 (Jan - Jun 2026)",
    "totalSessions": 1426
  }
};
