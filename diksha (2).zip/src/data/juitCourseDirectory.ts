// JUIT Course and Room Lookup Helpers for Even Semester 2026 Timetable

export const JUIT_COURSE_TITLES: Record<string, string> = {
  // 1st Year / 2nd Sem Courses
  '25B11MA211': 'Engineering Mathematics II',
  '18B11MA211': 'Mathematics II',
  '24B11MA212': 'Differential Equations & Linear Algebra',
  '25B11CI211': 'Computer Programming & Problem Solving',
  '25B11CI212': 'Data Structures & Fundamentals',
  '25B17CI271': 'Computer Programming Lab',
  '18B11PH211': 'Engineering Physics II',
  '18B11PH212': 'Applied Physics & Electromagnetics',
  '18B17PH271': 'Engineering Physics Lab',
  '25B17HS271': 'English & Professional Communication Lab',
  '23BB1HS211': 'Humanities & Social Sciences II',
  '23B11HS211': 'Professional Communication',
  '25B17GE171': 'Engineering Workshop & Fab Lab',
  '25B17GE172': 'Engineering Graphics & CAD Lab',
  '24B11EC211': 'Basic Electronics Engineering',

  // 2nd Year / 4th Sem Courses
  '25B11CI411': 'Operating Systems',
  '25B11CI412': 'Design & Analysis of Algorithms',
  '25B11CI413': 'Database Management Systems',
  '25B11CI414': 'Theory of Computation',
  '25B11CI415': 'Computer Organization & Architecture',
  '25B17CI471': 'Algorithms Lab',
  '25B17CI472': 'Database Systems Lab',
  '25B17CI473': 'Operating Systems Lab',
  '25B17CI476': 'Advanced Java & Web Tech Lab',
  '24B17CI471': 'Software Engineering Lab',
  '25B1WCI471': 'Python & Data Science Workshop',
  '25B1WCI431': 'Competitive Programming Seminar',
  '18B11CE411': 'Structural Analysis & Mechanics',
  '18B17CE471': 'Concrete & Materials Lab',
  '18B11BT411': 'Molecular Biology & Genetics',
  '18B17BT471': 'Biotechnology Lab II',
  '18B11EC411': 'Signals & Systems',
  '18B17EC471': 'Analog Electronics Lab',

  // 3rd Year / 6th Sem Courses
  '18B11CI611': 'Compiler Design',
  '18B11CI612': 'Computer Networks',
  '18B11CI613': 'Artificial Intelligence & Intelligent Systems',
  '18B17CI671': 'Computer Networks Lab',
  '18B17CI672': 'Compiler Design Lab',
  '18B17CI673': 'AI & Machine Learning Lab',
  '24B17CI671': 'Full Stack Web Development Project Lab',
  '18B1WCI674': 'Information Security & Cryptography Lab',
  '18B1WCI675': 'Cloud Computing & DevOps Workshop',
  '18B11EC611': 'Digital Communication Systems',
  '18B11EC612': 'VLSI Design & Technology',
  '18B17EC672': 'VLSI Cadence Simulation Lab',
  '18B11BT611': 'Recombinant DNA Technology',
  '18B11BT612': 'Bioprocess Engineering',
  '18B17BT671': 'Recombinant DNA Technology Lab',
  '18B17BT672': 'Bioprocess Engineering Lab',
  '18B11CE611': 'Design of Reinforced Concrete Structures',
  '18B17CE671': 'Structural Engineering Simulation Lab',

  // 4th Year / 8th Sem Electives
  '18B11CI811': 'Big Data Analytics',
  '18B11CI812': 'Deep Learning & Neural Networks',
  '18B11CI813': 'Internet of Things (IoT) Architectures',
  '18B11CI814': 'Cyber Forensics & Malware Analysis',
  '18B17CI871': 'Major Project Phase II & Capstone',
  '18B11EC811': 'Wireless Sensor Networks',
  '18B11CE811': 'Earthquake Engineering & Seismic Design',
  '18B11BT811': 'Stem Cell Technology & Therapeutics'
};

export const JUIT_FACULTY_NAMES: Record<string, { name: string; dept: string; cabin?: string }> = {
  // Provided Faculty (CSE Core & Head)
  'PKP': { name: 'Prof. (Dr.) Pradeep Kumar Gupta', dept: 'Computer Science & Engineering', cabin: 'F-301' },
  'PDK': { name: 'Prof. (Dr.) Pardeep Kumar', dept: 'Computer Science & Engineering', cabin: 'F-308' },
  'AKT': { name: 'Dr. Amit Kumar', dept: 'Computer Science & Engineering', cabin: 'F-315' },
  'EKG': { name: 'Dr. Ekta Gandotra', dept: 'Computer Science & Engineering', cabin: 'F-322' },
  'HRS': { name: 'Dr. Hari Singh', dept: 'Computer Science & Engineering', cabin: 'F-311' },
  'RBT': { name: 'Dr. Ravindara Bhatt', dept: 'Computer Science & Engineering', cabin: 'F-311' },
  'AMS': { name: 'Dr. Aman Sharma', dept: 'Computer Science & Engineering', cabin: 'F-218' },
  'AMV': { name: 'Dr. Amol Vasudeva', dept: 'Computer Science & Engineering', cabin: 'F-326' },
  'ANT': { name: 'Dr. Anita', dept: 'Computer Science & Engineering', cabin: 'F-102' },
  
  // Existing Faculty for Timetable Coverage
  'VSG': { name: 'Dr. Vivek Sehgal', dept: 'Computer Science & Engineering', cabin: 'F-308' },
  'HRI': { name: 'Dr. Hemraj Saini', dept: 'Computer Science & Engineering', cabin: 'F-312' },
  'NUK': { name: 'Dr. Nafis U. Khan', dept: 'Computer Science & Engineering', cabin: 'F-315' },
  'RVS': { name: 'Dr. Ravindara Bhatt (Old Code)', dept: 'Computer Science & Engineering', cabin: 'F-320' },
  'RKI': { name: 'Dr. Rakesh Kumar', dept: 'Mathematics', cabin: 'F-214' },
  'SKK': { name: 'Prof. (Dr.) Sunil Kumar Khah', dept: 'Physics & Materials Science', cabin: 'F-218' },
  'HSR': { name: 'Dr. Harsh Sohal', dept: 'Physics & Materials Science', cabin: 'F-222' },
  'MDS': { name: 'Dr. Mandeep Singh', dept: 'Mathematics', cabin: 'F-210' },
  'TNS': { name: 'Dr. Tanu Sharma', dept: 'Humanities & Social Sciences', cabin: 'F-104' },
  'SSA': { name: 'Dr. Shweta Sharma', dept: 'Computer Science & Engineering', cabin: 'F-324' },
  'SMA': { name: 'Dr. Shailendra Shukla', dept: 'Computer Science & Engineering', cabin: 'F-318' },
  'DBK': { name: 'Dr. Deepak Sharma', dept: 'Computer Science & Engineering', cabin: 'F-326' },
  'SHR': { name: 'Prof. (Dr.) Shruti Jain', dept: 'Electronics & Communication', cabin: 'F-226' },
  'EMP': { name: 'Dr. Emjee Puthooran', dept: 'Electronics & Communication', cabin: 'F-228' },
  'NSA': { name: 'Dr. Neeru Sharma', dept: 'Electronics & Communication', cabin: 'F-230' },
  'SRJ': { name: 'Dr. Salman Raju Dey', dept: 'Electronics & Communication', cabin: 'F-232' },
  'SDS': { name: 'Prof. (Dr.) Sudhir Kumar', dept: 'Biotechnology & Bioinformatics', cabin: 'F-110' },
  'JTV': { name: 'Dr. Jata Shankar', dept: 'Biotechnology & Bioinformatics', cabin: 'F-114' },
  'PBB': { name: 'Dr. Poonam Sharma', dept: 'Biotechnology & Bioinformatics', cabin: 'F-118' }
};

export function getCourseTitle(code: string): string {
  if (!code) return 'Scheduled Academic Session';
  const cleanCode = code.split('/')[0].trim();
  return JUIT_COURSE_TITLES[cleanCode] || `${cleanCode} (Course Session)`;
}

export function getFacultyDetail(code: string): { name: string; dept: string; cabin?: string } {
  if (!code) return { name: 'Department Faculty', dept: 'Academic Faculty' };
  const clean = code.split(',')[0].trim().toUpperCase();
  return JUIT_FACULTY_NAMES[clean] || { name: `Faculty (${code})`, dept: 'Teaching Faculty' };
}

export function mapRoomToCampusBlockId(room: string): string {
  if (!room) return 'block_academic';
  const upper = room.toUpperCase();
  if (upper.includes('LT') || upper.includes('DLC') || upper.includes('AUDI')) {
    return 'block_academic';
  }
  if (upper.includes('PHLAB') || upper.includes('PHYSIC')) {
    return 'block_academic';
  }
  if (upper.includes('CR') || upper.includes('TR') || upper.includes('CL') || upper.includes('LAB') || upper.includes('ECL')) {
    return 'block_faculty_f';
  }
  if (upper.includes('LIB') || upper.includes('LRC')) {
    return 'block_library';
  }
  if (upper.includes('BT') || upper.includes('BIO') || upper.includes('GENOME')) {
    return 'block_faculty_f';
  }
  return 'block_academic';
}
