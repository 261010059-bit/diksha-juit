import { CampusData } from '../types';
import { EVEN_SEM_2026_DATA } from './evenSem2026Data';

export const INITIAL_CAMPUS_DATA: CampusData = {
  even_sem_2026: EVEN_SEM_2026_DATA,
  mess_menu: {
    monday: {
      breakfast: 'Stuffed Parantha, Plain Curd, Daliya, Sprouts (Chat Masala), Bread, Butter, Jam, Pickle, Tea',
      lunch: 'Aaloo Methi, Kadhi Pakoda, Multigrain Tandoori Roti & Plain Chapati, Rice, Salad, Papad, Pear',
      dinner: 'Dal Panchranga, Egg Curry / Egg Bhurji, Aaloo Beans, Multigrain Tandoori & Plain Chapati, Rice, Salad, Corn Salad',
      specialNote: 'Sweet Dish: Semiya. Milk Distribution: 09:15PM to 09:45PM'
    },
    tuesday: {
      breakfast: 'Veg. Sandwich, Macaroni (Zero Maida), Cornflakes, Kala Chana Chat, Bread, Butter, Jam, Milk, Tea',
      lunch: 'Dal Rajmah, Aaloo Shimla Mirch, Plain Curd, Tandoori Roti & Plain Chapati, Rice, Salad, Apple Royal',
      dinner: 'Dal Moong Sabut, Shahi Paneer, Tandoori Roti & Plain Chapati, Rice, Salad',
      specialNote: 'Sweet Dish: Besan Ladoo. Milk Distribution: 09:15PM to 09:45PM'
    },
    wednesday: {
      breakfast: 'Poha, Veg Cutlet, Daliya, Boiled Egg, Sprouts (Chat Masala), Bread, Butter, Jam, Tea',
      lunch: 'Choley Bhature, Biryani, Dahi Vada/Pakodi With Sounth Chutney, Onion Salad & Lemon, Banana',
      dinner: 'Dal Chana Urad, Mix Veg., Tandoori Roti & Plain Chapati, Matar Pulao, Salad, Green Chutney',
      specialNote: 'Sweet Dish: Amul Butter Scotch/Mango Cup. Milk Distribution: 09:15PM to 09:45PM'
    },
    thursday: {
      breakfast: 'Poori, Aaloo Tomato Sabji, Veg Semiya, Kala Chana Chaat, Bread, Butter, Jam, Cold Coffee, Apple Golden',
      lunch: 'Dal Moong Malka, Matar Paneer, Boondi Raita, Tandoori Roti & Plain Chapati, Salad',
      dinner: 'Dal Arhar, Soya Chaap Curry, Tandoori Roti & Plain, Rice, Salad',
      specialNote: 'Sweet Dish: Sooji Halwa. Milk Distribution: 09:15PM to 09:45PM'
    },
    friday: {
      breakfast: 'Kachori Dal / Matar, Aaloo Sabji, Maggi (Zero Maida), Boiled Egg, Daliya, Sprouts (Chat Masala), Bread, Butter, Jam, Tea',
      lunch: 'Dal Masoor Sabut, Mix Veg., Boondi Raita, Tandoori Roti & Plain Chapati, Rice, Corn Salad, Banana',
      dinner: 'Dal Maharani, Kadhai Paneer / Paneer Bhurji, Tandoori Roti & Plain Chapati, Rice, Salad',
      specialNote: 'Sweet Dish: Gulab Jamun. Milk Distribution: 09:15PM to 09:45PM'
    },
    saturday: {
      breakfast: 'Idli, Sambhar, Vada, Upma, Coconut Chutney, Kala Chana Chat, Bread, Butter, Jam, Cold Coffee',
      lunch: 'Dal Rajmah, Lauki Tomato, Lassi, Tandoori Roti & Plain Chapati, Rice, Salad, Guava',
      dinner: 'Dal Chana Masala, Dry Aaloo Matar, Multigrain Tandoori Roti & Plain Chapati, Matar Pulao, Salad, Green Chutney',
      specialNote: 'Sweet Dish: Fruit Custard. Milk Distribution: 09:15PM to 09:45PM'
    },
    sunday: {
      breakfast: 'Bread Pakora / Pav Bhaji, White Sauce Pasta (Zero Maida), Cornflakes, Omlette, Bread, Butter, Jam, Milk, Tea',
      lunch: 'Paneer Onion Parantha, Veg Biryani, Curd, Butter, Salad, Papad, Pickle, Amul Kulfi - Kashmiri',
      dinner: 'Dal Makhani, Masala Bhindi / Baingan Bharta, Tandoori Roti & Plain Chapati, Rice, Salad',
      specialNote: 'Sweet Dish: Rice Kheer. Milk Distribution: 09:15PM to 09:45PM'
    }
  },
  tuckshop: {
    timings: '9:00 AM - 1:00 PM and 3:00 PM - 5:00 PM',
    location: 'Near Hostel Block C & Geeta Bhawan pathway',
    popularItems: [
      'Cheese Maggi & Masala Maggi',
      'Grilled Paneer Sandwich',
      'Cold Coffee & Hazelnut Frappe',
      'Aloo & Paneer Patties',
      'Red Bull, Mountain Dew & Amul Lassi',
      'Exam Stationery & Spiral Note Pads',
      'Midnight Snacks & Biscuits'
    ],
    paymentModes: ['Cash', 'UPI (Google Pay, PhonePe, Paytm)', 'BHIM'],
    contactNumber: '+91 1792 239240 (Ext: 240)',
    statusNote: 'Note: Tuckshop timings follow a split schedule (Morning: 9-1, Afternoon: 3-5).'
  },
  cafeteria: {
    timings: '9:00 AM - 9:30 PM',
    location: 'Ground Floor, Academic Complex Annex (Beside LT-3)',
    menuHighlights: [
      'Crispy Masala Dosa with Chutneys (₹60)',
      'Mini Student Thali with 2 Sabzis & Roti (₹75)',
      'Veg Manchurian with Fried Rice (₹90)',
      'Cold Coffee with Vanilla Scoop (₹45)',
      'Fresh Kinnow / Mosambi Juice (Seasonal) (₹50)',
      'Chilli Potato & Hakka Noodles (₹80)'
    ],
    paymentModes: ['UPI', 'Campus RFID Card', 'Cash'],
    seatingCapacity: '150+ indoor & outdoor scenic mountain-view seats'
  },
  laundry: {
    process: [
      '1. Sort clothes and place them in the provided linen laundry bag labeled with your Name, Roll Number, and Hostel Room.',
      '2. Deposit clothes at the Laundry Counter located at Hostel Block B (Basement entrance) between 8:30 AM and 11:00 AM.',
      '3. Collect your stamped token slip containing date of submission and verified piece count.',
      '4. Normal turnaround is 48 hours. Express same-day service (limited slots) ready in 24 hours.',
      '5. Show physical token slip or verified in-app receipt at the counter to collect washed, dried, and machine-ironed clothes.'
    ],
    timings: '8:30 AM - 5:30 PM (Monday to Saturday, Closed on Sundays)',
    turnaroundTime: '48 hours (Standard) / 24 hours (Priority Token)',
    contactPerson: 'Mr. Ramesh Sharma (Laundry Manager, Ext. 402)',
    cost: 'Free under student amenity quota (up to 30 garments/month); ₹10 per additional piece / bedsheet.',
    location: 'Hostel Block B Basement (Rear slope entrance toward Sports Complex)',
    helpline: '+91 1792 239402'
  },
  timetable: [
    {
      batchId: 'cse_2027',
      batchName: 'B.Tech CSE - 2027 Batch (2nd Year)',
      department: 'Computer Science & Engineering',
      semester: '4th Semester (Even 2026)',
      schedule: {
        monday: [
          { time: '09:00 - 10:00', subject: 'Data Structures & Algorithms', faculty: 'Dr. Pradeep Kumar', room: 'LT-1', code: 'CS201' },
          { time: '10:00 - 11:00', subject: 'Database Management Systems', faculty: 'Dr. Vivek Sehgal', room: 'LT-1', code: 'CS203' },
          { time: '11:00 - 12:00', subject: 'Computer Organization & Architecture', faculty: 'Dr. Nafis U. Khan', room: 'LT-2', code: 'CS205' },
          { time: '12:00 - 01:00', subject: 'Discrete Mathematics', faculty: 'Dr. Rakesh Kumar', room: 'CR-102', code: 'MA201' },
          { time: '02:00 - 04:00', subject: 'DSA Lab (Group A) / DBMS Lab (Group B)', faculty: 'Prof. P. Sharma / Dr. V. Sehgal', room: 'Turing Computer Lab (F-301)', code: 'CS271' }
        ],
        tuesday: [
          { time: '09:00 - 10:00', subject: 'Operating Systems', faculty: 'Dr. Geetanjali Rathee', room: 'LT-1', code: 'CS207' },
          { time: '10:00 - 11:00', subject: 'Software Engineering Principles', faculty: 'Dr. Ravindara Bhatt', room: 'LT-1', code: 'CS209' },
          { time: '11:00 - 01:00', subject: 'Web Technologies Lab', faculty: 'Er. Aman Sharma', room: 'Software Lab 3', code: 'CS273' },
          { time: '02:00 - 03:00', subject: 'Data Structures & Algorithms', faculty: 'Dr. Pradeep Kumar', room: 'LT-2', code: 'CS201' },
          { time: '03:00 - 04:00', subject: 'Environmental Studies', faculty: 'Dr. Sudhir Syal', room: 'LT-2', code: 'BT201' }
        ],
        wednesday: [
          { time: '09:00 - 10:00', subject: 'Database Management Systems', faculty: 'Dr. Vivek Sehgal', room: 'LT-1', code: 'CS203' },
          { time: '10:00 - 11:00', subject: 'Computer Organization & Architecture', faculty: 'Dr. Nafis U. Khan', room: 'LT-2', code: 'CS205' },
          { time: '11:00 - 12:00', subject: 'Operating Systems', faculty: 'Dr. Geetanjali Rathee', room: 'LT-1', code: 'CS207' },
          { time: '02:00 - 04:00', subject: 'Linux & OS Lab (All Groups)', faculty: 'Dr. G. Rathee / TAs', room: 'Lab F-302', code: 'CS275' },
          { time: '04:00 - 05:00', subject: 'Technical Communication & Life Skills', faculty: 'Dr. Anupriya Kaur', room: 'CR-104', code: 'HS201' }
        ],
        thursday: [
          { time: '09:00 - 10:00', subject: 'Discrete Mathematics', faculty: 'Dr. Rakesh Kumar', room: 'CR-102', code: 'MA201' },
          { time: '10:00 - 11:00', subject: 'Data Structures & Algorithms', faculty: 'Dr. Pradeep Kumar', room: 'LT-1', code: 'CS201' },
          { time: '11:00 - 12:00', subject: 'Software Engineering Principles', faculty: 'Dr. Ravindara Bhatt', room: 'LT-1', code: 'CS209' },
          { time: '02:00 - 04:00', subject: 'DBMS Lab (Group A) / DSA Lab (Group B)', faculty: 'Dr. V. Sehgal / Dr. P. Kumar', room: 'Turing Computer Lab', code: 'CS271' }
        ],
        friday: [
          { time: '09:00 - 10:00', subject: 'Computer Organization & Architecture', faculty: 'Dr. Nafis U. Khan', room: 'LT-2', code: 'CS205' },
          { time: '10:00 - 11:00', subject: 'Operating Systems', faculty: 'Dr. Geetanjali Rathee', room: 'LT-1', code: 'CS207' },
          { time: '11:00 - 12:00', subject: 'Database Management Systems', faculty: 'Dr. Vivek Sehgal', room: 'LT-1', code: 'CS203' },
          { time: '02:00 - 04:00', subject: 'Python for Data Science Workshop', faculty: 'Er. Shailendra Shukla', room: 'Aryabhata Lab', code: 'CS277' }
        ],
        saturday: [
          { time: '09:30 - 11:00', subject: 'Remedial & Doubts Clearance Session', faculty: 'Department Faculty', room: 'CR-102', code: 'TUT' },
          { time: '11:00 - 01:00', subject: 'Coding Club & Hackathon Mentorship', faculty: 'ACM / IEEE Student Chapters', room: 'Auditorium Hall', code: 'ACT' }
        ],
        sunday: []
      }
    },
    {
      batchId: 'it_2027',
      batchName: 'B.Tech IT - 2027 Batch (2nd Year)',
      department: 'Information Technology',
      semester: '4th Semester (Even 2026)',
      schedule: {
        monday: [
          { time: '09:00 - 10:00', subject: 'Object Oriented Programming with Java', faculty: 'Dr. Amit Srivastava', room: 'LT-3', code: 'IT201' },
          { time: '10:00 - 11:00', subject: 'Design & Analysis of Algorithms', faculty: 'Dr. Anita Mohanty', room: 'LT-3', code: 'IT203' },
          { time: '11:00 - 01:00', subject: 'Java Programming Lab', faculty: 'Dr. A. Srivastava', room: 'Lab F-201', code: 'IT271' },
          { time: '02:00 - 03:00', subject: 'Computer Networks', faculty: 'Dr. Hemraj Saini', room: 'LT-2', code: 'IT205' }
        ],
        tuesday: [
          { time: '09:00 - 10:00', subject: 'Computer Networks', faculty: 'Dr. Hemraj Saini', room: 'LT-2', code: 'IT205' },
          { time: '10:00 - 11:00', subject: 'Design & Analysis of Algorithms', faculty: 'Dr. Anita Mohanty', room: 'LT-3', code: 'IT203' },
          { time: '02:00 - 04:00', subject: 'Networks Simulator Lab', faculty: 'Dr. H. Saini', room: 'Lab F-203', code: 'IT273' }
        ],
        wednesday: [
          { time: '10:00 - 11:00', subject: 'Information Security Essentials', faculty: 'Dr. Y. S. Chauhan', room: 'LT-3', code: 'IT207' },
          { time: '11:00 - 12:00', subject: 'Object Oriented Programming with Java', faculty: 'Dr. Amit Srivastava', room: 'LT-3', code: 'IT201' },
          { time: '02:00 - 04:00', subject: 'Algorithms Lab', faculty: 'Dr. A. Mohanty', room: 'Turing Lab', code: 'IT275' }
        ],
        thursday: [
          { time: '09:00 - 10:00', subject: 'Design & Analysis of Algorithms', faculty: 'Dr. Anita Mohanty', room: 'LT-3', code: 'IT203' },
          { time: '10:00 - 11:00', subject: 'Information Security Essentials', faculty: 'Dr. Y. S. Chauhan', room: 'LT-3', code: 'IT207' },
          { time: '11:00 - 12:00', subject: 'Computer Networks', faculty: 'Dr. Hemraj Saini', room: 'LT-2', code: 'IT205' }
        ],
        friday: [
          { time: '09:00 - 10:00', subject: 'Object Oriented Programming with Java', faculty: 'Dr. Amit Srivastava', room: 'LT-3', code: 'IT201' },
          { time: '10:00 - 11:00', subject: 'Information Security Essentials', faculty: 'Dr. Y. S. Chauhan', room: 'LT-3', code: 'IT207' },
          { time: '02:00 - 04:00', subject: 'Web App Security Project Lab', faculty: 'Dr. Y. S. Chauhan', room: 'Lab F-201', code: 'IT277' }
        ],
        saturday: [
          { time: '10:00 - 12:00', subject: 'Industry Seminar & Project Review', faculty: 'Guest Experts / Dr. A. Srivastava', room: 'Audi-2', code: 'SEM' }
        ],
        sunday: []
      }
    },
    {
      batchId: 'ece_2026',
      batchName: 'B.Tech ECE - 2026 Batch (3rd Year)',
      department: 'Electronics & Communication',
      semester: '6th Semester (Even 2026)',
      schedule: {
        monday: [
          { time: '09:00 - 10:00', subject: 'Digital Signal Processing', faculty: 'Dr. Salman Raju Dey', room: 'CR-201', code: 'EC301' },
          { time: '10:00 - 11:00', subject: 'VLSI Design & Technology', faculty: 'Dr. Shruti Jain', room: 'CR-201', code: 'EC303' },
          { time: '11:00 - 12:00', subject: 'Wireless & Mobile Communication', faculty: 'Dr. Neeru Sharma', room: 'CR-202', code: 'EC305' },
          { time: '02:00 - 04:00', subject: 'DSP MATLAB Lab', faculty: 'Dr. S. R. Dey', room: 'DSP Lab (Block D)', code: 'EC371' }
        ],
        tuesday: [
          { time: '09:00 - 10:00', subject: 'Antenna & Wave Propagation', faculty: 'Dr. Emjee Puthooran', room: 'CR-201', code: 'EC307' },
          { time: '10:00 - 11:00', subject: 'Digital Signal Processing', faculty: 'Dr. Salman Raju Dey', room: 'CR-201', code: 'EC301' },
          { time: '02:00 - 04:00', subject: 'VLSI Cadence Lab', faculty: 'Dr. Shruti Jain', room: 'VLSI Research Lab', code: 'EC373' }
        ],
        wednesday: [
          { time: '09:00 - 10:00', subject: 'VLSI Design & Technology', faculty: 'Dr. Shruti Jain', room: 'CR-201', code: 'EC303' },
          { time: '10:00 - 11:00', subject: 'Wireless & Mobile Communication', faculty: 'Dr. Neeru Sharma', room: 'CR-202', code: 'EC305' },
          { time: '11:00 - 12:00', subject: 'Antenna & Wave Propagation', faculty: 'Dr. Emjee Puthooran', room: 'CR-201', code: 'EC307' }
        ],
        thursday: [
          { time: '09:00 - 10:00', subject: 'Wireless & Mobile Communication', faculty: 'Dr. Neeru Sharma', room: 'CR-202', code: 'EC305' },
          { time: '10:00 - 11:00', subject: 'Antenna & Wave Propagation', faculty: 'Dr. Emjee Puthooran', room: 'CR-201', code: 'EC307' },
          { time: '02:00 - 04:00', subject: 'Microwave & Antenna Hardware Lab', faculty: 'Dr. E. Puthooran', room: 'RF Lab', code: 'EC375' }
        ],
        friday: [
          { time: '09:00 - 10:00', subject: 'Digital Signal Processing', faculty: 'Dr. Salman Raju Dey', room: 'CR-201', code: 'EC301' },
          { time: '10:00 - 11:00', subject: 'VLSI Design & Technology', faculty: 'Dr. Shruti Jain', room: 'CR-201', code: 'EC303' },
          { time: '02:00 - 04:00', subject: 'Embedded Systems & IoT Mini Project', faculty: 'Dr. Vikas Baghel', room: 'IoT Lab', code: 'EC377' }
        ],
        saturday: [],
        sunday: []
      }
    }
  ],
  campus_map: {
    blocks: [
      {
        id: 'block_academic',
        name: 'Academic Block (LT Complex)',
        shortName: 'LT Complex',
        category: 'academic',
        description: 'Main lecture theater complex housing LT-1, LT-2, LT-3, Dean of Academics office, and examination halls.',
        coordinates: { x: 42, y: 38 },
        keyRooms: ['Lecture Theatre 1 (LT-1)', 'Lecture Theatre 2 (LT-2)', 'Lecture Theatre 3 (LT-3)', 'Dean Academics Office (Room A-102)', 'Central Exam Cell'],
        accessibleFeatures: ['Ramp entry', 'Wheelchair accessible elevators', 'Water purifiers on every level', 'Restrooms']
      },
      {
        id: 'block_faculty_f',
        name: 'Faculty Block F',
        shortName: 'Block F',
        category: 'academic',
        description: 'Multi-storey building hosting faculty consultation cabins, departmental HoD offices (CSE, IT, ECE, BT/BI), and advanced research labs.',
        coordinates: { x: 55, y: 32 },
        keyRooms: ['F-101 to F-120 (BT/BI Faculty)', 'F-201 to F-230 (ECE & Math Faculty)', 'F-301 to F-340 (CSE & IT Faculty)', 'Turing Computing Lab', 'Aryabhata Data Science Lab'],
        accessibleFeatures: ['Faculty elevators', 'Notice boards', 'Student consultation lounges']
      },
      {
        id: 'block_admin',
        name: 'Administrative Complex',
        shortName: 'Admin Block',
        category: 'admin',
        description: 'Houses the Vice Chancellor Secretariat, Registrar Office, Finance & Accounts (Fee counters), and Admissions Wing.',
        coordinates: { x: 30, y: 25 },
        keyRooms: ['Registrar Office', 'Finance & Student Accounts (Window 1-4)', 'VC Office', 'Admissions & Scholarships Cell'],
        accessibleFeatures: ['Fee payment counters', 'Official document verification', 'Student helpdesk']
      },
      {
        id: 'block_library',
        name: 'Learning Resource Centre (LRC) & Central Library',
        shortName: 'Central Library',
        category: 'academic',
        description: 'Three-tier library with over 45,000 volumes, IEEE/ACM digital access consoles, silent reading rooms, and discussion pods.',
        coordinates: { x: 48, y: 52 },
        keyRooms: ['Digital Library & OPAC Consoles', 'Periodical & Journal Section', '24x7 Reading Hall (Exam season)', 'Reprography & Book Bank'],
        accessibleFeatures: ['High-speed Wi-Fi', 'Power sockets on reading desks', 'Quiet study pods']
      },
      {
        id: 'block_hostel_boys',
        name: 'Boys Hostels (Geeta Bhawan, Block A, B & C)',
        shortName: 'Boys Hostels',
        category: 'hostel',
        description: 'Residential blocks for male students with mountain-facing balconies, high-speed Wi-Fi, table tennis rooms, and laundry points.',
        coordinates: { x: 68, y: 65 },
        keyRooms: ['Hostel Block A (1st Year)', 'Hostel Block B (2nd Year & Laundry)', 'Hostel Block C (3rd & Final Year)', 'Warden Offices', 'Common TV Rooms'],
        accessibleFeatures: ['24/7 Security guard', 'Water coolers with RO', 'Basement Laundry Counter (Block B)']
      },
      {
        id: 'block_hostel_girls',
        name: 'Girls Hostels (Sharda Bhawan & Saraswati)',
        shortName: 'Girls Hostels',
        category: 'hostel',
        description: 'Dedicated secure residential accommodations for female students equipped with biometric access, gym, common study area, and courtyard.',
        coordinates: { x: 22, y: 70 },
        keyRooms: ['Sharda Bhawan 1 & 2', 'Girls Common Recreation Lounge', 'Chief Warden Residence', 'Girls Laundry Collection Point'],
        accessibleFeatures: ['Biometric check-in', 'Full-time female security guard', 'In-house medical first aid kit']
      },
      {
        id: 'block_mess_dining',
        name: 'Annapurna Dining Hall & Student Cafeteria',
        shortName: 'Annapurna Mess',
        category: 'amenity',
        description: 'Large dining facility accommodating 1,200+ students per sitting. Separate vegetarian & non-veg counters with hot water dispensers.',
        coordinates: { x: 50, y: 72 },
        keyRooms: ['Mess Ground Floor (Boys Wing)', 'Mess First Floor (Girls & Staff Wing)', 'Student Cafeteria Annex', 'Night Tuckshop Pathway'],
        accessibleFeatures: ['Sanitized wash areas', 'Menu display screen', 'Dietary feedback box']
      },
      {
        id: 'block_tuckshop',
        name: 'Campus Tuckshop & Grocery Point',
        shortName: 'Tuckshop',
        category: 'amenity',
        description: 'Student hub for quick bites (Maggi, Sandwiches, Cold Coffee), daily essentials, toiletries, and printing/stationery.',
        coordinates: { x: 62, y: 76 },
        keyRooms: ['Snack Counter', 'Stationery & Printing Stall', 'UPI Payment Kiosk'],
        accessibleFeatures: ['Open until 11:00 PM', 'Quick takeaways']
      },
      {
        id: 'block_sports_sac',
        name: 'Student Activity Centre (SAC) & Sports Arena',
        shortName: 'SAC & Sports Ground',
        category: 'sports',
        description: 'Recreational complex with modern gymnasium, indoor badminton courts, outdoor basketball, volleyball courts, and cricket nets.',
        coordinates: { x: 75, y: 45 },
        keyRooms: ['Modern Fitness Gym', 'Indoor Badminton Courts (Wooden)', 'Table Tennis Arena', 'Sports Officer Office'],
        accessibleFeatures: ['Floodlit basketball court', 'Locker facilities', 'Drinking water fountain']
      },
      {
        id: 'block_dispensary',
        name: 'Campus Dispensary & Medical Health Centre',
        shortName: 'Medical Centre',
        category: 'amenity',
        description: '24/7 health post with resident medical officer, emergency observation beds, essential medicines, and 24x7 ambulance service.',
        coordinates: { x: 35, y: 55 },
        keyRooms: ['Doctor Consultation Chamber', 'Day Care Observation Beds', 'Pharmacy Dispensing Counter', 'Emergency Ambulance Bay'],
        accessibleFeatures: ['24x7 Emergency helpline', 'Free generic medicines for students', 'Nebulizer & ECG facility']
      }
    ],
    mapImageUrl: '/assets/juit_campus_map_vector.svg'
  },
  faculty: [
    {
      id: 'fac_1',
      name: 'Prof. (Dr.) Pradeep Kumar Gupta',
      department: 'Computer Science & Engineering',
      designation: 'Professor and Head CSE - Core Computing Group',
      cabin: 'F-301, 3rd Floor, Faculty Block F',
      inchargeFor: ['CSE Core Computing', 'HOD CSE', 'Department Academics'],
      email: 'pradeepkumar.gupta@juitsolan.in',
      availableHours: 'Mon & Wed: 03:00 PM - 04:30 PM',
      phoneExtension: 'Ext. 242',
      researchArea: 'PhD (JUIT), PDF (South Africa)'
    },
    {
      id: 'fac_2',
      name: 'Prof. (Dr.) Pardeep Kumar',
      department: 'Computer Science & Engineering',
      designation: 'Professor, SM-ACM',
      cabin: 'F-308, 3rd Floor, Faculty Block F',
      inchargeFor: ['ACM Student Chapter', 'Senior Member ACM'],
      email: 'pardeep.kumar@juit.ac.in',
      availableHours: 'Tue & Thu: 11:30 AM - 01:00 PM',
      phoneExtension: 'Ext. 308',
      researchArea: 'PhD (UTU Dehradun)'
    },
    {
      id: 'fac_3',
      name: 'Dr. Amit Kumar',
      department: 'Computer Science & Engineering',
      designation: 'Associate Professor',
      cabin: 'F-315, 3rd Floor, Faculty Block F',
      inchargeFor: ['Academic Support'],
      email: 'amit.kumar@juit.ac.in',
      availableHours: 'Mon to Fri: 04:00 PM - 05:00 PM',
      phoneExtension: 'Ext. 209',
      researchArea: 'PhD (BIT Mesra)'
    },
    {
      id: 'fac_4',
      name: 'Dr. Ekta Gandotra',
      department: 'Computer Science & Engineering',
      designation: 'Associate Professor',
      cabin: 'F-322, 3rd Floor, Faculty Block F',
      inchargeFor: ['Research Coordination'],
      email: 'ekta.gandotra@juitsolan.in',
      availableHours: 'Mon & Thu: 02:30 PM - 04:00 PM',
      phoneExtension: 'Ext. 289',
      researchArea: 'PhD (PEC Chandigarh)'
    },
    {
      id: 'fac_5',
      name: 'Dr. Hari Singh',
      department: 'Computer Science & Engineering',
      designation: 'Associate Professor',
      cabin: 'F-311, 3rd Floor, Faculty Block F',
      inchargeFor: ['Technical Projects'],
      email: 'hari.singh@juitsolan.in',
      availableHours: 'Wed & Fri: 03:00 PM - 05:00 PM',
      phoneExtension: 'Ext. 296',
      researchArea: 'PhD (Thapar University)'
    },
    {
      id: 'fac_6',
      name: 'Dr. Ravindara Bhatt',
      department: 'Computer Science & Engineering',
      designation: 'Associate Professor',
      cabin: 'F-311, 3rd Floor, Faculty Block F',
      inchargeFor: ['Training & Placement'],
      email: 'ravindara.bhatt@juit.ac.in',
      availableHours: 'Tue & Fri: 03:00 PM - 04:30 PM',
      phoneExtension: 'Ext. 283',
      researchArea: 'PhD (IIT Kharagpur)'
    },
    {
      id: 'fac_7',
      name: 'Dr. Aman Sharma',
      department: 'Computer Science & Engineering',
      designation: 'Assistant Professor (SG)',
      cabin: 'F-218, 2nd Floor, Faculty Block F',
      inchargeFor: ['Web Technologies', 'Coding Club'],
      email: 'aman.sharma@juit.ac.in',
      availableHours: 'Mon & Wed: 11:00 AM - 12:30 PM',
      phoneExtension: 'Ext. 348',
      researchArea: 'PhD (Thapar University)'
    },
    {
      id: 'fac_8',
      name: 'Dr. Amol Vasudeva',
      department: 'Computer Science & Engineering',
      designation: 'Assistant Professor (SG)',
      cabin: 'F-326, 3rd Floor, Faculty Block F',
      inchargeFor: ['Network Admin'],
      email: 'amol.vasudeva@juit.ac.in',
      availableHours: 'Mon to Thu: 02:00 PM - 03:30 PM',
      phoneExtension: 'Ext. 273',
      researchArea: 'PhD (HPU)'
    },
    {
      id: 'fac_9',
      name: 'Dr. Anita',
      department: 'Computer Science & Engineering',
      designation: 'Assistant Professor (SG)',
      cabin: 'F-102, 1st Floor, Faculty Block F',
      inchargeFor: ['Academic Counseling'],
      email: 'anita@juitsolan.in',
      availableHours: 'Tue & Thu: 03:30 PM - 05:00 PM',
      phoneExtension: 'Ext. 238',
      researchArea: 'PhD (YMCAUST)'
    }
  ],
  campus_lynx: [
    {
      id: 'lynx_login',
      title: 'Portal Access & First-Time Login',
      summary: 'How to access your JUIT student portal, credentials format, and self-service password reset.',
      category: 'Account & Access',
      directUrl: 'https://webkiosk.juitsolan.in',
      steps: [
        {
          stepNumber: 1,
          title: 'Navigate to Official Portal',
          description: 'Open your browser and visit webkiosk.juitsolan.in (or access via the Campus Lynx mobile link on intranet/Wi-Fi).'
        },
        {
          stepNumber: 2,
          title: 'Enter Credentials Format',
          description: 'Username is your JUIT Enrollment Number (e.g., 231030045). For first-time login, the default password is your Date of Birth in DDMMYYYY format unless provided otherwise on your admission slip.'
        },
        {
          stepNumber: 3,
          title: 'Immediate Password Change & Security Questions',
          description: 'On first login, the system will mandate a 8+ character password with at least 1 uppercase letter and 1 number. Choose 2 recovery security questions.'
        },
        {
          stepNumber: 4,
          title: 'Troubleshooting Locked Accounts',
          description: 'If you enter the wrong password 5 consecutive times, your account enters a 30-minute lock. To unlock sooner, email webkiosk@juit.ac.in with your Roll No and scanned ID card.'
        }
      ]
    },
    {
      id: 'lynx_attendance',
      title: 'Checking Subject-Wise Attendance & 75% Rule',
      summary: 'Track lecture and lab attendance percentages and avoid debarment before end-term exams.',
      category: 'Academics',
      steps: [
        {
          stepNumber: 1,
          title: 'Access Attendance Dashboard',
          description: 'After logging into Campus Lynx / Webkiosk, click on "Academic Reports" in the left sidebar and select "Subject-Wise Student Attendance".'
        },
        {
          stepNumber: 2,
          title: 'Understanding Percentage Calculations',
          description: 'Attendance shows: Delivered Lectures, Attended Lectures, and Current Percentage. Red highlight appears automatically if your percentage is below 75%.'
        },
        {
          stepNumber: 3,
          title: '75% Mandatory Eligibility Rule',
          description: 'As per JUIT academic regulations, minimum 75% aggregate in both Theory and Practical separately is required to sit in the End-Semester Examination (T-3). Medical leave must be submitted within 3 days of resuming classes.'
        },
        {
          stepNumber: 4,
          title: 'Discrepancy Correction Window',
          description: 'If you were marked absent while present, submit a physical or email request to the concerned course coordinator within 7 calendar days of the class.'
        }
      ]
    },
    {
      id: 'lynx_fee_receipt',
      title: 'Downloading Semester Fee Receipts & Dues Clearance',
      summary: 'Generate authorized tuition and hostel fee receipts for income tax (80C), bank education loans, or scholarship verification.',
      category: 'Finance & Accounts',
      steps: [
        {
          stepNumber: 1,
          title: 'Open Financial Accounts Module',
          description: 'Go to the sidebar menu: "Fee & Accounts" -> "Student Fee Ledger & Receipts".'
        },
        {
          stepNumber: 2,
          title: 'Select Academic Semester',
          description: 'Choose the appropriate academic year and semester (e.g., 2025-26 Even Semester) from the dropdown list.'
        },
        {
          stepNumber: 3,
          title: 'Generate Digitally Signed PDF',
          description: 'Click on "Print Official Receipt". Ensure pop-up blockers are disabled. The downloaded PDF contains transaction reference ID, breakdown of Tuition, Hostel, Mess, and Security deposit.'
        },
        {
          stepNumber: 4,
          title: 'Physical Stamp Verification (For Bank Loans)',
          description: 'If your bank requires an in-person physical stamp, visit the Accounts Department (Admin Block, Counter No. 2) with the printed copy between 10:00 AM and 01:00 PM.'
        }
      ]
    },
    {
      id: 'lynx_grievance',
      title: 'Lodging Complaints & Hostel Grievance Redressal',
      summary: 'Register complaints regarding Wi-Fi, electricity, plumbing, hostel furniture, or academic matters with tracked ticket IDs.',
      category: 'Campus Facilities',
      steps: [
        {
          stepNumber: 1,
          title: 'Navigate to Grievance Section',
          description: 'Click "Student Services" -> "Grievance / Maintenance Request" on the Campus Lynx portal.'
        },
        {
          stepNumber: 2,
          title: 'Select Category & Room Details',
          description: 'Categories include: Electrical (tube-light, switch), Carpentry (bed, table, lock), Plumbing (geyser, tap), Internet/Wi-Fi, or Mess/Food.'
        },
        {
          stepNumber: 3,
          title: 'Provide Clear Description & Upload Photo',
          description: 'Describe the issue clearly with your specific Hostel Block and Room Number. You can optionally attach an image of the breakdown.'
        },
        {
          stepNumber: 4,
          title: 'Resolution Timeframe & Ticket Tracking',
          description: 'Standard repair window is 24 to 48 hours on working days. Note your Ticket Number. If not resolved in 48 hours, escalate directly to the Block Caretaker or Hostel Warden.'
        }
      ]
    },
    {
      id: 'lynx_exam_admit_card',
      title: 'Examination Forms, Datesheet & Admit Card',
      summary: 'Exam registration, seating allotment, downloading admit cards for T-1, T-2, and T-3 exams.',
      category: 'Examinations',
      steps: [
        {
          stepNumber: 1,
          title: 'Verify Exam Registration',
          description: 'Under "Examination Module", check your enrolled course list 2 weeks before the start of Test-1 (T-1) or End-Term (T-3).'
        },
        {
          stepNumber: 2,
          title: 'Admit Card Generation',
          description: 'Admit cards are released 5 days prior to T-3 exam week. Ensure no library books or fee dues are pending, or the download link will remain inactive.'
        },
        {
          stepNumber: 3,
          title: 'Mandatory Printout & ID Verification',
          description: 'Print the admit card on A4 sheet. Students must carry both their JUIT Student Identity Card and Printed Admit Card into the examination hall.'
        }
      ]
    }
  ]
};
